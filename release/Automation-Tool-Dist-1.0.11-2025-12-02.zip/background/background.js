var yo = Object.defineProperty;
var vo = (_, V, k) => V in _ ? yo(_, V, { enumerable: !0, configurable: !0, writable: !0, value: k }) : _[V] = k;
var $t = (_, V, k) => vo(_, typeof V != "symbol" ? V + "" : V, k);
var mo = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function go(_) {
  return _ && _.__esModule && Object.prototype.hasOwnProperty.call(_, "default") ? _.default : _;
}
var zt = { exports: {} }, bo = zt.exports, Er;
function wo() {
  return Er || (Er = 1, (function(_, V) {
    (function(k, x) {
      _.exports = x();
    })(bo, function() {
      var k = function(e, t) {
        return (k = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
          n.__proto__ = r;
        } || function(n, r) {
          for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (n[o] = r[o]);
        })(e, t);
      }, x = function() {
        return (x = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
          return e;
        }).apply(this, arguments);
      };
      function W(e, t, n) {
        for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || ((r = r || Array.prototype.slice.call(t, 0, o))[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t));
      }
      var U = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : mo, $ = Object.keys, C = Array.isArray;
      function A(e, t) {
        return typeof t != "object" || $(t).forEach(function(n) {
          e[n] = t[n];
        }), e;
      }
      typeof Promise > "u" || U.Promise || (U.Promise = Promise);
      var X = Object.getPrototypeOf, le = {}.hasOwnProperty;
      function oe(e, t) {
        return le.call(e, t);
      }
      function Me(e, t) {
        typeof t == "function" && (t = t(X(e))), (typeof Reflect > "u" ? $ : Reflect.ownKeys)(t).forEach(function(n) {
          ge(e, n, t[n]);
        });
      }
      var Mn = Object.defineProperty;
      function ge(e, t, n, r) {
        Mn(e, t, A(n && oe(n, "get") && typeof n.get == "function" ? { get: n.get, set: n.set, configurable: !0 } : { value: n, configurable: !0, writable: !0 }, r));
      }
      function Fe(e) {
        return { from: function(t) {
          return e.prototype = Object.create(t.prototype), ge(e.prototype, "constructor", e), { extend: Me.bind(null, e.prototype) };
        } };
      }
      var Dr = Object.getOwnPropertyDescriptor, Tr = [].slice;
      function yt(e, t, n) {
        return Tr.call(e, t, n);
      }
      function Fn(e, t) {
        return t(e);
      }
      function Je(e) {
        if (!e) throw new Error("Assertion Failed");
      }
      function Vn(e) {
        U.setImmediate ? setImmediate(e) : setTimeout(e, 0);
      }
      function pe(e, t) {
        if (typeof t == "string" && oe(e, t)) return e[t];
        if (!t) return e;
        if (typeof t != "string") {
          for (var n = [], r = 0, o = t.length; r < o; ++r) {
            var i = pe(e, t[r]);
            n.push(i);
          }
          return n;
        }
        var a = t.indexOf(".");
        if (a !== -1) {
          var u = e[t.substr(0, a)];
          return u == null ? void 0 : pe(u, t.substr(a + 1));
        }
      }
      function ie(e, t, n) {
        if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) if (typeof t != "string" && "length" in t) {
          Je(typeof n != "string" && "length" in n);
          for (var r = 0, o = t.length; r < o; ++r) ie(e, t[r], n[r]);
        } else {
          var i, a, u = t.indexOf(".");
          u !== -1 ? (i = t.substr(0, u), (a = t.substr(u + 1)) === "" ? n === void 0 ? C(e) && !isNaN(parseInt(i)) ? e.splice(i, 1) : delete e[i] : e[i] = n : ie(u = !(u = e[i]) || !oe(e, i) ? e[i] = {} : u, a, n)) : n === void 0 ? C(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
        }
      }
      function Ln(e) {
        var t, n = {};
        for (t in e) oe(e, t) && (n[t] = e[t]);
        return n;
      }
      var Cr = [].concat;
      function Un(e) {
        return Cr.apply([], e);
      }
      var Ke = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(Un([8, 16, 32, 64].map(function(e) {
        return ["Int", "Uint", "Float"].map(function(t) {
          return t + e + "Array";
        });
      }))).filter(function(e) {
        return U[e];
      }), $n = new Set(Ke.map(function(e) {
        return U[e];
      })), Ze = null;
      function Oe(e) {
        return Ze = /* @__PURE__ */ new WeakMap(), e = (function t(n) {
          if (!n || typeof n != "object") return n;
          var r = Ze.get(n);
          if (r) return r;
          if (C(n)) {
            r = [], Ze.set(n, r);
            for (var o = 0, i = n.length; o < i; ++o) r.push(t(n[o]));
          } else if ($n.has(n.constructor)) r = n;
          else {
            var a, u = X(n);
            for (a in r = u === Object.prototype ? {} : Object.create(u), Ze.set(n, r), n) oe(n, a) && (r[a] = t(n[a]));
          }
          return r;
        })(e), Ze = null, e;
      }
      var Ar = {}.toString;
      function Xt(e) {
        return Ar.call(e).slice(8, -1);
      }
      var Jt = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", qr = typeof Jt == "symbol" ? function(e) {
        var t;
        return e != null && (t = e[Jt]) && t.apply(e);
      } : function() {
        return null;
      };
      function je(e, t) {
        return t = e.indexOf(t), 0 <= t && e.splice(t, 1), 0 <= t;
      }
      var Ve = {};
      function ye(e) {
        var t, n, r, o;
        if (arguments.length === 1) {
          if (C(e)) return e.slice();
          if (this === Ve && typeof e == "string") return [e];
          if (o = qr(e)) {
            for (n = []; !(r = o.next()).done; ) n.push(r.value);
            return n;
          }
          if (e == null) return [e];
          if (typeof (t = e.length) != "number") return [e];
          for (n = new Array(t); t--; ) n[t] = e[t];
          return n;
        }
        for (t = arguments.length, n = new Array(t); t--; ) n[t] = arguments[t];
        return n;
      }
      var Zt = typeof Symbol < "u" ? function(e) {
        return e[Symbol.toStringTag] === "AsyncFunction";
      } : function() {
        return !1;
      }, nt = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"], ce = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(nt), Br = { VersionChanged: "Database version changed by other database connection", DatabaseClosed: "Database has been closed", Abort: "Transaction aborted", TransactionInactive: "Transaction has already completed or failed", MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb" };
      function Le(e, t) {
        this.name = e, this.message = t;
      }
      function zn(e, t) {
        return e + ". Errors: " + Object.keys(t).map(function(n) {
          return t[n].toString();
        }).filter(function(n, r, o) {
          return o.indexOf(n) === r;
        }).join(`
`);
      }
      function vt(e, t, n, r) {
        this.failures = t, this.failedKeys = r, this.successCount = n, this.message = zn(e, t);
      }
      function Ue(e, t) {
        this.name = "BulkError", this.failures = Object.keys(t).map(function(n) {
          return t[n];
        }), this.failuresByPos = t, this.message = zn(e, this.failures);
      }
      Fe(Le).from(Error).extend({ toString: function() {
        return this.name + ": " + this.message;
      } }), Fe(vt).from(Le), Fe(Ue).from(Le);
      var en = ce.reduce(function(e, t) {
        return e[t] = t + "Error", e;
      }, {}), Rr = Le, q = ce.reduce(function(e, t) {
        var n = t + "Error";
        function r(o, i) {
          this.name = n, o ? typeof o == "string" ? (this.message = "".concat(o).concat(i ? `
 ` + i : ""), this.inner = i || null) : typeof o == "object" && (this.message = "".concat(o.name, " ").concat(o.message), this.inner = o) : (this.message = Br[t] || n, this.inner = null);
        }
        return Fe(r).from(Rr), e[t] = r, e;
      }, {});
      q.Syntax = SyntaxError, q.Type = TypeError, q.Range = RangeError;
      var Yn = nt.reduce(function(e, t) {
        return e[t + "Error"] = q[t], e;
      }, {}), mt = ce.reduce(function(e, t) {
        return ["Syntax", "Type", "Range"].indexOf(t) === -1 && (e[t + "Error"] = q[t]), e;
      }, {});
      function z() {
      }
      function et(e) {
        return e;
      }
      function Nr(e, t) {
        return e == null || e === et ? t : function(n) {
          return t(e(n));
        };
      }
      function Ee(e, t) {
        return function() {
          e.apply(this, arguments), t.apply(this, arguments);
        };
      }
      function Mr(e, t) {
        return e === z ? t : function() {
          var n = e.apply(this, arguments);
          n !== void 0 && (arguments[0] = n);
          var r = this.onsuccess, o = this.onerror;
          this.onsuccess = null, this.onerror = null;
          var i = t.apply(this, arguments);
          return r && (this.onsuccess = this.onsuccess ? Ee(r, this.onsuccess) : r), o && (this.onerror = this.onerror ? Ee(o, this.onerror) : o), i !== void 0 ? i : n;
        };
      }
      function Fr(e, t) {
        return e === z ? t : function() {
          e.apply(this, arguments);
          var n = this.onsuccess, r = this.onerror;
          this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? Ee(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? Ee(r, this.onerror) : r);
        };
      }
      function Vr(e, t) {
        return e === z ? t : function(n) {
          var r = e.apply(this, arguments);
          A(n, r);
          var o = this.onsuccess, i = this.onerror;
          return this.onsuccess = null, this.onerror = null, n = t.apply(this, arguments), o && (this.onsuccess = this.onsuccess ? Ee(o, this.onsuccess) : o), i && (this.onerror = this.onerror ? Ee(i, this.onerror) : i), r === void 0 ? n === void 0 ? void 0 : n : A(r, n);
        };
      }
      function Lr(e, t) {
        return e === z ? t : function() {
          return t.apply(this, arguments) !== !1 && e.apply(this, arguments);
        };
      }
      function tn(e, t) {
        return e === z ? t : function() {
          var n = e.apply(this, arguments);
          if (n && typeof n.then == "function") {
            for (var r = this, o = arguments.length, i = new Array(o); o--; ) i[o] = arguments[o];
            return n.then(function() {
              return t.apply(r, i);
            });
          }
          return t.apply(this, arguments);
        };
      }
      mt.ModifyError = vt, mt.DexieError = Le, mt.BulkError = Ue;
      var fe = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
      function Wn(e) {
        fe = e;
      }
      var tt = {}, Hn = 100, Ke = typeof Promise > "u" ? [] : (function() {
        var e = Promise.resolve();
        if (typeof crypto > "u" || !crypto.subtle) return [e, X(e), e];
        var t = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [t, X(t), e];
      })(), nt = Ke[0], ce = Ke[1], Ke = Ke[2], ce = ce && ce.then, Ie = nt && nt.constructor, nn = !!Ke, rt = function(e, t) {
        ot.push([e, t]), gt && (queueMicrotask($r), gt = !1);
      }, rn = !0, gt = !0, De = [], bt = [], on = et, be = { id: "global", global: !0, ref: 0, unhandleds: [], onunhandled: z, pgp: !1, env: {}, finalize: z }, T = be, ot = [], Te = 0, wt = [];
      function I(e) {
        if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
        this._listeners = [], this._lib = !1;
        var t = this._PSD = T;
        if (typeof e != "function") {
          if (e !== tt) throw new TypeError("Not a function");
          return this._state = arguments[1], this._value = arguments[2], void (this._state === !1 && un(this, this._value));
        }
        this._state = null, this._value = null, ++t.ref, (function n(r, o) {
          try {
            o(function(i) {
              if (r._state === null) {
                if (i === r) throw new TypeError("A promise cannot be resolved with itself.");
                var a = r._lib && $e();
                i && typeof i.then == "function" ? n(r, function(u, c) {
                  i instanceof I ? i._then(u, c) : i.then(u, c);
                }) : (r._state = !0, r._value = i, Qn(r)), a && ze();
              }
            }, un.bind(null, r));
          } catch (i) {
            un(r, i);
          }
        })(this, e);
      }
      var an = { get: function() {
        var e = T, t = Pt;
        function n(r, o) {
          var i = this, a = !e.global && (e !== T || t !== Pt), u = a && !_e(), c = new I(function(l, p) {
            sn(i, new Gn(Jn(r, e, a, u), Jn(o, e, a, u), l, p, e));
          });
          return this._consoleTask && (c._consoleTask = this._consoleTask), c;
        }
        return n.prototype = tt, n;
      }, set: function(e) {
        ge(this, "then", e && e.prototype === tt ? an : { get: function() {
          return e;
        }, set: an.set });
      } };
      function Gn(e, t, n, r, o) {
        this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = o;
      }
      function un(e, t) {
        var n, r;
        bt.push(t), e._state === null && (n = e._lib && $e(), t = on(t), e._state = !1, e._value = t, r = e, De.some(function(o) {
          return o._value === r._value;
        }) || De.push(r), Qn(e), n && ze());
      }
      function Qn(e) {
        var t = e._listeners;
        e._listeners = [];
        for (var n = 0, r = t.length; n < r; ++n) sn(e, t[n]);
        var o = e._PSD;
        --o.ref || o.finalize(), Te === 0 && (++Te, rt(function() {
          --Te == 0 && cn();
        }, []));
      }
      function sn(e, t) {
        if (e._state !== null) {
          var n = e._state ? t.onFulfilled : t.onRejected;
          if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
          ++t.psd.ref, ++Te, rt(Ur, [n, e, t]);
        } else e._listeners.push(t);
      }
      function Ur(e, t, n) {
        try {
          var r, o = t._value;
          !t._state && bt.length && (bt = []), r = fe && t._consoleTask ? t._consoleTask.run(function() {
            return e(o);
          }) : e(o), t._state || bt.indexOf(o) !== -1 || (function(i) {
            for (var a = De.length; a; ) if (De[--a]._value === i._value) return De.splice(a, 1);
          })(t), n.resolve(r);
        } catch (i) {
          n.reject(i);
        } finally {
          --Te == 0 && cn(), --n.psd.ref || n.psd.finalize();
        }
      }
      function $r() {
        Ce(be, function() {
          $e() && ze();
        });
      }
      function $e() {
        var e = rn;
        return gt = rn = !1, e;
      }
      function ze() {
        var e, t, n;
        do
          for (; 0 < ot.length; ) for (e = ot, ot = [], n = e.length, t = 0; t < n; ++t) {
            var r = e[t];
            r[0].apply(null, r[1]);
          }
        while (0 < ot.length);
        gt = rn = !0;
      }
      function cn() {
        var e = De;
        De = [], e.forEach(function(r) {
          r._PSD.onunhandled.call(null, r._value, r);
        });
        for (var t = wt.slice(0), n = t.length; n; ) t[--n]();
      }
      function _t(e) {
        return new I(tt, !1, e);
      }
      function H(e, t) {
        var n = T;
        return function() {
          var r = $e(), o = T;
          try {
            return xe(n, !0), e.apply(this, arguments);
          } catch (i) {
            t && t(i);
          } finally {
            xe(o, !1), r && ze();
          }
        };
      }
      Me(I.prototype, { then: an, _then: function(e, t) {
        sn(this, new Gn(null, null, e, t, T));
      }, catch: function(e) {
        if (arguments.length === 1) return this.then(null, e);
        var t = e, n = arguments[1];
        return typeof t == "function" ? this.then(null, function(r) {
          return (r instanceof t ? n : _t)(r);
        }) : this.then(null, function(r) {
          return (r && r.name === t ? n : _t)(r);
        });
      }, finally: function(e) {
        return this.then(function(t) {
          return I.resolve(e()).then(function() {
            return t;
          });
        }, function(t) {
          return I.resolve(e()).then(function() {
            return _t(t);
          });
        });
      }, timeout: function(e, t) {
        var n = this;
        return e < 1 / 0 ? new I(function(r, o) {
          var i = setTimeout(function() {
            return o(new q.Timeout(t));
          }, e);
          n.then(r, o).finally(clearTimeout.bind(null, i));
        }) : this;
      } }), typeof Symbol < "u" && Symbol.toStringTag && ge(I.prototype, Symbol.toStringTag, "Dexie.Promise"), be.env = Xn(), Me(I, { all: function() {
        var e = ye.apply(null, arguments).map(St);
        return new I(function(t, n) {
          e.length === 0 && t([]);
          var r = e.length;
          e.forEach(function(o, i) {
            return I.resolve(o).then(function(a) {
              e[i] = a, --r || t(e);
            }, n);
          });
        });
      }, resolve: function(e) {
        return e instanceof I ? e : e && typeof e.then == "function" ? new I(function(t, n) {
          e.then(t, n);
        }) : new I(tt, !0, e);
      }, reject: _t, race: function() {
        var e = ye.apply(null, arguments).map(St);
        return new I(function(t, n) {
          e.map(function(r) {
            return I.resolve(r).then(t, n);
          });
        });
      }, PSD: { get: function() {
        return T;
      }, set: function(e) {
        return T = e;
      } }, totalEchoes: { get: function() {
        return Pt;
      } }, newPSD: we, usePSD: Ce, scheduler: { get: function() {
        return rt;
      }, set: function(e) {
        rt = e;
      } }, rejectionMapper: { get: function() {
        return on;
      }, set: function(e) {
        on = e;
      } }, follow: function(e, t) {
        return new I(function(n, r) {
          return we(function(o, i) {
            var a = T;
            a.unhandleds = [], a.onunhandled = i, a.finalize = Ee(function() {
              var u, c = this;
              u = function() {
                c.unhandleds.length === 0 ? o() : i(c.unhandleds[0]);
              }, wt.push(function l() {
                u(), wt.splice(wt.indexOf(l), 1);
              }), ++Te, rt(function() {
                --Te == 0 && cn();
              }, []);
            }, a.finalize), e();
          }, t, n, r);
        });
      } }), Ie && (Ie.allSettled && ge(I, "allSettled", function() {
        var e = ye.apply(null, arguments).map(St);
        return new I(function(t) {
          e.length === 0 && t([]);
          var n = e.length, r = new Array(n);
          e.forEach(function(o, i) {
            return I.resolve(o).then(function(a) {
              return r[i] = { status: "fulfilled", value: a };
            }, function(a) {
              return r[i] = { status: "rejected", reason: a };
            }).then(function() {
              return --n || t(r);
            });
          });
        });
      }), Ie.any && typeof AggregateError < "u" && ge(I, "any", function() {
        var e = ye.apply(null, arguments).map(St);
        return new I(function(t, n) {
          e.length === 0 && n(new AggregateError([]));
          var r = e.length, o = new Array(r);
          e.forEach(function(i, a) {
            return I.resolve(i).then(function(u) {
              return t(u);
            }, function(u) {
              o[a] = u, --r || n(new AggregateError(o));
            });
          });
        });
      }), Ie.withResolvers && (I.withResolvers = Ie.withResolvers));
      var J = { awaits: 0, echoes: 0, id: 0 }, zr = 0, xt = [], kt = 0, Pt = 0, Yr = 0;
      function we(e, t, n, r) {
        var o = T, i = Object.create(o);
        return i.parent = o, i.ref = 0, i.global = !1, i.id = ++Yr, be.env, i.env = nn ? { Promise: I, PromiseProp: { value: I, configurable: !0, writable: !0 }, all: I.all, race: I.race, allSettled: I.allSettled, any: I.any, resolve: I.resolve, reject: I.reject } : {}, t && A(i, t), ++o.ref, i.finalize = function() {
          --this.parent.ref || this.parent.finalize();
        }, r = Ce(i, e, n, r), i.ref === 0 && i.finalize(), r;
      }
      function Ye() {
        return J.id || (J.id = ++zr), ++J.awaits, J.echoes += Hn, J.id;
      }
      function _e() {
        return !!J.awaits && (--J.awaits == 0 && (J.id = 0), J.echoes = J.awaits * Hn, !0);
      }
      function St(e) {
        return J.echoes && e && e.constructor === Ie ? (Ye(), e.then(function(t) {
          return _e(), t;
        }, function(t) {
          return _e(), G(t);
        })) : e;
      }
      function Wr() {
        var e = xt[xt.length - 1];
        xt.pop(), xe(e, !1);
      }
      function xe(e, t) {
        var n, r = T;
        (t ? !J.echoes || kt++ && e === T : !kt || --kt && e === T) || queueMicrotask(t ? (function(o) {
          ++Pt, J.echoes && --J.echoes != 0 || (J.echoes = J.awaits = J.id = 0), xt.push(T), xe(o, !0);
        }).bind(null, e) : Wr), e !== T && (T = e, r === be && (be.env = Xn()), nn && (n = be.env.Promise, t = e.env, (r.global || e.global) && (Object.defineProperty(U, "Promise", t.PromiseProp), n.all = t.all, n.race = t.race, n.resolve = t.resolve, n.reject = t.reject, t.allSettled && (n.allSettled = t.allSettled), t.any && (n.any = t.any))));
      }
      function Xn() {
        var e = U.Promise;
        return nn ? { Promise: e, PromiseProp: Object.getOwnPropertyDescriptor(U, "Promise"), all: e.all, race: e.race, allSettled: e.allSettled, any: e.any, resolve: e.resolve, reject: e.reject } : {};
      }
      function Ce(e, t, n, r, o) {
        var i = T;
        try {
          return xe(e, !0), t(n, r, o);
        } finally {
          xe(i, !1);
        }
      }
      function Jn(e, t, n, r) {
        return typeof e != "function" ? e : function() {
          var o = T;
          n && Ye(), xe(t, !0);
          try {
            return e.apply(this, arguments);
          } finally {
            xe(o, !1), r && queueMicrotask(_e);
          }
        };
      }
      function ln(e) {
        Promise === Ie && J.echoes === 0 ? kt === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
      }
      ("" + ce).indexOf("[native code]") === -1 && (Ye = _e = z);
      var G = I.reject, Ae = "￿", ve = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", Zn = "String expected.", We = [], Ot = "__dbnames", fn = "readonly", dn = "readwrite";
      function qe(e, t) {
        return e ? t ? function() {
          return e.apply(this, arguments) && t.apply(this, arguments);
        } : e : t;
      }
      var er = { type: 3, lower: -1 / 0, lowerOpen: !1, upper: [[]], upperOpen: !1 };
      function jt(e) {
        return typeof e != "string" || /\./.test(e) ? function(t) {
          return t;
        } : function(t) {
          return t[e] === void 0 && e in t && delete (t = Oe(t))[e], t;
        };
      }
      function tr() {
        throw q.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
      }
      function F(e, t) {
        try {
          var n = nr(e), r = nr(t);
          if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r !== "Date" ? NaN : -1;
          switch (n) {
            case "number":
            case "Date":
            case "string":
              return t < e ? 1 : e < t ? -1 : 0;
            case "binary":
              return (function(o, i) {
                for (var a = o.length, u = i.length, c = a < u ? a : u, l = 0; l < c; ++l) if (o[l] !== i[l]) return o[l] < i[l] ? -1 : 1;
                return a === u ? 0 : a < u ? -1 : 1;
              })(rr(e), rr(t));
            case "Array":
              return (function(o, i) {
                for (var a = o.length, u = i.length, c = a < u ? a : u, l = 0; l < c; ++l) {
                  var p = F(o[l], i[l]);
                  if (p !== 0) return p;
                }
                return a === u ? 0 : a < u ? -1 : 1;
              })(e, t);
          }
        } catch {
        }
        return NaN;
      }
      function nr(e) {
        var t = typeof e;
        return t != "object" ? t : ArrayBuffer.isView(e) ? "binary" : (e = Xt(e), e === "ArrayBuffer" ? "binary" : e);
      }
      function rr(e) {
        return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
      }
      function Et(e, t, n) {
        var r = e.schema.yProps;
        return r ? (t && 0 < n.numFailures && (t = t.filter(function(o, i) {
          return !n.failures[i];
        })), Promise.all(r.map(function(o) {
          return o = o.updatesTable, t ? e.db.table(o).where("k").anyOf(t).delete() : e.db.table(o).clear();
        })).then(function() {
          return n;
        })) : n;
      }
      var it = (or.prototype.execute = function(e) {
        var t = this["@@propmod"];
        if (t.add !== void 0) {
          var n = t.add;
          if (C(n)) return W(W([], C(e) ? e : [], !0), n).sort();
          if (typeof n == "number") return (Number(e) || 0) + n;
          if (typeof n == "bigint") try {
            return BigInt(e) + n;
          } catch {
            return BigInt(0) + n;
          }
          throw new TypeError("Invalid term ".concat(n));
        }
        if (t.remove !== void 0) {
          var r = t.remove;
          if (C(r)) return C(e) ? e.filter(function(o) {
            return !r.includes(o);
          }).sort() : [];
          if (typeof r == "number") return Number(e) - r;
          if (typeof r == "bigint") try {
            return BigInt(e) - r;
          } catch {
            return BigInt(0) - r;
          }
          throw new TypeError("Invalid subtrahend ".concat(r));
        }
        return n = (n = t.replacePrefix) === null || n === void 0 ? void 0 : n[0], n && typeof e == "string" && e.startsWith(n) ? t.replacePrefix[1] + e.substring(n.length) : e;
      }, or);
      function or(e) {
        this["@@propmod"] = e;
      }
      function ir(e, t) {
        for (var n = $(t), r = n.length, o = !1, i = 0; i < r; ++i) {
          var a = n[i], u = t[a], c = pe(e, a);
          u instanceof it ? (ie(e, a, u.execute(c)), o = !0) : c !== u && (ie(e, a, u), o = !0);
        }
        return o;
      }
      var ar = (Y.prototype._trans = function(e, t, n) {
        var r = this._tx || T.trans, o = this.name, i = fe && typeof console < "u" && console.createTask && console.createTask("Dexie: ".concat(e === "readonly" ? "read" : "write", " ").concat(this.name));
        function a(l, p, s) {
          if (!s.schema[o]) throw new q.NotFound("Table " + o + " not part of transaction");
          return t(s.idbtrans, s);
        }
        var u = $e();
        try {
          var c = r && r.db._novip === this.db._novip ? r === T.trans ? r._promise(e, a, n) : we(function() {
            return r._promise(e, a, n);
          }, { trans: r, transless: T.transless || T }) : (function l(p, s, v, f) {
            if (p.idbdb && (p._state.openComplete || T.letThrough || p._vip)) {
              var d = p._createTransaction(s, v, p._dbSchema);
              try {
                d.create(), p._state.PR1398_maxLoop = 3;
              } catch (h) {
                return h.name === en.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                  return l(p, s, v, f);
                })) : G(h);
              }
              return d._promise(s, function(h, y) {
                return we(function() {
                  return T.trans = d, f(h, y, d);
                });
              }).then(function(h) {
                if (s === "readwrite") try {
                  d.idbtrans.commit();
                } catch {
                }
                return s === "readonly" ? h : d._completion.then(function() {
                  return h;
                });
              });
            }
            if (p._state.openComplete) return G(new q.DatabaseClosed(p._state.dbOpenError));
            if (!p._state.isBeingOpened) {
              if (!p._state.autoOpen) return G(new q.DatabaseClosed());
              p.open().catch(z);
            }
            return p._state.dbReadyPromise.then(function() {
              return l(p, s, v, f);
            });
          })(this.db, e, [this.name], a);
          return i && (c._consoleTask = i, c = c.catch(function(l) {
            return console.trace(l), G(l);
          })), c;
        } finally {
          u && ze();
        }
      }, Y.prototype.get = function(e, t) {
        var n = this;
        return e && e.constructor === Object ? this.where(e).first(t) : e == null ? G(new q.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(r) {
          return n.core.get({ trans: r, key: e }).then(function(o) {
            return n.hook.reading.fire(o);
          });
        }).then(t);
      }, Y.prototype.where = function(e) {
        if (typeof e == "string") return new this.db.WhereClause(this, e);
        if (C(e)) return new this.db.WhereClause(this, "[".concat(e.join("+"), "]"));
        var t = $(e);
        if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
        var n = this.schema.indexes.concat(this.schema.primKey).filter(function(u) {
          if (u.compound && t.every(function(l) {
            return 0 <= u.keyPath.indexOf(l);
          })) {
            for (var c = 0; c < t.length; ++c) if (t.indexOf(u.keyPath[c]) === -1) return !1;
            return !0;
          }
          return !1;
        }).sort(function(u, c) {
          return u.keyPath.length - c.keyPath.length;
        })[0];
        if (n && this.db._maxKey !== Ae) {
          var i = n.keyPath.slice(0, t.length);
          return this.where(i).equals(i.map(function(c) {
            return e[c];
          }));
        }
        !n && fe && console.warn("The query ".concat(JSON.stringify(e), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(t.join("+"), "]"));
        var r = this.schema.idxByName;
        function o(u, c) {
          return F(u, c) === 0;
        }
        var a = t.reduce(function(s, c) {
          var l = s[0], p = s[1], s = r[c], v = e[c];
          return [l || s, l || !s ? qe(p, s && s.multi ? function(f) {
            return f = pe(f, c), C(f) && f.some(function(d) {
              return o(v, d);
            });
          } : function(f) {
            return o(v, pe(f, c));
          }) : p];
        }, [null, null]), i = a[0], a = a[1];
        return i ? this.where(i.name).equals(e[i.keyPath]).filter(a) : n ? this.filter(a) : this.where(t).equals("");
      }, Y.prototype.filter = function(e) {
        return this.toCollection().and(e);
      }, Y.prototype.count = function(e) {
        return this.toCollection().count(e);
      }, Y.prototype.offset = function(e) {
        return this.toCollection().offset(e);
      }, Y.prototype.limit = function(e) {
        return this.toCollection().limit(e);
      }, Y.prototype.each = function(e) {
        return this.toCollection().each(e);
      }, Y.prototype.toArray = function(e) {
        return this.toCollection().toArray(e);
      }, Y.prototype.toCollection = function() {
        return new this.db.Collection(new this.db.WhereClause(this));
      }, Y.prototype.orderBy = function(e) {
        return new this.db.Collection(new this.db.WhereClause(this, C(e) ? "[".concat(e.join("+"), "]") : e));
      }, Y.prototype.reverse = function() {
        return this.toCollection().reverse();
      }, Y.prototype.mapToClass = function(e) {
        var t, n = this.db, r = this.name;
        function o() {
          return t !== null && t.apply(this, arguments) || this;
        }
        (this.schema.mappedClass = e).prototype instanceof tr && ((function(c, l) {
          if (typeof l != "function" && l !== null) throw new TypeError("Class extends value " + String(l) + " is not a constructor or null");
          function p() {
            this.constructor = c;
          }
          k(c, l), c.prototype = l === null ? Object.create(l) : (p.prototype = l.prototype, new p());
        })(o, t = e), Object.defineProperty(o.prototype, "db", { get: function() {
          return n;
        }, enumerable: !1, configurable: !0 }), o.prototype.table = function() {
          return r;
        }, e = o);
        for (var i = /* @__PURE__ */ new Set(), a = e.prototype; a; a = X(a)) Object.getOwnPropertyNames(a).forEach(function(c) {
          return i.add(c);
        });
        function u(c) {
          if (!c) return c;
          var l, p = Object.create(e.prototype);
          for (l in c) if (!i.has(l)) try {
            p[l] = c[l];
          } catch {
          }
          return p;
        }
        return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = u, this.hook("reading", u), e;
      }, Y.prototype.defineClass = function() {
        return this.mapToClass(function(e) {
          A(this, e);
        });
      }, Y.prototype.add = function(e, t) {
        var n = this, r = this.schema.primKey, o = r.auto, i = r.keyPath, a = e;
        return i && o && (a = jt(i)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "add", keys: t != null ? [t] : null, values: [a] });
        }).then(function(u) {
          return u.numFailures ? I.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (i) try {
            ie(e, i, u);
          } catch {
          }
          return u;
        });
      }, Y.prototype.upsert = function(e, t) {
        var n = this, r = this.schema.primKey.keyPath;
        return this._trans("readwrite", function(o) {
          return n.core.get({ trans: o, key: e }).then(function(i) {
            var a = i ?? {};
            return ir(a, t), r && ie(a, r, e), n.core.mutate({ trans: o, type: "put", values: [a], keys: [e], upsert: !0, updates: { keys: [e], changeSpecs: [t] } }).then(function(u) {
              return u.numFailures ? I.reject(u.failures[0]) : !!i;
            });
          });
        });
      }, Y.prototype.update = function(e, t) {
        return typeof e != "object" || C(e) ? this.where(":id").equals(e).modify(t) : (e = pe(e, this.schema.primKey.keyPath), e === void 0 ? G(new q.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t));
      }, Y.prototype.put = function(e, t) {
        var n = this, r = this.schema.primKey, o = r.auto, i = r.keyPath, a = e;
        return i && o && (a = jt(i)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "put", values: [a], keys: t != null ? [t] : null });
        }).then(function(u) {
          return u.numFailures ? I.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (i) try {
            ie(e, i, u);
          } catch {
          }
          return u;
        });
      }, Y.prototype.delete = function(e) {
        var t = this;
        return this._trans("readwrite", function(n) {
          return t.core.mutate({ trans: n, type: "delete", keys: [e] }).then(function(r) {
            return Et(t, [e], r);
          }).then(function(r) {
            return r.numFailures ? I.reject(r.failures[0]) : void 0;
          });
        });
      }, Y.prototype.clear = function() {
        var e = this;
        return this._trans("readwrite", function(t) {
          return e.core.mutate({ trans: t, type: "deleteRange", range: er }).then(function(n) {
            return Et(e, null, n);
          });
        }).then(function(t) {
          return t.numFailures ? I.reject(t.failures[0]) : void 0;
        });
      }, Y.prototype.bulkGet = function(e) {
        var t = this;
        return this._trans("readonly", function(n) {
          return t.core.getMany({ keys: e, trans: n }).then(function(r) {
            return r.map(function(o) {
              return t.hook.reading.fire(o);
            });
          });
        });
      }, Y.prototype.bulkAdd = function(e, t, n) {
        var r = this, o = Array.isArray(t) ? t : void 0, i = (n = n || (o ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var l = r.schema.primKey, u = l.auto, l = l.keyPath;
          if (l && o) throw new q.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
          if (o && o.length !== e.length) throw new q.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, l = l && u ? e.map(jt(l)) : e;
          return r.core.mutate({ trans: a, type: "add", keys: o, values: l, wantResults: i }).then(function(d) {
            var s = d.numFailures, v = d.results, f = d.lastResult, d = d.failures;
            if (s === 0) return i ? v : f;
            throw new Ue("".concat(r.name, ".bulkAdd(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, Y.prototype.bulkPut = function(e, t, n) {
        var r = this, o = Array.isArray(t) ? t : void 0, i = (n = n || (o ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var l = r.schema.primKey, u = l.auto, l = l.keyPath;
          if (l && o) throw new q.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
          if (o && o.length !== e.length) throw new q.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, l = l && u ? e.map(jt(l)) : e;
          return r.core.mutate({ trans: a, type: "put", keys: o, values: l, wantResults: i }).then(function(d) {
            var s = d.numFailures, v = d.results, f = d.lastResult, d = d.failures;
            if (s === 0) return i ? v : f;
            throw new Ue("".concat(r.name, ".bulkPut(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, Y.prototype.bulkUpdate = function(e) {
        var t = this, n = this.core, r = e.map(function(a) {
          return a.key;
        }), o = e.map(function(a) {
          return a.changes;
        }), i = [];
        return this._trans("readwrite", function(a) {
          return n.getMany({ trans: a, keys: r, cache: "clone" }).then(function(u) {
            var c = [], l = [];
            e.forEach(function(s, v) {
              var f = s.key, d = s.changes, h = u[v];
              if (h) {
                for (var y = 0, m = Object.keys(d); y < m.length; y++) {
                  var g = m[y], b = d[g];
                  if (g === t.schema.primKey.keyPath) {
                    if (F(b, f) !== 0) throw new q.Constraint("Cannot update primary key in bulkUpdate()");
                  } else ie(h, g, b);
                }
                i.push(v), c.push(f), l.push(h);
              }
            });
            var p = c.length;
            return n.mutate({ trans: a, type: "put", keys: c, values: l, updates: { keys: r, changeSpecs: o } }).then(function(s) {
              var v = s.numFailures, f = s.failures;
              if (v === 0) return p;
              for (var d = 0, h = Object.keys(f); d < h.length; d++) {
                var y, m = h[d], g = i[Number(m)];
                g != null && (y = f[m], delete f[m], f[g] = y);
              }
              throw new Ue("".concat(t.name, ".bulkUpdate(): ").concat(v, " of ").concat(p, " operations failed"), f);
            });
          });
        });
      }, Y.prototype.bulkDelete = function(e) {
        var t = this, n = e.length;
        return this._trans("readwrite", function(r) {
          return t.core.mutate({ trans: r, type: "delete", keys: e }).then(function(o) {
            return Et(t, e, o);
          });
        }).then(function(a) {
          var o = a.numFailures, i = a.lastResult, a = a.failures;
          if (o === 0) return i;
          throw new Ue("".concat(t.name, ".bulkDelete(): ").concat(o, " of ").concat(n, " operations failed"), a);
        });
      }, Y);
      function Y() {
      }
      function at(e) {
        function t(a, u) {
          if (u) {
            for (var c = arguments.length, l = new Array(c - 1); --c; ) l[c - 1] = arguments[c];
            return n[a].subscribe.apply(null, l), e;
          }
          if (typeof a == "string") return n[a];
        }
        var n = {};
        t.addEventType = i;
        for (var r = 1, o = arguments.length; r < o; ++r) i(arguments[r]);
        return t;
        function i(a, u, c) {
          if (typeof a != "object") {
            var l;
            u = u || Lr;
            var p = { subscribers: [], fire: c = c || z, subscribe: function(s) {
              p.subscribers.indexOf(s) === -1 && (p.subscribers.push(s), p.fire = u(p.fire, s));
            }, unsubscribe: function(s) {
              p.subscribers = p.subscribers.filter(function(v) {
                return v !== s;
              }), p.fire = p.subscribers.reduce(u, c);
            } };
            return n[a] = t[a] = p;
          }
          $(l = a).forEach(function(s) {
            var v = l[s];
            if (C(v)) i(s, l[s][0], l[s][1]);
            else {
              if (v !== "asap") throw new q.InvalidArgument("Invalid event config");
              var f = i(s, et, function() {
                for (var d = arguments.length, h = new Array(d); d--; ) h[d] = arguments[d];
                f.subscribers.forEach(function(y) {
                  Vn(function() {
                    y.apply(null, h);
                  });
                });
              });
            }
          });
        }
      }
      function ut(e, t) {
        return Fe(t).from({ prototype: e }), t;
      }
      function He(e, t) {
        return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
      }
      function hn(e, t) {
        e.filter = qe(e.filter, t);
      }
      function pn(e, t, n) {
        var r = e.replayFilter;
        e.replayFilter = r ? function() {
          return qe(r(), t());
        } : t, e.justLimit = n && !r;
      }
      function Kt(e, t) {
        if (e.isPrimKey) return t.primaryKey;
        var n = t.getIndexByKeyPath(e.index);
        if (!n) throw new q.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
        return n;
      }
      function ur(e, t, n) {
        var r = Kt(e, t.schema);
        return t.openCursor({ trans: n, values: !e.keysOnly, reverse: e.dir === "prev", unique: !!e.unique, query: { index: r, range: e.range } });
      }
      function It(e, t, n, r) {
        var o = e.replayFilter ? qe(e.filter, e.replayFilter()) : e.filter;
        if (e.or) {
          var i = {}, a = function(u, c, l) {
            var p, s;
            o && !o(c, l, function(v) {
              return c.stop(v);
            }, function(v) {
              return c.fail(v);
            }) || ((s = "" + (p = c.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(p)), oe(i, s) || (i[s] = !0, t(u, c, l)));
          };
          return Promise.all([e.or._iterate(a, n), sr(ur(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)]);
        }
        return sr(ur(e, r, n), qe(e.algorithm, o), t, !e.keysOnly && e.valueMapper);
      }
      function sr(e, t, n, r) {
        var o = H(r ? function(i, a, u) {
          return n(r(i), a, u);
        } : n);
        return e.then(function(i) {
          if (i) return i.start(function() {
            var a = function() {
              return i.continue();
            };
            t && !t(i, function(u) {
              return a = u;
            }, function(u) {
              i.stop(u), a = z;
            }, function(u) {
              i.fail(u), a = z;
            }) || o(i.value, i, function(u) {
              return a = u;
            }), a();
          });
        });
      }
      var Hr = (L.prototype._read = function(e, t) {
        var n = this._ctx;
        return n.error ? n.table._trans(null, G.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
      }, L.prototype._write = function(e) {
        var t = this._ctx;
        return t.error ? t.table._trans(null, G.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
      }, L.prototype._addAlgorithm = function(e) {
        var t = this._ctx;
        t.algorithm = qe(t.algorithm, e);
      }, L.prototype._iterate = function(e, t) {
        return It(this._ctx, e, t, this._ctx.table.core);
      }, L.prototype.clone = function(e) {
        var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
        return e && A(n, e), t._ctx = n, t;
      }, L.prototype.raw = function() {
        return this._ctx.valueMapper = null, this;
      }, L.prototype.each = function(e) {
        var t = this._ctx;
        return this._read(function(n) {
          return It(t, e, n, t.table.core);
        });
      }, L.prototype.count = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx, o = r.table.core;
          if (He(r, !0)) return o.count({ trans: n, query: { index: Kt(r, o.schema), range: r.range } }).then(function(a) {
            return Math.min(a, r.limit);
          });
          var i = 0;
          return It(r, function() {
            return ++i, !1;
          }, n, o).then(function() {
            return i;
          });
        }).then(e);
      }, L.prototype.sortBy = function(e, t) {
        var n = e.split(".").reverse(), r = n[0], o = n.length - 1;
        function i(c, l) {
          return l ? i(c[n[l]], l - 1) : c[r];
        }
        var a = this._ctx.dir === "next" ? 1 : -1;
        function u(c, l) {
          return F(i(c, o), i(l, o)) * a;
        }
        return this.toArray(function(c) {
          return c.sort(u);
        }).then(t);
      }, L.prototype.toArray = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx;
          if (r.dir === "next" && He(r, !0) && 0 < r.limit) {
            var o = r.valueMapper, i = Kt(r, r.table.core.schema);
            return r.table.core.query({ trans: n, limit: r.limit, values: !0, query: { index: i, range: r.range } }).then(function(u) {
              return u = u.result, o ? u.map(o) : u;
            });
          }
          var a = [];
          return It(r, function(u) {
            return a.push(u);
          }, n, r.table.core).then(function() {
            return a;
          });
        }, e);
      }, L.prototype.offset = function(e) {
        var t = this._ctx;
        return e <= 0 || (t.offset += e, He(t) ? pn(t, function() {
          var n = e;
          return function(r, o) {
            return n === 0 || (n === 1 ? --n : o(function() {
              r.advance(n), n = 0;
            }), !1);
          };
        }) : pn(t, function() {
          var n = e;
          return function() {
            return --n < 0;
          };
        })), this;
      }, L.prototype.limit = function(e) {
        return this._ctx.limit = Math.min(this._ctx.limit, e), pn(this._ctx, function() {
          var t = e;
          return function(n, r, o) {
            return --t <= 0 && r(o), 0 <= t;
          };
        }, !0), this;
      }, L.prototype.until = function(e, t) {
        return hn(this._ctx, function(n, r, o) {
          return !e(n.value) || (r(o), t);
        }), this;
      }, L.prototype.first = function(e) {
        return this.limit(1).toArray(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.last = function(e) {
        return this.reverse().first(e);
      }, L.prototype.filter = function(e) {
        var t;
        return hn(this._ctx, function(n) {
          return e(n.value);
        }), (t = this._ctx).isMatch = qe(t.isMatch, e), this;
      }, L.prototype.and = function(e) {
        return this.filter(e);
      }, L.prototype.or = function(e) {
        return new this.db.WhereClause(this._ctx.table, e, this);
      }, L.prototype.reverse = function() {
        return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
      }, L.prototype.desc = function() {
        return this.reverse();
      }, L.prototype.eachKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.key, r);
        });
      }, L.prototype.eachUniqueKey = function(e) {
        return this._ctx.unique = "unique", this.eachKey(e);
      }, L.prototype.eachPrimaryKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.primaryKey, r);
        });
      }, L.prototype.keys = function(e) {
        var t = this._ctx;
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, o) {
          n.push(o.key);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.primaryKeys = function(e) {
        var t = this._ctx;
        if (t.dir === "next" && He(t, !0) && 0 < t.limit) return this._read(function(r) {
          var o = Kt(t, t.table.core.schema);
          return t.table.core.query({ trans: r, values: !1, limit: t.limit, query: { index: o, range: t.range } });
        }).then(function(r) {
          return r.result;
        }).then(e);
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, o) {
          n.push(o.primaryKey);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.uniqueKeys = function(e) {
        return this._ctx.unique = "unique", this.keys(e);
      }, L.prototype.firstKey = function(e) {
        return this.limit(1).keys(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.lastKey = function(e) {
        return this.reverse().firstKey(e);
      }, L.prototype.distinct = function() {
        var e = this._ctx, e = e.index && e.table.schema.idxByName[e.index];
        if (!e || !e.multi) return this;
        var t = {};
        return hn(this._ctx, function(o) {
          var r = o.primaryKey.toString(), o = oe(t, r);
          return t[r] = !0, !o;
        }), this;
      }, L.prototype.modify = function(e) {
        var t = this, n = this._ctx;
        return this._write(function(r) {
          var o = typeof e == "function" ? e : function(h) {
            return ir(h, e);
          }, i = n.table.core, l = i.schema.primaryKey, a = l.outbound, u = l.extractKey, c = 200, l = t.db._options.modifyChunkSize;
          l && (c = typeof l == "object" ? l[i.name] || l["*"] || 200 : l);
          function p(h, g) {
            var m = g.failures, g = g.numFailures;
            v += h - g;
            for (var b = 0, w = $(m); b < w.length; b++) {
              var S = w[b];
              s.push(m[S]);
            }
          }
          var s = [], v = 0, f = [], d = e === cr;
          return t.clone().primaryKeys().then(function(h) {
            function y(g) {
              var b = Math.min(c, h.length - g), w = h.slice(g, g + b);
              return (d ? Promise.resolve([]) : i.getMany({ trans: r, keys: w, cache: "immutable" })).then(function(S) {
                var E = [], P = [], O = a ? [] : null, K = d ? w : [];
                if (!d) for (var j = 0; j < b; ++j) {
                  var D = S[j], R = { value: Oe(D), primKey: h[g + j] };
                  o.call(R, R.value, R) !== !1 && (R.value == null ? K.push(h[g + j]) : a || F(u(D), u(R.value)) === 0 ? (P.push(R.value), a && O.push(h[g + j])) : (K.push(h[g + j]), E.push(R.value)));
                }
                return Promise.resolve(0 < E.length && i.mutate({ trans: r, type: "add", values: E }).then(function(N) {
                  for (var M in N.failures) K.splice(parseInt(M), 1);
                  p(E.length, N);
                })).then(function() {
                  return (0 < P.length || m && typeof e == "object") && i.mutate({ trans: r, type: "put", keys: O, values: P, criteria: m, changeSpec: typeof e != "function" && e, isAdditionalChunk: 0 < g }).then(function(N) {
                    return p(P.length, N);
                  });
                }).then(function() {
                  return (0 < K.length || m && d) && i.mutate({ trans: r, type: "delete", keys: K, criteria: m, isAdditionalChunk: 0 < g }).then(function(N) {
                    return Et(n.table, K, N);
                  }).then(function(N) {
                    return p(K.length, N);
                  });
                }).then(function() {
                  return h.length > g + b && y(g + c);
                });
              });
            }
            var m = He(n) && n.limit === 1 / 0 && (typeof e != "function" || d) && { index: n.index, range: n.range };
            return y(0).then(function() {
              if (0 < s.length) throw new vt("Error modifying one or more objects", s, v, f);
              return h.length;
            });
          });
        });
      }, L.prototype.delete = function() {
        var e = this._ctx, t = e.range;
        return !He(e) || e.table.schema.yProps || !e.isPrimKey && t.type !== 3 ? this.modify(cr) : this._write(function(n) {
          var r = e.table.core.schema.primaryKey, o = t;
          return e.table.core.count({ trans: n, query: { index: r, range: o } }).then(function(i) {
            return e.table.core.mutate({ trans: n, type: "deleteRange", range: o }).then(function(c) {
              var u = c.failures, c = c.numFailures;
              if (c) throw new vt("Could not delete some values", Object.keys(u).map(function(l) {
                return u[l];
              }), i - c);
              return i - c;
            });
          });
        });
      }, L);
      function L() {
      }
      var cr = function(e, t) {
        return t.value = null;
      };
      function Gr(e, t) {
        return e < t ? -1 : e === t ? 0 : 1;
      }
      function Qr(e, t) {
        return t < e ? -1 : e === t ? 0 : 1;
      }
      function ae(e, t, n) {
        return e = e instanceof fr ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
      }
      function Ge(e) {
        return new e.Collection(e, function() {
          return lr("");
        }).limit(0);
      }
      function Dt(e, t, n, r) {
        var o, i, a, u, c, l, p, s = n.length;
        if (!n.every(function(d) {
          return typeof d == "string";
        })) return ae(e, Zn);
        function v(d) {
          o = d === "next" ? function(y) {
            return y.toUpperCase();
          } : function(y) {
            return y.toLowerCase();
          }, i = d === "next" ? function(y) {
            return y.toLowerCase();
          } : function(y) {
            return y.toUpperCase();
          }, a = d === "next" ? Gr : Qr;
          var h = n.map(function(y) {
            return { lower: i(y), upper: o(y) };
          }).sort(function(y, m) {
            return a(y.lower, m.lower);
          });
          u = h.map(function(y) {
            return y.upper;
          }), c = h.map(function(y) {
            return y.lower;
          }), p = (l = d) === "next" ? "" : r;
        }
        v("next"), e = new e.Collection(e, function() {
          return ke(u[0], c[s - 1] + r);
        }), e._ondirectionchange = function(d) {
          v(d);
        };
        var f = 0;
        return e._addAlgorithm(function(d, h, y) {
          var m = d.key;
          if (typeof m != "string") return !1;
          var g = i(m);
          if (t(g, c, f)) return !0;
          for (var b = null, w = f; w < s; ++w) {
            var S = (function(E, P, O, K, j, D) {
              for (var R = Math.min(E.length, K.length), N = -1, M = 0; M < R; ++M) {
                var ue = P[M];
                if (ue !== K[M]) return j(E[M], O[M]) < 0 ? E.substr(0, M) + O[M] + O.substr(M + 1) : j(E[M], K[M]) < 0 ? E.substr(0, M) + K[M] + O.substr(M + 1) : 0 <= N ? E.substr(0, N) + P[N] + O.substr(N + 1) : null;
                j(E[M], ue) < 0 && (N = M);
              }
              return R < K.length && D === "next" ? E + O.substr(E.length) : R < E.length && D === "prev" ? E.substr(0, O.length) : N < 0 ? null : E.substr(0, N) + K[N] + O.substr(N + 1);
            })(m, g, u[w], c[w], a, l);
            S === null && b === null ? f = w + 1 : (b === null || 0 < a(b, S)) && (b = S);
          }
          return h(b !== null ? function() {
            d.continue(b + p);
          } : y), !1;
        }), e;
      }
      function ke(e, t, n, r) {
        return { type: 2, lower: e, upper: t, lowerOpen: n, upperOpen: r };
      }
      function lr(e) {
        return { type: 1, lower: e, upper: e };
      }
      var fr = (Object.defineProperty(Z.prototype, "Collection", { get: function() {
        return this._ctx.table.db.Collection;
      }, enumerable: !1, configurable: !0 }), Z.prototype.between = function(e, t, n, r) {
        n = n !== !1, r = r === !0;
        try {
          return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Ge(this) : new this.Collection(this, function() {
            return ke(e, t, !n, !r);
          });
        } catch {
          return ae(this, ve);
        }
      }, Z.prototype.equals = function(e) {
        return e == null ? ae(this, ve) : new this.Collection(this, function() {
          return lr(e);
        });
      }, Z.prototype.above = function(e) {
        return e == null ? ae(this, ve) : new this.Collection(this, function() {
          return ke(e, void 0, !0);
        });
      }, Z.prototype.aboveOrEqual = function(e) {
        return e == null ? ae(this, ve) : new this.Collection(this, function() {
          return ke(e, void 0, !1);
        });
      }, Z.prototype.below = function(e) {
        return e == null ? ae(this, ve) : new this.Collection(this, function() {
          return ke(void 0, e, !1, !0);
        });
      }, Z.prototype.belowOrEqual = function(e) {
        return e == null ? ae(this, ve) : new this.Collection(this, function() {
          return ke(void 0, e);
        });
      }, Z.prototype.startsWith = function(e) {
        return typeof e != "string" ? ae(this, Zn) : this.between(e, e + Ae, !0, !0);
      }, Z.prototype.startsWithIgnoreCase = function(e) {
        return e === "" ? this.startsWith(e) : Dt(this, function(t, n) {
          return t.indexOf(n[0]) === 0;
        }, [e], Ae);
      }, Z.prototype.equalsIgnoreCase = function(e) {
        return Dt(this, function(t, n) {
          return t === n[0];
        }, [e], "");
      }, Z.prototype.anyOfIgnoreCase = function() {
        var e = ye.apply(Ve, arguments);
        return e.length === 0 ? Ge(this) : Dt(this, function(t, n) {
          return n.indexOf(t) !== -1;
        }, e, "");
      }, Z.prototype.startsWithAnyOfIgnoreCase = function() {
        var e = ye.apply(Ve, arguments);
        return e.length === 0 ? Ge(this) : Dt(this, function(t, n) {
          return n.some(function(r) {
            return t.indexOf(r) === 0;
          });
        }, e, Ae);
      }, Z.prototype.anyOf = function() {
        var e = this, t = ye.apply(Ve, arguments), n = this._cmp;
        try {
          t.sort(n);
        } catch {
          return ae(this, ve);
        }
        if (t.length === 0) return Ge(this);
        var r = new this.Collection(this, function() {
          return ke(t[0], t[t.length - 1]);
        });
        r._ondirectionchange = function(i) {
          n = i === "next" ? e._ascending : e._descending, t.sort(n);
        };
        var o = 0;
        return r._addAlgorithm(function(i, a, u) {
          for (var c = i.key; 0 < n(c, t[o]); ) if (++o === t.length) return a(u), !1;
          return n(c, t[o]) === 0 || (a(function() {
            i.continue(t[o]);
          }), !1);
        }), r;
      }, Z.prototype.notEqual = function(e) {
        return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], { includeLowers: !1, includeUppers: !1 });
      }, Z.prototype.noneOf = function() {
        var e = ye.apply(Ve, arguments);
        if (e.length === 0) return new this.Collection(this);
        try {
          e.sort(this._ascending);
        } catch {
          return ae(this, ve);
        }
        var t = e.reduce(function(n, r) {
          return n ? n.concat([[n[n.length - 1][1], r]]) : [[-1 / 0, r]];
        }, null);
        return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, { includeLowers: !1, includeUppers: !1 });
      }, Z.prototype.inAnyRange = function(m, t) {
        var n = this, r = this._cmp, o = this._ascending, i = this._descending, a = this._min, u = this._max;
        if (m.length === 0) return Ge(this);
        if (!m.every(function(g) {
          return g[0] !== void 0 && g[1] !== void 0 && o(g[0], g[1]) <= 0;
        })) return ae(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", q.InvalidArgument);
        var c = !t || t.includeLowers !== !1, l = t && t.includeUppers === !0, p, s = o;
        function v(g, b) {
          return s(g[0], b[0]);
        }
        try {
          (p = m.reduce(function(g, b) {
            for (var w = 0, S = g.length; w < S; ++w) {
              var E = g[w];
              if (r(b[0], E[1]) < 0 && 0 < r(b[1], E[0])) {
                E[0] = a(E[0], b[0]), E[1] = u(E[1], b[1]);
                break;
              }
            }
            return w === S && g.push(b), g;
          }, [])).sort(v);
        } catch {
          return ae(this, ve);
        }
        var f = 0, d = l ? function(g) {
          return 0 < o(g, p[f][1]);
        } : function(g) {
          return 0 <= o(g, p[f][1]);
        }, h = c ? function(g) {
          return 0 < i(g, p[f][0]);
        } : function(g) {
          return 0 <= i(g, p[f][0]);
        }, y = d, m = new this.Collection(this, function() {
          return ke(p[0][0], p[p.length - 1][1], !c, !l);
        });
        return m._ondirectionchange = function(g) {
          s = g === "next" ? (y = d, o) : (y = h, i), p.sort(v);
        }, m._addAlgorithm(function(g, b, w) {
          for (var S, E = g.key; y(E); ) if (++f === p.length) return b(w), !1;
          return !d(S = E) && !h(S) || (n._cmp(E, p[f][1]) === 0 || n._cmp(E, p[f][0]) === 0 || b(function() {
            s === o ? g.continue(p[f][0]) : g.continue(p[f][1]);
          }), !1);
        }), m;
      }, Z.prototype.startsWithAnyOf = function() {
        var e = ye.apply(Ve, arguments);
        return e.every(function(t) {
          return typeof t == "string";
        }) ? e.length === 0 ? Ge(this) : this.inAnyRange(e.map(function(t) {
          return [t, t + Ae];
        })) : ae(this, "startsWithAnyOf() only works with strings");
      }, Z);
      function Z() {
      }
      function de(e) {
        return H(function(t) {
          return st(t), e(t.target.error), !1;
        });
      }
      function st(e) {
        e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
      }
      var ct = "storagemutated", yn = "x-storagemutated-1", Pe = at(null, ct), Xr = (he.prototype._lock = function() {
        return Je(!T.global), ++this._reculock, this._reculock !== 1 || T.global || (T.lockOwnerFor = this), this;
      }, he.prototype._unlock = function() {
        if (Je(!T.global), --this._reculock == 0) for (T.global || (T.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked(); ) {
          var e = this._blockedFuncs.shift();
          try {
            Ce(e[1], e[0]);
          } catch {
          }
        }
        return this;
      }, he.prototype._locked = function() {
        return this._reculock && T.lockOwnerFor !== this;
      }, he.prototype.create = function(e) {
        var t = this;
        if (!this.mode) return this;
        var n = this.db.idbdb, r = this.db._state.dbOpenError;
        if (Je(!this.idbtrans), !e && !n) switch (r && r.name) {
          case "DatabaseClosedError":
            throw new q.DatabaseClosed(r);
          case "MissingAPIError":
            throw new q.MissingAPI(r.message, r);
          default:
            throw new q.OpenFailed(r);
        }
        if (!this.active) throw new q.TransactionInactive();
        return Je(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = H(function(o) {
          st(o), t._reject(e.error);
        }), e.onabort = H(function(o) {
          st(o), t.active && t._reject(new q.Abort(e.error)), t.active = !1, t.on("abort").fire(o);
        }), e.oncomplete = H(function() {
          t.active = !1, t._resolve(), "mutatedParts" in e && Pe.storagemutated.fire(e.mutatedParts);
        }), this;
      }, he.prototype._promise = function(e, t, n) {
        var r = this;
        if (e === "readwrite" && this.mode !== "readwrite") return G(new q.ReadOnly("Transaction is readonly"));
        if (!this.active) return G(new q.TransactionInactive());
        if (this._locked()) return new I(function(i, a) {
          r._blockedFuncs.push([function() {
            r._promise(e, t, n).then(i, a);
          }, T]);
        });
        if (n) return we(function() {
          var i = new I(function(a, u) {
            r._lock();
            var c = t(a, u, r);
            c && c.then && c.then(a, u);
          });
          return i.finally(function() {
            return r._unlock();
          }), i._lib = !0, i;
        });
        var o = new I(function(i, a) {
          var u = t(i, a, r);
          u && u.then && u.then(i, a);
        });
        return o._lib = !0, o;
      }, he.prototype._root = function() {
        return this.parent ? this.parent._root() : this;
      }, he.prototype.waitFor = function(e) {
        var t, n = this._root(), r = I.resolve(e);
        n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
          return r;
        }) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), (function i() {
          for (++n._spinCount; n._waitingQueue.length; ) n._waitingQueue.shift()();
          n._waitingFor && (t.get(-1 / 0).onsuccess = i);
        })());
        var o = n._waitingFor;
        return new I(function(i, a) {
          r.then(function(u) {
            return n._waitingQueue.push(H(i.bind(null, u)));
          }, function(u) {
            return n._waitingQueue.push(H(a.bind(null, u)));
          }).finally(function() {
            n._waitingFor === o && (n._waitingFor = null);
          });
        });
      }, he.prototype.abort = function() {
        this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new q.Abort()));
      }, he.prototype.table = function(e) {
        var t = this._memoizedTables || (this._memoizedTables = {});
        if (oe(t, e)) return t[e];
        var n = this.schema[e];
        if (!n) throw new q.NotFound("Table " + e + " not part of transaction");
        return n = new this.db.Table(e, n, this), n.core = this.db.core.table(e), t[e] = n;
      }, he);
      function he() {
      }
      function vn(e, t, n, r, o, i, a, u) {
        return { name: e, keyPath: t, unique: n, multi: r, auto: o, compound: i, src: (n && !a ? "&" : "") + (r ? "*" : "") + (o ? "++" : "") + dr(t), type: u };
      }
      function dr(e) {
        return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
      }
      function mn(e, t, n) {
        return { name: e, primKey: t, indexes: n, mappedClass: null, idxByName: (r = function(o) {
          return [o.name, o];
        }, n.reduce(function(o, i, a) {
          return a = r(i, a), a && (o[a[0]] = a[1]), o;
        }, {})) };
        var r;
      }
      var lt = function(e) {
        try {
          return e.only([[]]), lt = function() {
            return [[]];
          }, [[]];
        } catch {
          return lt = function() {
            return Ae;
          }, Ae;
        }
      };
      function gn(e) {
        return e == null ? function() {
        } : typeof e == "string" ? (t = e).split(".").length === 1 ? function(n) {
          return n[t];
        } : function(n) {
          return pe(n, t);
        } : function(n) {
          return pe(n, e);
        };
        var t;
      }
      function hr(e) {
        return [].slice.call(e);
      }
      var Jr = 0;
      function ft(e) {
        return e == null ? ":id" : typeof e == "string" ? e : "[".concat(e.join("+"), "]");
      }
      function Zr(e, t, c) {
        function r(y) {
          if (y.type === 3) return null;
          if (y.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
          var f = y.lower, d = y.upper, h = y.lowerOpen, y = y.upperOpen;
          return f === void 0 ? d === void 0 ? null : t.upperBound(d, !!y) : d === void 0 ? t.lowerBound(f, !!h) : t.bound(f, d, !!h, !!y);
        }
        function o(v) {
          var f, d = v.name;
          return { name: d, schema: v, mutate: function(h) {
            var y = h.trans, m = h.type, g = h.keys, b = h.values, w = h.range;
            return new Promise(function(S, E) {
              S = H(S);
              var P = y.objectStore(d), O = P.keyPath == null, K = m === "put" || m === "add";
              if (!K && m !== "delete" && m !== "deleteRange") throw new Error("Invalid operation type: " + m);
              var j, D = (g || b || { length: 1 }).length;
              if (g && b && g.length !== b.length) throw new Error("Given keys array must have same length as given values array.");
              if (D === 0) return S({ numFailures: 0, failures: {}, results: [], lastResult: void 0 });
              function R(re) {
                ++ue, st(re);
              }
              var N = [], M = [], ue = 0;
              if (m === "deleteRange") {
                if (w.type === 4) return S({ numFailures: ue, failures: M, results: [], lastResult: void 0 });
                w.type === 3 ? N.push(j = P.clear()) : N.push(j = P.delete(r(w)));
              } else {
                var O = K ? O ? [b, g] : [b, null] : [g, null], B = O[0], te = O[1];
                if (K) for (var ne = 0; ne < D; ++ne) N.push(j = te && te[ne] !== void 0 ? P[m](B[ne], te[ne]) : P[m](B[ne])), j.onerror = R;
                else for (ne = 0; ne < D; ++ne) N.push(j = P[m](B[ne])), j.onerror = R;
              }
              function Ut(re) {
                re = re.target.result, N.forEach(function(Ne, Bn) {
                  return Ne.error != null && (M[Bn] = Ne.error);
                }), S({ numFailures: ue, failures: M, results: m === "delete" ? g : N.map(function(Ne) {
                  return Ne.result;
                }), lastResult: re });
              }
              j.onerror = function(re) {
                R(re), Ut(re);
              }, j.onsuccess = Ut;
            });
          }, getMany: function(h) {
            var y = h.trans, m = h.keys;
            return new Promise(function(g, b) {
              g = H(g);
              for (var w, S = y.objectStore(d), E = m.length, P = new Array(E), O = 0, K = 0, j = function(N) {
                N = N.target, P[N._pos] = N.result, ++K === O && g(P);
              }, D = de(b), R = 0; R < E; ++R) m[R] != null && ((w = S.get(m[R]))._pos = R, w.onsuccess = j, w.onerror = D, ++O);
              O === 0 && g(P);
            });
          }, get: function(h) {
            var y = h.trans, m = h.key;
            return new Promise(function(g, b) {
              g = H(g);
              var w = y.objectStore(d).get(m);
              w.onsuccess = function(S) {
                return g(S.target.result);
              }, w.onerror = de(b);
            });
          }, query: (f = l, function(h) {
            return new Promise(function(y, m) {
              y = H(y);
              var g, b, w, O = h.trans, S = h.values, E = h.limit, j = h.query, P = E === 1 / 0 ? void 0 : E, K = j.index, j = j.range, O = O.objectStore(d), K = K.isPrimaryKey ? O : O.index(K.name), j = r(j);
              if (E === 0) return y({ result: [] });
              f ? ((P = S ? K.getAll(j, P) : K.getAllKeys(j, P)).onsuccess = function(D) {
                return y({ result: D.target.result });
              }, P.onerror = de(m)) : (g = 0, b = !S && "openKeyCursor" in K ? K.openKeyCursor(j) : K.openCursor(j), w = [], b.onsuccess = function(D) {
                var R = b.result;
                return R ? (w.push(S ? R.value : R.primaryKey), ++g === E ? y({ result: w }) : void R.continue()) : y({ result: w });
              }, b.onerror = de(m));
            });
          }), openCursor: function(h) {
            var y = h.trans, m = h.values, g = h.query, b = h.reverse, w = h.unique;
            return new Promise(function(S, E) {
              S = H(S);
              var K = g.index, P = g.range, O = y.objectStore(d), O = K.isPrimaryKey ? O : O.index(K.name), K = b ? w ? "prevunique" : "prev" : w ? "nextunique" : "next", j = !m && "openKeyCursor" in O ? O.openKeyCursor(r(P), K) : O.openCursor(r(P), K);
              j.onerror = de(E), j.onsuccess = H(function(D) {
                var R, N, M, ue, B = j.result;
                B ? (B.___id = ++Jr, B.done = !1, R = B.continue.bind(B), N = (N = B.continuePrimaryKey) && N.bind(B), M = B.advance.bind(B), ue = function() {
                  throw new Error("Cursor not stopped");
                }, B.trans = y, B.stop = B.continue = B.continuePrimaryKey = B.advance = function() {
                  throw new Error("Cursor not started");
                }, B.fail = H(E), B.next = function() {
                  var te = this, ne = 1;
                  return this.start(function() {
                    return ne-- ? te.continue() : te.stop();
                  }).then(function() {
                    return te;
                  });
                }, B.start = function(te) {
                  function ne() {
                    if (j.result) try {
                      te();
                    } catch (re) {
                      B.fail(re);
                    }
                    else B.done = !0, B.start = function() {
                      throw new Error("Cursor behind last entry");
                    }, B.stop();
                  }
                  var Ut = new Promise(function(re, Ne) {
                    re = H(re), j.onerror = de(Ne), B.fail = Ne, B.stop = function(Bn) {
                      B.stop = B.continue = B.continuePrimaryKey = B.advance = ue, re(Bn);
                    };
                  });
                  return j.onsuccess = H(function(re) {
                    j.onsuccess = ne, ne();
                  }), B.continue = R, B.continuePrimaryKey = N, B.advance = M, ne(), Ut;
                }, S(B)) : S(null);
              }, E);
            });
          }, count: function(h) {
            var y = h.query, m = h.trans, g = y.index, b = y.range;
            return new Promise(function(w, S) {
              var E = m.objectStore(d), P = g.isPrimaryKey ? E : E.index(g.name), E = r(b), P = E ? P.count(E) : P.count();
              P.onsuccess = H(function(O) {
                return w(O.target.result);
              }), P.onerror = de(S);
            });
          } };
        }
        var i, a, u, p = (a = c, u = hr((i = e).objectStoreNames), { schema: { name: i.name, tables: u.map(function(v) {
          return a.objectStore(v);
        }).map(function(v) {
          var f = v.keyPath, y = v.autoIncrement, d = C(f), h = {}, y = { name: v.name, primaryKey: { name: null, isPrimaryKey: !0, outbound: f == null, compound: d, keyPath: f, autoIncrement: y, unique: !0, extractKey: gn(f) }, indexes: hr(v.indexNames).map(function(m) {
            return v.index(m);
          }).map(function(w) {
            var g = w.name, b = w.unique, S = w.multiEntry, w = w.keyPath, S = { name: g, compound: C(w), keyPath: w, unique: b, multiEntry: S, extractKey: gn(w) };
            return h[ft(w)] = S;
          }), getIndexByKeyPath: function(m) {
            return h[ft(m)];
          } };
          return h[":id"] = y.primaryKey, f != null && (h[ft(f)] = y.primaryKey), y;
        }) }, hasGetAll: 0 < u.length && "getAll" in a.objectStore(u[0]) && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) }), c = p.schema, l = p.hasGetAll, p = c.tables.map(o), s = {};
        return p.forEach(function(v) {
          return s[v.name] = v;
        }), { stack: "dbcore", transaction: e.transaction.bind(e), table: function(v) {
          if (!s[v]) throw new Error("Table '".concat(v, "' not found"));
          return s[v];
        }, MIN_KEY: -1 / 0, MAX_KEY: lt(t), schema: c };
      }
      function eo(e, t, n, r) {
        var o = n.IDBKeyRange;
        return n.indexedDB, { dbcore: (r = Zr(t, o, r), e.dbcore.reduce(function(i, a) {
          return a = a.create, x(x({}, i), a(i));
        }, r)) };
      }
      function Tt(e, r) {
        var n = r.db, r = eo(e._middlewares, n, e._deps, r);
        e.core = r.dbcore, e.tables.forEach(function(o) {
          var i = o.name;
          e.core.schema.tables.some(function(a) {
            return a.name === i;
          }) && (o.core = e.core.table(i), e[i] instanceof e.Table && (e[i].core = o.core));
        });
      }
      function Ct(e, t, n, r) {
        n.forEach(function(o) {
          var i = r[o];
          t.forEach(function(a) {
            var u = (function c(l, p) {
              return Dr(l, p) || (l = X(l)) && c(l, p);
            })(a, o);
            (!u || "value" in u && u.value === void 0) && (a === e.Transaction.prototype || a instanceof e.Transaction ? ge(a, o, { get: function() {
              return this.table(o);
            }, set: function(c) {
              Mn(this, o, { value: c, writable: !0, configurable: !0, enumerable: !0 });
            } }) : a[o] = new e.Table(o, i));
          });
        });
      }
      function bn(e, t) {
        t.forEach(function(n) {
          for (var r in n) n[r] instanceof e.Table && delete n[r];
        });
      }
      function to(e, t) {
        return e._cfg.version - t._cfg.version;
      }
      function no(e, t, n, r) {
        var o = e._dbSchema;
        n.objectStoreNames.contains("$meta") && !o.$meta && (o.$meta = mn("$meta", yr("")[0], []), e._storeNames.push("$meta"));
        var i = e._createTransaction("readwrite", e._storeNames, o);
        i.create(n), i._completion.catch(r);
        var a = i._reject.bind(i), u = T.transless || T;
        we(function() {
          return T.trans = i, T.transless = u, t !== 0 ? (Tt(e, n), l = t, ((c = i).storeNames.includes("$meta") ? c.table("$meta").get("version").then(function(p) {
            return p ?? l;
          }) : I.resolve(l)).then(function(p) {
            return v = p, f = i, d = n, h = [], p = (s = e)._versions, y = s._dbSchema = qt(0, s.idbdb, d), (p = p.filter(function(m) {
              return m._cfg.version >= v;
            })).length !== 0 ? (p.forEach(function(m) {
              h.push(function() {
                var g = y, b = m._cfg.dbschema;
                Bt(s, g, d), Bt(s, b, d), y = s._dbSchema = b;
                var w = wn(g, b);
                w.add.forEach(function(K) {
                  _n(d, K[0], K[1].primKey, K[1].indexes);
                }), w.change.forEach(function(K) {
                  if (K.recreate) throw new q.Upgrade("Not yet support for changing primary key");
                  var j = d.objectStore(K.name);
                  K.add.forEach(function(D) {
                    return At(j, D);
                  }), K.change.forEach(function(D) {
                    j.deleteIndex(D.name), At(j, D);
                  }), K.del.forEach(function(D) {
                    return j.deleteIndex(D);
                  });
                });
                var S = m._cfg.contentUpgrade;
                if (S && m._cfg.version > v) {
                  Tt(s, d), f._memoizedTables = {};
                  var E = Ln(b);
                  w.del.forEach(function(K) {
                    E[K] = g[K];
                  }), bn(s, [s.Transaction.prototype]), Ct(s, [s.Transaction.prototype], $(E), E), f.schema = E;
                  var P, O = Zt(S);
                  return O && Ye(), w = I.follow(function() {
                    var K;
                    (P = S(f)) && O && (K = _e.bind(null, null), P.then(K, K));
                  }), P && typeof P.then == "function" ? I.resolve(P) : w.then(function() {
                    return P;
                  });
                }
              }), h.push(function(g) {
                var b, w, S = m._cfg.dbschema;
                b = S, w = g, [].slice.call(w.db.objectStoreNames).forEach(function(E) {
                  return b[E] == null && w.db.deleteObjectStore(E);
                }), bn(s, [s.Transaction.prototype]), Ct(s, [s.Transaction.prototype], s._storeNames, s._dbSchema), f.schema = s._dbSchema;
              }), h.push(function(g) {
                s.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(s.idbdb.version / 10) === m._cfg.version ? (s.idbdb.deleteObjectStore("$meta"), delete s._dbSchema.$meta, s._storeNames = s._storeNames.filter(function(b) {
                  return b !== "$meta";
                })) : g.objectStore("$meta").put(m._cfg.version, "version"));
              });
            }), (function m() {
              return h.length ? I.resolve(h.shift()(f.idbtrans)).then(m) : I.resolve();
            })().then(function() {
              pr(y, d);
            })) : I.resolve();
            var s, v, f, d, h, y;
          }).catch(a)) : ($(o).forEach(function(p) {
            _n(n, p, o[p].primKey, o[p].indexes);
          }), Tt(e, n), void I.follow(function() {
            return e.on.populate.fire(i);
          }).catch(a));
          var c, l;
        });
      }
      function ro(e, t) {
        pr(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
        var n = qt(0, e.idbdb, t);
        Bt(e, e._dbSchema, t);
        for (var r = 0, o = wn(n, e._dbSchema).change; r < o.length; r++) {
          var i = (function(a) {
            if (a.change.length || a.recreate) return console.warn("Unable to patch indexes of table ".concat(a.name, " because it has changes on the type of index or primary key.")), { value: void 0 };
            var u = t.objectStore(a.name);
            a.add.forEach(function(c) {
              fe && console.debug("Dexie upgrade patch: Creating missing index ".concat(a.name, ".").concat(c.src)), At(u, c);
            });
          })(o[r]);
          if (typeof i == "object") return i.value;
        }
      }
      function wn(e, t) {
        var n, r = { del: [], add: [], change: [] };
        for (n in e) t[n] || r.del.push(n);
        for (n in t) {
          var o = e[n], i = t[n];
          if (o) {
            var a = { name: n, def: i, recreate: !1, del: [], add: [], change: [] };
            if ("" + (o.primKey.keyPath || "") != "" + (i.primKey.keyPath || "") || o.primKey.auto !== i.primKey.auto) a.recreate = !0, r.change.push(a);
            else {
              var u = o.idxByName, c = i.idxByName, l = void 0;
              for (l in u) c[l] || a.del.push(l);
              for (l in c) {
                var p = u[l], s = c[l];
                p ? p.src !== s.src && a.change.push(s) : a.add.push(s);
              }
              (0 < a.del.length || 0 < a.add.length || 0 < a.change.length) && r.change.push(a);
            }
          } else r.add.push([n, i]);
        }
        return r;
      }
      function _n(e, t, n, r) {
        var o = e.db.createObjectStore(t, n.keyPath ? { keyPath: n.keyPath, autoIncrement: n.auto } : { autoIncrement: n.auto });
        return r.forEach(function(i) {
          return At(o, i);
        }), o;
      }
      function pr(e, t) {
        $(e).forEach(function(n) {
          t.db.objectStoreNames.contains(n) || (fe && console.debug("Dexie: Creating missing table", n), _n(t, n, e[n].primKey, e[n].indexes));
        });
      }
      function At(e, t) {
        e.createIndex(t.name, t.keyPath, { unique: t.unique, multiEntry: t.multi });
      }
      function qt(e, t, n) {
        var r = {};
        return yt(t.objectStoreNames, 0).forEach(function(o) {
          for (var i = n.objectStore(o), a = vn(dr(l = i.keyPath), l || "", !0, !1, !!i.autoIncrement, l && typeof l != "string", !0), u = [], c = 0; c < i.indexNames.length; ++c) {
            var p = i.index(i.indexNames[c]), l = p.keyPath, p = vn(p.name, l, !!p.unique, !!p.multiEntry, !1, l && typeof l != "string", !1);
            u.push(p);
          }
          r[o] = mn(o, a, u);
        }), r;
      }
      function Bt(e, t, n) {
        for (var r = n.db.objectStoreNames, o = 0; o < r.length; ++o) {
          var i = r[o], a = n.objectStore(i);
          e._hasGetAll = "getAll" in a;
          for (var u = 0; u < a.indexNames.length; ++u) {
            var c = a.indexNames[u], l = a.index(c).keyPath, p = typeof l == "string" ? l : "[" + yt(l).join("+") + "]";
            !t[i] || (l = t[i].idxByName[p]) && (l.name = c, delete t[i].idxByName[p], t[i].idxByName[c] = l);
          }
        }
        typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && U.WorkerGlobalScope && U instanceof U.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
      }
      function yr(e) {
        return e.split(",").map(function(t, n) {
          var i = t.split(":"), r = (o = i[1]) === null || o === void 0 ? void 0 : o.trim(), o = (t = i[0].trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(o) ? o.match(/^\[(.*)\]$/)[1].split("+") : o;
          return vn(o, i || null, /\&/.test(t), /\*/.test(t), /\+\+/.test(t), C(i), n === 0, r);
        });
      }
      var oo = (Qe.prototype._createTableSchema = mn, Qe.prototype._parseIndexSyntax = yr, Qe.prototype._parseStoresSpec = function(e, t) {
        var n = this;
        $(e).forEach(function(r) {
          if (e[r] !== null) {
            var o = n._parseIndexSyntax(e[r]), i = o.shift();
            if (!i) throw new q.Schema("Invalid schema for table " + r + ": " + e[r]);
            if (i.unique = !0, i.multi) throw new q.Schema("Primary key cannot be multiEntry*");
            o.forEach(function(a) {
              if (a.auto) throw new q.Schema("Only primary key can be marked as autoIncrement (++)");
              if (!a.keyPath) throw new q.Schema("Index must have a name and cannot be an empty string");
            }), o = n._createTableSchema(r, i, o), t[r] = o;
          }
        });
      }, Qe.prototype.stores = function(n) {
        var t = this.db;
        this._cfg.storesSource = this._cfg.storesSource ? A(this._cfg.storesSource, n) : n;
        var n = t._versions, r = {}, o = {};
        return n.forEach(function(i) {
          A(r, i._cfg.storesSource), o = i._cfg.dbschema = {}, i._parseStoresSpec(r, o);
        }), t._dbSchema = o, bn(t, [t._allTables, t, t.Transaction.prototype]), Ct(t, [t._allTables, t, t.Transaction.prototype, this._cfg.tables], $(o), o), t._storeNames = $(o), this;
      }, Qe.prototype.upgrade = function(e) {
        return this._cfg.contentUpgrade = tn(this._cfg.contentUpgrade || z, e), this;
      }, Qe);
      function Qe() {
      }
      function xn(e, t) {
        var n = e._dbNamesDB;
        return n || (n = e._dbNamesDB = new me(Ot, { addons: [], indexedDB: e, IDBKeyRange: t })).version(1).stores({ dbnames: "name" }), n.table("dbnames");
      }
      function kn(e) {
        return e && typeof e.databases == "function";
      }
      function Pn(e) {
        return we(function() {
          return T.letThrough = !0, e();
        });
      }
      function Sn(e) {
        return !("from" in e);
      }
      var ee = function(e, t) {
        if (!this) {
          var n = new ee();
          return e && "d" in e && A(n, e), n;
        }
        A(this, arguments.length ? { d: 1, from: e, to: 1 < arguments.length ? t : e } : { d: 0 });
      };
      function dt(e, t, n) {
        var r = F(t, n);
        if (!isNaN(r)) {
          if (0 < r) throw RangeError();
          if (Sn(e)) return A(e, { from: t, to: n, d: 1 });
          var o = e.l, r = e.r;
          if (F(n, e.from) < 0) return o ? dt(o, t, n) : e.l = { from: t, to: n, d: 1, l: null, r: null }, mr(e);
          if (0 < F(t, e.to)) return r ? dt(r, t, n) : e.r = { from: t, to: n, d: 1, l: null, r: null }, mr(e);
          F(t, e.from) < 0 && (e.from = t, e.l = null, e.d = r ? r.d + 1 : 1), 0 < F(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), n = !e.r, o && !e.l && ht(e, o), r && n && ht(e, r);
        }
      }
      function ht(e, t) {
        Sn(t) || (function n(r, c) {
          var i = c.from, a = c.to, u = c.l, c = c.r;
          dt(r, i, a), u && n(r, u), c && n(r, c);
        })(e, t);
      }
      function vr(e, t) {
        var n = Rt(t), r = n.next();
        if (r.done) return !1;
        for (var o = r.value, i = Rt(e), a = i.next(o.from), u = a.value; !r.done && !a.done; ) {
          if (F(u.from, o.to) <= 0 && 0 <= F(u.to, o.from)) return !0;
          F(o.from, u.from) < 0 ? o = (r = n.next(u.from)).value : u = (a = i.next(o.from)).value;
        }
        return !1;
      }
      function Rt(e) {
        var t = Sn(e) ? null : { s: 0, n: e };
        return { next: function(n) {
          for (var r = 0 < arguments.length; t; ) switch (t.s) {
            case 0:
              if (t.s = 1, r) for (; t.n.l && F(n, t.n.from) < 0; ) t = { up: t, n: t.n.l, s: 1 };
              else for (; t.n.l; ) t = { up: t, n: t.n.l, s: 1 };
            case 1:
              if (t.s = 2, !r || F(n, t.n.to) <= 0) return { value: t.n, done: !1 };
            case 2:
              if (t.n.r) {
                t.s = 3, t = { up: t, n: t.n.r, s: 0 };
                continue;
              }
            case 3:
              t = t.up;
          }
          return { done: !0 };
        } };
      }
      function mr(e) {
        var t, n, r = (((t = e.r) === null || t === void 0 ? void 0 : t.d) || 0) - (((n = e.l) === null || n === void 0 ? void 0 : n.d) || 0), o = 1 < r ? "r" : r < -1 ? "l" : "";
        o && (t = o == "r" ? "l" : "r", n = x({}, e), r = e[o], e.from = r.from, e.to = r.to, e[o] = r[o], n[o] = r[t], (e[t] = n).d = gr(n)), e.d = gr(e);
      }
      function gr(n) {
        var t = n.r, n = n.l;
        return (t ? n ? Math.max(t.d, n.d) : t.d : n ? n.d : 0) + 1;
      }
      function Nt(e, t) {
        return $(t).forEach(function(n) {
          e[n] ? ht(e[n], t[n]) : e[n] = (function r(o) {
            var i, a, u = {};
            for (i in o) oe(o, i) && (a = o[i], u[i] = !a || typeof a != "object" || $n.has(a.constructor) ? a : r(a));
            return u;
          })(t[n]);
        }), e;
      }
      function On(e, t) {
        return e.all || t.all || Object.keys(e).some(function(n) {
          return t[n] && vr(t[n], e[n]);
        });
      }
      Me(ee.prototype, ((ce = { add: function(e) {
        return ht(this, e), this;
      }, addKey: function(e) {
        return dt(this, e, e), this;
      }, addKeys: function(e) {
        var t = this;
        return e.forEach(function(n) {
          return dt(t, n, n);
        }), this;
      }, hasKey: function(e) {
        var t = Rt(this).next(e).value;
        return t && F(t.from, e) <= 0 && 0 <= F(t.to, e);
      } })[Jt] = function() {
        return Rt(this);
      }, ce));
      var Be = {}, jn = {}, En = !1;
      function Mt(e) {
        Nt(jn, e), En || (En = !0, setTimeout(function() {
          En = !1, Kn(jn, !(jn = {}));
        }, 0));
      }
      function Kn(e, t) {
        t === void 0 && (t = !1);
        var n = /* @__PURE__ */ new Set();
        if (e.all) for (var r = 0, o = Object.values(Be); r < o.length; r++) br(a = o[r], e, n, t);
        else for (var i in e) {
          var a, u = /^idb\:\/\/(.*)\/(.*)\//.exec(i);
          u && (i = u[1], u = u[2], (a = Be["idb://".concat(i, "/").concat(u)]) && br(a, e, n, t));
        }
        n.forEach(function(c) {
          return c();
        });
      }
      function br(e, t, n, r) {
        for (var o = [], i = 0, a = Object.entries(e.queries.query); i < a.length; i++) {
          for (var u = a[i], c = u[0], l = [], p = 0, s = u[1]; p < s.length; p++) {
            var v = s[p];
            On(t, v.obsSet) ? v.subscribers.forEach(function(y) {
              return n.add(y);
            }) : r && l.push(v);
          }
          r && o.push([c, l]);
        }
        if (r) for (var f = 0, d = o; f < d.length; f++) {
          var h = d[f], c = h[0], l = h[1];
          e.queries.query[c] = l;
        }
      }
      function io(e) {
        var t = e._state, n = e._deps.indexedDB;
        if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
          return t.dbOpenError ? G(t.dbOpenError) : e;
        });
        t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
        var r = t.openCanceller, o = Math.round(10 * e.verno), i = !1;
        function a() {
          if (t.openCanceller !== r) throw new q.DatabaseClosed("db.open() was cancelled");
        }
        function u() {
          return new I(function(v, f) {
            if (a(), !n) throw new q.MissingAPI();
            var d = e.name, h = t.autoSchema || !o ? n.open(d) : n.open(d, o);
            if (!h) throw new q.MissingAPI();
            h.onerror = de(f), h.onblocked = H(e._fireOnBlocked), h.onupgradeneeded = H(function(y) {
              var m;
              p = h.transaction, t.autoSchema && !e._options.allowEmptyDB ? (h.onerror = st, p.abort(), h.result.close(), (m = n.deleteDatabase(d)).onsuccess = m.onerror = H(function() {
                f(new q.NoSuchDatabase("Database ".concat(d, " doesnt exist")));
              })) : (p.onerror = de(f), y = y.oldVersion > Math.pow(2, 62) ? 0 : y.oldVersion, s = y < 1, e.idbdb = h.result, i && ro(e, p), no(e, y / 10, p, f));
            }, f), h.onsuccess = H(function() {
              p = null;
              var y, m, g, b, w, S = e.idbdb = h.result, E = yt(S.objectStoreNames);
              if (0 < E.length) try {
                var P = S.transaction((b = E).length === 1 ? b[0] : b, "readonly");
                if (t.autoSchema) m = S, g = P, (y = e).verno = m.version / 10, g = y._dbSchema = qt(0, m, g), y._storeNames = yt(m.objectStoreNames, 0), Ct(y, [y._allTables], $(g), g);
                else if (Bt(e, e._dbSchema, P), ((w = wn(qt(0, (w = e).idbdb, P), w._dbSchema)).add.length || w.change.some(function(O) {
                  return O.add.length || O.change.length;
                })) && !i) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), S.close(), o = S.version + 1, i = !0, v(u());
                Tt(e, P);
              } catch {
              }
              We.push(e), S.onversionchange = H(function(O) {
                t.vcFired = !0, e.on("versionchange").fire(O);
              }), S.onclose = H(function() {
                e.close({ disableAutoOpen: !1 });
              }), s && (w = e._deps, P = d, S = w.indexedDB, w = w.IDBKeyRange, kn(S) || P === Ot || xn(S, w).put({ name: P }).catch(z)), v();
            }, f);
          }).catch(function(v) {
            switch (v == null ? void 0 : v.name) {
              case "UnknownError":
                if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), u();
                break;
              case "VersionError":
                if (0 < o) return o = 0, u();
            }
            return I.reject(v);
          });
        }
        var c, l = t.dbReadyResolve, p = null, s = !1;
        return I.race([r, (typeof navigator > "u" ? I.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(v) {
          function f() {
            return indexedDB.databases().finally(v);
          }
          c = setInterval(f, 100), f();
        }).finally(function() {
          return clearInterval(c);
        }) : Promise.resolve()).then(u)]).then(function() {
          return a(), t.onReadyBeingFired = [], I.resolve(Pn(function() {
            return e.on.ready.fire(e.vip);
          })).then(function v() {
            if (0 < t.onReadyBeingFired.length) {
              var f = t.onReadyBeingFired.reduce(tn, z);
              return t.onReadyBeingFired = [], I.resolve(Pn(function() {
                return f(e.vip);
              })).then(v);
            }
          });
        }).finally(function() {
          t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
        }).catch(function(v) {
          t.dbOpenError = v;
          try {
            p && p.abort();
          } catch {
          }
          return r === t.openCanceller && e._close(), G(v);
        }).finally(function() {
          t.openComplete = !0, l();
        }).then(function() {
          var v;
          return s && (v = {}, e.tables.forEach(function(f) {
            f.schema.indexes.forEach(function(d) {
              d.name && (v["idb://".concat(e.name, "/").concat(f.name, "/").concat(d.name)] = new ee(-1 / 0, [[[]]]));
            }), v["idb://".concat(e.name, "/").concat(f.name, "/")] = v["idb://".concat(e.name, "/").concat(f.name, "/:dels")] = new ee(-1 / 0, [[[]]]);
          }), Pe(ct).fire(v), Kn(v, !0)), e;
        });
      }
      function In(e) {
        function t(i) {
          return e.next(i);
        }
        var n = o(t), r = o(function(i) {
          return e.throw(i);
        });
        function o(i) {
          return function(c) {
            var u = i(c), c = u.value;
            return u.done ? c : c && typeof c.then == "function" ? c.then(n, r) : C(c) ? Promise.all(c).then(n, r) : n(c);
          };
        }
        return o(t)();
      }
      function Ft(e, t, n) {
        for (var r = C(e) ? e.slice() : [e], o = 0; o < n; ++o) r.push(t);
        return r;
      }
      var ao = { stack: "dbcore", name: "VirtualIndexMiddleware", level: 1, create: function(e) {
        return x(x({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema, o = {}, i = [];
          function a(s, v, f) {
            var d = ft(s), h = o[d] = o[d] || [], y = s == null ? 0 : typeof s == "string" ? 1 : s.length, m = 0 < v, m = x(x({}, f), { name: m ? "".concat(d, "(virtual-from:").concat(f.name, ")") : f.name, lowLevelIndex: f, isVirtual: m, keyTail: v, keyLength: y, extractKey: gn(s), unique: !m && f.unique });
            return h.push(m), m.isPrimaryKey || i.push(m), 1 < y && a(y === 2 ? s[0] : s.slice(0, y - 1), v + 1, f), h.sort(function(g, b) {
              return g.keyTail - b.keyTail;
            }), m;
          }
          t = a(r.primaryKey.keyPath, 0, r.primaryKey), o[":id"] = [t];
          for (var u = 0, c = r.indexes; u < c.length; u++) {
            var l = c[u];
            a(l.keyPath, 0, l);
          }
          function p(s) {
            var v, f = s.query.index;
            return f.isVirtual ? x(x({}, s), { query: { index: f.lowLevelIndex, range: (v = s.query.range, f = f.keyTail, { type: v.type === 1 ? 2 : v.type, lower: Ft(v.lower, v.lowerOpen ? e.MAX_KEY : e.MIN_KEY, f), lowerOpen: !0, upper: Ft(v.upper, v.upperOpen ? e.MIN_KEY : e.MAX_KEY, f), upperOpen: !0 }) } }) : s;
          }
          return x(x({}, n), { schema: x(x({}, r), { primaryKey: t, indexes: i, getIndexByKeyPath: function(s) {
            return (s = o[ft(s)]) && s[0];
          } }), count: function(s) {
            return n.count(p(s));
          }, query: function(s) {
            return n.query(p(s));
          }, openCursor: function(s) {
            var v = s.query.index, f = v.keyTail, d = v.isVirtual, h = v.keyLength;
            return d ? n.openCursor(p(s)).then(function(m) {
              return m && y(m);
            }) : n.openCursor(s);
            function y(m) {
              return Object.create(m, { continue: { value: function(g) {
                g != null ? m.continue(Ft(g, s.reverse ? e.MAX_KEY : e.MIN_KEY, f)) : s.unique ? m.continue(m.key.slice(0, h).concat(s.reverse ? e.MIN_KEY : e.MAX_KEY, f)) : m.continue();
              } }, continuePrimaryKey: { value: function(g, b) {
                m.continuePrimaryKey(Ft(g, e.MAX_KEY, f), b);
              } }, primaryKey: { get: function() {
                return m.primaryKey;
              } }, key: { get: function() {
                var g = m.key;
                return h === 1 ? g[0] : g.slice(0, h);
              } }, value: { get: function() {
                return m.value;
              } } });
            }
          } });
        } });
      } };
      function Dn(e, t, n, r) {
        return n = n || {}, r = r || "", $(e).forEach(function(o) {
          var i, a, u;
          oe(t, o) ? (i = e[o], a = t[o], typeof i == "object" && typeof a == "object" && i && a ? (u = Xt(i)) !== Xt(a) ? n[r + o] = t[o] : u === "Object" ? Dn(i, a, n, r + o + ".") : i !== a && (n[r + o] = t[o]) : i !== a && (n[r + o] = t[o])) : n[r + o] = void 0;
        }), $(t).forEach(function(o) {
          oe(e, o) || (n[r + o] = t[o]);
        }), n;
      }
      function Tn(e, t) {
        return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
      }
      var uo = { stack: "dbcore", name: "HooksMiddleware", level: 2, create: function(e) {
        return x(x({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema.primaryKey;
          return x(x({}, n), { mutate: function(o) {
            var i = T.trans, a = i.table(t).hook, u = a.deleting, c = a.creating, l = a.updating;
            switch (o.type) {
              case "add":
                if (c.fire === z) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "put":
                if (c.fire === z && l.fire === z) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "delete":
                if (u.fire === z) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "deleteRange":
                if (u.fire === z) break;
                return i._promise("readwrite", function() {
                  return (function s(v, f, d) {
                    return n.query({ trans: v, values: !1, query: { index: r, range: f }, limit: d }).then(function(h) {
                      var y = h.result;
                      return p({ type: "delete", keys: y, trans: v }).then(function(m) {
                        return 0 < m.numFailures ? Promise.reject(m.failures[0]) : y.length < d ? { failures: [], numFailures: 0, lastResult: void 0 } : s(v, x(x({}, f), { lower: y[y.length - 1], lowerOpen: !0 }), d);
                      });
                    });
                  })(o.trans, o.range, 1e4);
                }, !0);
            }
            return n.mutate(o);
            function p(s) {
              var v, f, d, h = T.trans, y = s.keys || Tn(r, s);
              if (!y) throw new Error("Keys missing");
              return (s = s.type === "add" || s.type === "put" ? x(x({}, s), { keys: y }) : x({}, s)).type !== "delete" && (s.values = W([], s.values)), s.keys && (s.keys = W([], s.keys)), v = n, d = y, ((f = s).type === "add" ? Promise.resolve([]) : v.getMany({ trans: f.trans, keys: d, cache: "immutable" })).then(function(m) {
                var g = y.map(function(b, w) {
                  var S, E, P, O = m[w], K = { onerror: null, onsuccess: null };
                  return s.type === "delete" ? u.fire.call(K, b, O, h) : s.type === "add" || O === void 0 ? (S = c.fire.call(K, b, s.values[w], h), b == null && S != null && (s.keys[w] = b = S, r.outbound || ie(s.values[w], r.keyPath, b))) : (S = Dn(O, s.values[w]), (E = l.fire.call(K, S, b, O, h)) && (P = s.values[w], Object.keys(E).forEach(function(j) {
                    oe(P, j) ? P[j] = E[j] : ie(P, j, E[j]);
                  }))), K;
                });
                return n.mutate(s).then(function(b) {
                  for (var w = b.failures, S = b.results, E = b.numFailures, b = b.lastResult, P = 0; P < y.length; ++P) {
                    var O = (S || y)[P], K = g[P];
                    O == null ? K.onerror && K.onerror(w[P]) : K.onsuccess && K.onsuccess(s.type === "put" && m[P] ? s.values[P] : O);
                  }
                  return { failures: w, results: S, numFailures: E, lastResult: b };
                }).catch(function(b) {
                  return g.forEach(function(w) {
                    return w.onerror && w.onerror(b);
                  }), Promise.reject(b);
                });
              });
            }
          } });
        } });
      } };
      function wr(e, t, n) {
        try {
          if (!t || t.keys.length < e.length) return null;
          for (var r = [], o = 0, i = 0; o < t.keys.length && i < e.length; ++o) F(t.keys[o], e[i]) === 0 && (r.push(n ? Oe(t.values[o]) : t.values[o]), ++i);
          return r.length === e.length ? r : null;
        } catch {
          return null;
        }
      }
      var so = { stack: "dbcore", level: -1, create: function(e) {
        return { table: function(t) {
          var n = e.table(t);
          return x(x({}, n), { getMany: function(r) {
            if (!r.cache) return n.getMany(r);
            var o = wr(r.keys, r.trans._cache, r.cache === "clone");
            return o ? I.resolve(o) : n.getMany(r).then(function(i) {
              return r.trans._cache = { keys: r.keys, values: r.cache === "clone" ? Oe(i) : i }, i;
            });
          }, mutate: function(r) {
            return r.type !== "add" && (r.trans._cache = null), n.mutate(r);
          } });
        } };
      } };
      function _r(e, t) {
        return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
      }
      function xr(e, t) {
        switch (e) {
          case "query":
            return t.values && !t.unique;
          case "get":
          case "getMany":
          case "count":
          case "openCursor":
            return !1;
        }
      }
      var co = { stack: "dbcore", level: 0, name: "Observability", create: function(e) {
        var t = e.schema.name, n = new ee(e.MIN_KEY, e.MAX_KEY);
        return x(x({}, e), { transaction: function(r, o, i) {
          if (T.subscr && o !== "readonly") throw new q.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(T.querier));
          return e.transaction(r, o, i);
        }, table: function(r) {
          var o = e.table(r), i = o.schema, a = i.primaryKey, s = i.indexes, u = a.extractKey, c = a.outbound, l = a.autoIncrement && s.filter(function(f) {
            return f.compound && f.keyPath.includes(a.keyPath);
          }), p = x(x({}, o), { mutate: function(f) {
            function d(j) {
              return j = "idb://".concat(t, "/").concat(r, "/").concat(j), b[j] || (b[j] = new ee());
            }
            var h, y, m, g = f.trans, b = f.mutatedParts || (f.mutatedParts = {}), w = d(""), S = d(":dels"), E = f.type, K = f.type === "deleteRange" ? [f.range] : f.type === "delete" ? [f.keys] : f.values.length < 50 ? [Tn(a, f).filter(function(j) {
              return j;
            }), f.values] : [], P = K[0], O = K[1], K = f.trans._cache;
            return C(P) ? (w.addKeys(P), (K = E === "delete" || P.length === O.length ? wr(P, K) : null) || S.addKeys(P), (K || O) && (h = d, y = K, m = O, i.indexes.forEach(function(j) {
              var D = h(j.name || "");
              function R(M) {
                return M != null ? j.extractKey(M) : null;
              }
              function N(M) {
                return j.multiEntry && C(M) ? M.forEach(function(ue) {
                  return D.addKey(ue);
                }) : D.addKey(M);
              }
              (y || m).forEach(function(M, te) {
                var B = y && R(y[te]), te = m && R(m[te]);
                F(B, te) !== 0 && (B != null && N(B), te != null && N(te));
              });
            }))) : P ? (O = { from: (O = P.lower) !== null && O !== void 0 ? O : e.MIN_KEY, to: (O = P.upper) !== null && O !== void 0 ? O : e.MAX_KEY }, S.add(O), w.add(O)) : (w.add(n), S.add(n), i.indexes.forEach(function(j) {
              return d(j.name).add(n);
            })), o.mutate(f).then(function(j) {
              return !P || f.type !== "add" && f.type !== "put" || (w.addKeys(j.results), l && l.forEach(function(D) {
                for (var R = f.values.map(function(B) {
                  return D.extractKey(B);
                }), N = D.keyPath.findIndex(function(B) {
                  return B === a.keyPath;
                }), M = 0, ue = j.results.length; M < ue; ++M) R[M][N] = j.results[M];
                d(D.name).addKeys(R);
              })), g.mutatedParts = Nt(g.mutatedParts || {}, b), j;
            });
          } }), s = function(d) {
            var h = d.query, d = h.index, h = h.range;
            return [d, new ee((d = h.lower) !== null && d !== void 0 ? d : e.MIN_KEY, (h = h.upper) !== null && h !== void 0 ? h : e.MAX_KEY)];
          }, v = { get: function(f) {
            return [a, new ee(f.key)];
          }, getMany: function(f) {
            return [a, new ee().addKeys(f.keys)];
          }, count: s, query: s, openCursor: s };
          return $(v).forEach(function(f) {
            p[f] = function(d) {
              var h = T.subscr, y = !!h, m = _r(T, o) && xr(f, d) ? d.obsSet = {} : h;
              if (y) {
                var g = function(O) {
                  return O = "idb://".concat(t, "/").concat(r, "/").concat(O), m[O] || (m[O] = new ee());
                }, b = g(""), w = g(":dels"), h = v[f](d), y = h[0], h = h[1];
                if ((f === "query" && y.isPrimaryKey && !d.values ? w : g(y.name || "")).add(h), !y.isPrimaryKey) {
                  if (f !== "count") {
                    var S = f === "query" && c && d.values && o.query(x(x({}, d), { values: !1 }));
                    return o[f].apply(this, arguments).then(function(O) {
                      if (f === "query") {
                        if (c && d.values) return S.then(function(R) {
                          return R = R.result, b.addKeys(R), O;
                        });
                        var K = d.values ? O.result.map(u) : O.result;
                        (d.values ? b : w).addKeys(K);
                      } else if (f === "openCursor") {
                        var j = O, D = d.values;
                        return j && Object.create(j, { key: { get: function() {
                          return w.addKey(j.primaryKey), j.key;
                        } }, primaryKey: { get: function() {
                          var R = j.primaryKey;
                          return w.addKey(R), R;
                        } }, value: { get: function() {
                          return D && b.addKey(j.primaryKey), j.value;
                        } } });
                      }
                      return O;
                    });
                  }
                  w.add(n);
                }
              }
              return o[f].apply(this, arguments);
            };
          }), p;
        } });
      } };
      function kr(e, t, n) {
        if (n.numFailures === 0) return t;
        if (t.type === "deleteRange") return null;
        var r = t.keys ? t.keys.length : "values" in t && t.values ? t.values.length : 1;
        return n.numFailures === r ? null : (t = x({}, t), C(t.keys) && (t.keys = t.keys.filter(function(o, i) {
          return !(i in n.failures);
        })), "values" in t && C(t.values) && (t.values = t.values.filter(function(o, i) {
          return !(i in n.failures);
        })), t);
      }
      function Cn(e, t) {
        return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < F(n, r.lower) : 0 <= F(n, r.lower))) && (e = e, (t = t).upper === void 0 || (t.upperOpen ? F(e, t.upper) < 0 : F(e, t.upper) <= 0));
        var n, r;
      }
      function Pr(e, t, v, r, o, i) {
        if (!v || v.length === 0) return e;
        var a = t.query.index, u = a.multiEntry, c = t.query.range, l = r.schema.primaryKey.extractKey, p = a.extractKey, s = (a.lowLevelIndex || a).extractKey, v = v.reduce(function(f, d) {
          var h = f, y = [];
          if (d.type === "add" || d.type === "put") for (var m = new ee(), g = d.values.length - 1; 0 <= g; --g) {
            var b, w = d.values[g], S = l(w);
            m.hasKey(S) || (b = p(w), (u && C(b) ? b.some(function(j) {
              return Cn(j, c);
            }) : Cn(b, c)) && (m.addKey(S), y.push(w)));
          }
          switch (d.type) {
            case "add":
              var E = new ee().addKeys(t.values ? f.map(function(D) {
                return l(D);
              }) : f), h = f.concat(t.values ? y.filter(function(D) {
                return D = l(D), !E.hasKey(D) && (E.addKey(D), !0);
              }) : y.map(function(D) {
                return l(D);
              }).filter(function(D) {
                return !E.hasKey(D) && (E.addKey(D), !0);
              }));
              break;
            case "put":
              var P = new ee().addKeys(d.values.map(function(D) {
                return l(D);
              }));
              h = f.filter(function(D) {
                return !P.hasKey(t.values ? l(D) : D);
              }).concat(t.values ? y : y.map(function(D) {
                return l(D);
              }));
              break;
            case "delete":
              var O = new ee().addKeys(d.keys);
              h = f.filter(function(D) {
                return !O.hasKey(t.values ? l(D) : D);
              });
              break;
            case "deleteRange":
              var K = d.range;
              h = f.filter(function(D) {
                return !Cn(l(D), K);
              });
          }
          return h;
        }, e);
        return v === e ? e : (v.sort(function(f, d) {
          return F(s(f), s(d)) || F(l(f), l(d));
        }), t.limit && t.limit < 1 / 0 && (v.length > t.limit ? v.length = t.limit : e.length === t.limit && v.length < t.limit && (o.dirty = !0)), i ? Object.freeze(v) : v);
      }
      function Sr(e, t) {
        return F(e.lower, t.lower) === 0 && F(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
      }
      function lo(e, t) {
        return (function(n, r, o, i) {
          if (n === void 0) return r !== void 0 ? -1 : 0;
          if (r === void 0) return 1;
          if ((r = F(n, r)) === 0) {
            if (o && i) return 0;
            if (o) return 1;
            if (i) return -1;
          }
          return r;
        })(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= (function(n, r, o, i) {
          if (n === void 0) return r !== void 0 ? 1 : 0;
          if (r === void 0) return -1;
          if ((r = F(n, r)) === 0) {
            if (o && i) return 0;
            if (o) return -1;
            if (i) return 1;
          }
          return r;
        })(e.upper, t.upper, e.upperOpen, t.upperOpen);
      }
      function fo(e, t, n, r) {
        e.subscribers.add(n), r.addEventListener("abort", function() {
          var o, i;
          e.subscribers.delete(n), e.subscribers.size === 0 && (o = e, i = t, setTimeout(function() {
            o.subscribers.size === 0 && je(i, o);
          }, 3e3));
        });
      }
      var ho = { stack: "dbcore", level: 0, name: "Cache", create: function(e) {
        var t = e.schema.name;
        return x(x({}, e), { transaction: function(n, r, o) {
          var i, a, u = e.transaction(n, r, o);
          return r === "readwrite" && (a = (i = new AbortController()).signal, o = function(c) {
            return function() {
              if (i.abort(), r === "readwrite") {
                for (var l = /* @__PURE__ */ new Set(), p = 0, s = n; p < s.length; p++) {
                  var v = s[p], f = Be["idb://".concat(t, "/").concat(v)];
                  if (f) {
                    var d = e.table(v), h = f.optimisticOps.filter(function(D) {
                      return D.trans === u;
                    });
                    if (u._explicit && c && u.mutatedParts) for (var y = 0, m = Object.values(f.queries.query); y < m.length; y++) for (var g = 0, b = (E = m[y]).slice(); g < b.length; g++) On((P = b[g]).obsSet, u.mutatedParts) && (je(E, P), P.subscribers.forEach(function(D) {
                      return l.add(D);
                    }));
                    else if (0 < h.length) {
                      f.optimisticOps = f.optimisticOps.filter(function(D) {
                        return D.trans !== u;
                      });
                      for (var w = 0, S = Object.values(f.queries.query); w < S.length; w++) for (var E, P, O, K = 0, j = (E = S[w]).slice(); K < j.length; K++) (P = j[K]).res != null && u.mutatedParts && (c && !P.dirty ? (O = Object.isFrozen(P.res), O = Pr(P.res, P.req, h, d, P, O), P.dirty ? (je(E, P), P.subscribers.forEach(function(D) {
                        return l.add(D);
                      })) : O !== P.res && (P.res = O, P.promise = I.resolve({ result: O }))) : (P.dirty && je(E, P), P.subscribers.forEach(function(D) {
                        return l.add(D);
                      })));
                    }
                  }
                }
                l.forEach(function(D) {
                  return D();
                });
              }
            };
          }, u.addEventListener("abort", o(!1), { signal: a }), u.addEventListener("error", o(!1), { signal: a }), u.addEventListener("complete", o(!0), { signal: a })), u;
        }, table: function(n) {
          var r = e.table(n), o = r.schema.primaryKey;
          return x(x({}, r), { mutate: function(i) {
            var a = T.trans;
            if (o.outbound || a.db._options.cache === "disabled" || a.explicit || a.idbtrans.mode !== "readwrite") return r.mutate(i);
            var u = Be["idb://".concat(t, "/").concat(n)];
            return u ? (a = r.mutate(i), i.type !== "add" && i.type !== "put" || !(50 <= i.values.length || Tn(o, i).some(function(c) {
              return c == null;
            })) ? (u.optimisticOps.push(i), i.mutatedParts && Mt(i.mutatedParts), a.then(function(c) {
              0 < c.numFailures && (je(u.optimisticOps, i), (c = kr(0, i, c)) && u.optimisticOps.push(c), i.mutatedParts && Mt(i.mutatedParts));
            }), a.catch(function() {
              je(u.optimisticOps, i), i.mutatedParts && Mt(i.mutatedParts);
            })) : a.then(function(c) {
              var l = kr(0, x(x({}, i), { values: i.values.map(function(p, s) {
                var v;
                return c.failures[s] ? p : (p = (v = o.keyPath) !== null && v !== void 0 && v.includes(".") ? Oe(p) : x({}, p), ie(p, o.keyPath, c.results[s]), p);
              }) }), c);
              u.optimisticOps.push(l), queueMicrotask(function() {
                return i.mutatedParts && Mt(i.mutatedParts);
              });
            }), a) : r.mutate(i);
          }, query: function(i) {
            if (!_r(T, r) || !xr("query", i)) return r.query(i);
            var a = ((l = T.trans) === null || l === void 0 ? void 0 : l.db._options.cache) === "immutable", s = T, u = s.requery, c = s.signal, l = (function(d, h, y, m) {
              var g = Be["idb://".concat(d, "/").concat(h)];
              if (!g) return [];
              if (!(h = g.queries[y])) return [null, !1, g, null];
              var b = h[(m.query ? m.query.index.name : null) || ""];
              if (!b) return [null, !1, g, null];
              switch (y) {
                case "query":
                  var w = b.find(function(S) {
                    return S.req.limit === m.limit && S.req.values === m.values && Sr(S.req.query.range, m.query.range);
                  });
                  return w ? [w, !0, g, b] : [b.find(function(S) {
                    return ("limit" in S.req ? S.req.limit : 1 / 0) >= m.limit && (!m.values || S.req.values) && lo(S.req.query.range, m.query.range);
                  }), !1, g, b];
                case "count":
                  return w = b.find(function(S) {
                    return Sr(S.req.query.range, m.query.range);
                  }), [w, !!w, g, b];
              }
            })(t, n, "query", i), p = l[0], s = l[1], v = l[2], f = l[3];
            return p && s ? p.obsSet = i.obsSet : (s = r.query(i).then(function(d) {
              var h = d.result;
              if (p && (p.res = h), a) {
                for (var y = 0, m = h.length; y < m; ++y) Object.freeze(h[y]);
                Object.freeze(h);
              } else d.result = Oe(h);
              return d;
            }).catch(function(d) {
              return f && p && je(f, p), Promise.reject(d);
            }), p = { obsSet: i.obsSet, promise: s, subscribers: /* @__PURE__ */ new Set(), type: "query", req: i, dirty: !1 }, f ? f.push(p) : (f = [p], (v = v || (Be["idb://".concat(t, "/").concat(n)] = { queries: { query: {}, count: {} }, objs: /* @__PURE__ */ new Map(), optimisticOps: [], unsignaledParts: {} })).queries.query[i.query.index.name || ""] = f)), fo(p, f, u, c), p.promise.then(function(d) {
              return { result: Pr(d.result, i, v == null ? void 0 : v.optimisticOps, r, p, a) };
            });
          } });
        } });
      } };
      function Vt(e, t) {
        return new Proxy(e, { get: function(n, r, o) {
          return r === "db" ? t : Reflect.get(n, r, o);
        } });
      }
      var me = (Q.prototype.version = function(e) {
        if (isNaN(e) || e < 0.1) throw new q.Type("Given version is not a positive number");
        if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new q.Schema("Cannot add version when database is open");
        this.verno = Math.max(this.verno, e);
        var t = this._versions, n = t.filter(function(r) {
          return r._cfg.version === e;
        })[0];
        return n || (n = new this.Version(e), t.push(n), t.sort(to), n.stores({}), this._state.autoSchema = !1, n);
      }, Q.prototype._whenReady = function(e) {
        var t = this;
        return this.idbdb && (this._state.openComplete || T.letThrough || this._vip) ? e() : new I(function(n, r) {
          if (t._state.openComplete) return r(new q.DatabaseClosed(t._state.dbOpenError));
          if (!t._state.isBeingOpened) {
            if (!t._state.autoOpen) return void r(new q.DatabaseClosed());
            t.open().catch(z);
          }
          t._state.dbReadyPromise.then(n, r);
        }).then(e);
      }, Q.prototype.use = function(e) {
        var t = e.stack, n = e.create, r = e.level, o = e.name;
        return o && this.unuse({ stack: t, name: o }), e = this._middlewares[t] || (this._middlewares[t] = []), e.push({ stack: t, create: n, level: r ?? 10, name: o }), e.sort(function(i, a) {
          return i.level - a.level;
        }), this;
      }, Q.prototype.unuse = function(e) {
        var t = e.stack, n = e.name, r = e.create;
        return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(o) {
          return r ? o.create !== r : !!n && o.name !== n;
        })), this;
      }, Q.prototype.open = function() {
        var e = this;
        return Ce(be, function() {
          return io(e);
        });
      }, Q.prototype._close = function() {
        this.on.close.fire(new CustomEvent("close"));
        var e = this._state, t = We.indexOf(this);
        if (0 <= t && We.splice(t, 1), this.idbdb) {
          try {
            this.idbdb.close();
          } catch {
          }
          this.idbdb = null;
        }
        e.isBeingOpened || (e.dbReadyPromise = new I(function(n) {
          e.dbReadyResolve = n;
        }), e.openCanceller = new I(function(n, r) {
          e.cancelOpen = r;
        }));
      }, Q.prototype.close = function(n) {
        var t = (n === void 0 ? { disableAutoOpen: !0 } : n).disableAutoOpen, n = this._state;
        t ? (n.isBeingOpened && n.cancelOpen(new q.DatabaseClosed()), this._close(), n.autoOpen = !1, n.dbOpenError = new q.DatabaseClosed()) : (this._close(), n.autoOpen = this._options.autoOpen || n.isBeingOpened, n.openComplete = !1, n.dbOpenError = null);
      }, Q.prototype.delete = function(e) {
        var t = this;
        e === void 0 && (e = { disableAutoOpen: !0 });
        var n = 0 < arguments.length && typeof arguments[0] != "object", r = this._state;
        return new I(function(o, i) {
          function a() {
            t.close(e);
            var u = t._deps.indexedDB.deleteDatabase(t.name);
            u.onsuccess = H(function() {
              var c, l, p;
              c = t._deps, l = t.name, p = c.indexedDB, c = c.IDBKeyRange, kn(p) || l === Ot || xn(p, c).delete(l).catch(z), o();
            }), u.onerror = de(i), u.onblocked = t._fireOnBlocked;
          }
          if (n) throw new q.InvalidArgument("Invalid closeOptions argument to db.delete()");
          r.isBeingOpened ? r.dbReadyPromise.then(a) : a();
        });
      }, Q.prototype.backendDB = function() {
        return this.idbdb;
      }, Q.prototype.isOpen = function() {
        return this.idbdb !== null;
      }, Q.prototype.hasBeenClosed = function() {
        var e = this._state.dbOpenError;
        return e && e.name === "DatabaseClosed";
      }, Q.prototype.hasFailed = function() {
        return this._state.dbOpenError !== null;
      }, Q.prototype.dynamicallyOpened = function() {
        return this._state.autoSchema;
      }, Object.defineProperty(Q.prototype, "tables", { get: function() {
        var e = this;
        return $(this._allTables).map(function(t) {
          return e._allTables[t];
        });
      }, enumerable: !1, configurable: !0 }), Q.prototype.transaction = function() {
        var e = (function(t, n, r) {
          var o = arguments.length;
          if (o < 2) throw new q.InvalidArgument("Too few arguments");
          for (var i = new Array(o - 1); --o; ) i[o - 1] = arguments[o];
          return r = i.pop(), [t, Un(i), r];
        }).apply(this, arguments);
        return this._transaction.apply(this, e);
      }, Q.prototype._transaction = function(e, t, n) {
        var r = this, o = T.trans;
        o && o.db === this && e.indexOf("!") === -1 || (o = null);
        var i, a, u = e.indexOf("?") !== -1;
        e = e.replace("!", "").replace("?", "");
        try {
          if (a = t.map(function(l) {
            if (l = l instanceof r.Table ? l.name : l, typeof l != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
            return l;
          }), e == "r" || e === fn) i = fn;
          else {
            if (e != "rw" && e != dn) throw new q.InvalidArgument("Invalid transaction mode: " + e);
            i = dn;
          }
          if (o) {
            if (o.mode === fn && i === dn) {
              if (!u) throw new q.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
              o = null;
            }
            o && a.forEach(function(l) {
              if (o && o.storeNames.indexOf(l) === -1) {
                if (!u) throw new q.SubTransaction("Table " + l + " not included in parent transaction.");
                o = null;
              }
            }), u && o && !o.active && (o = null);
          }
        } catch (l) {
          return o ? o._promise(null, function(p, s) {
            s(l);
          }) : G(l);
        }
        var c = (function l(p, s, v, f, d) {
          return I.resolve().then(function() {
            var h = T.transless || T, y = p._createTransaction(s, v, p._dbSchema, f);
            if (y.explicit = !0, h = { trans: y, transless: h }, f) y.idbtrans = f.idbtrans;
            else try {
              y.create(), y.idbtrans._explicit = !0, p._state.PR1398_maxLoop = 3;
            } catch (b) {
              return b.name === en.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                return l(p, s, v, null, d);
              })) : G(b);
            }
            var m, g = Zt(d);
            return g && Ye(), h = I.follow(function() {
              var b;
              (m = d.call(y, y)) && (g ? (b = _e.bind(null, null), m.then(b, b)) : typeof m.next == "function" && typeof m.throw == "function" && (m = In(m)));
            }, h), (m && typeof m.then == "function" ? I.resolve(m).then(function(b) {
              return y.active ? b : G(new q.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
            }) : h.then(function() {
              return m;
            })).then(function(b) {
              return f && y._resolve(), y._completion.then(function() {
                return b;
              });
            }).catch(function(b) {
              return y._reject(b), G(b);
            });
          });
        }).bind(null, this, i, a, o, n);
        return o ? o._promise(i, c, "lock") : T.trans ? Ce(T.transless, function() {
          return r._whenReady(c);
        }) : this._whenReady(c);
      }, Q.prototype.table = function(e) {
        if (!oe(this._allTables, e)) throw new q.InvalidTable("Table ".concat(e, " does not exist"));
        return this._allTables[e];
      }, Q);
      function Q(e, t) {
        var n = this;
        this._middlewares = {}, this.verno = 0;
        var r = Q.dependencies;
        this._options = t = x({ addons: Q.addons, autoOpen: !0, indexedDB: r.indexedDB, IDBKeyRange: r.IDBKeyRange, cache: "cloned" }, t), this._deps = { indexedDB: t.indexedDB, IDBKeyRange: t.IDBKeyRange }, r = t.addons, this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
        var o, i, a, u, c, l = { dbOpenError: null, isBeingOpened: !1, onReadyBeingFired: null, openComplete: !1, dbReadyResolve: z, dbReadyPromise: null, cancelOpen: z, openCanceller: null, autoSchema: !0, PR1398_maxLoop: 3, autoOpen: t.autoOpen };
        l.dbReadyPromise = new I(function(s) {
          l.dbReadyResolve = s;
        }), l.openCanceller = new I(function(s, v) {
          l.cancelOpen = v;
        }), this._state = l, this.name = e, this.on = at(this, "populate", "blocked", "versionchange", "close", { ready: [tn, z] }), this.once = function(s, v) {
          var f = function() {
            for (var d = [], h = 0; h < arguments.length; h++) d[h] = arguments[h];
            n.on(s).unsubscribe(f), v.apply(n, d);
          };
          return n.on(s, f);
        }, this.on.ready.subscribe = Fn(this.on.ready.subscribe, function(s) {
          return function(v, f) {
            Q.vip(function() {
              var d, h = n._state;
              h.openComplete ? (h.dbOpenError || I.resolve().then(v), f && s(v)) : h.onReadyBeingFired ? (h.onReadyBeingFired.push(v), f && s(v)) : (s(v), d = n, f || s(function y() {
                d.on.ready.unsubscribe(v), d.on.ready.unsubscribe(y);
              }));
            });
          };
        }), this.Collection = (o = this, ut(Hr.prototype, function(m, y) {
          this.db = o;
          var f = er, d = null;
          if (y) try {
            f = y();
          } catch (g) {
            d = g;
          }
          var h = m._ctx, y = h.table, m = y.hook.reading.fire;
          this._ctx = { table: y, index: h.index, isPrimKey: !h.index || y.schema.primKey.keyPath && h.index === y.schema.primKey.name, range: f, keysOnly: !1, dir: "next", unique: "", algorithm: null, filter: null, replayFilter: null, justLimit: !0, isMatch: null, offset: 0, limit: 1 / 0, error: d, or: h.or, valueMapper: m !== et ? m : null };
        })), this.Table = (i = this, ut(ar.prototype, function(s, v, f) {
          this.db = i, this._tx = f, this.name = s, this.schema = v, this.hook = i._allTables[s] ? i._allTables[s].hook : at(null, { creating: [Mr, z], reading: [Nr, et], updating: [Vr, z], deleting: [Fr, z] });
        })), this.Transaction = (a = this, ut(Xr.prototype, function(s, v, f, d, h) {
          var y = this;
          s !== "readonly" && v.forEach(function(m) {
            m = (m = f[m]) === null || m === void 0 ? void 0 : m.yProps, m && (v = v.concat(m.map(function(g) {
              return g.updatesTable;
            })));
          }), this.db = a, this.mode = s, this.storeNames = v, this.schema = f, this.chromeTransactionDurability = d, this.idbtrans = null, this.on = at(this, "complete", "error", "abort"), this.parent = h || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new I(function(m, g) {
            y._resolve = m, y._reject = g;
          }), this._completion.then(function() {
            y.active = !1, y.on.complete.fire();
          }, function(m) {
            var g = y.active;
            return y.active = !1, y.on.error.fire(m), y.parent ? y.parent._reject(m) : g && y.idbtrans && y.idbtrans.abort(), G(m);
          });
        })), this.Version = (u = this, ut(oo.prototype, function(s) {
          this.db = u, this._cfg = { version: s, storesSource: null, dbschema: {}, tables: {}, contentUpgrade: null };
        })), this.WhereClause = (c = this, ut(fr.prototype, function(s, v, f) {
          if (this.db = c, this._ctx = { table: s, index: v === ":id" ? null : v, or: f }, this._cmp = this._ascending = F, this._descending = function(d, h) {
            return F(h, d);
          }, this._max = function(d, h) {
            return 0 < F(d, h) ? d : h;
          }, this._min = function(d, h) {
            return F(d, h) < 0 ? d : h;
          }, this._IDBKeyRange = c._deps.IDBKeyRange, !this._IDBKeyRange) throw new q.MissingAPI();
        })), this.on("versionchange", function(s) {
          0 < s.newVersion ? console.warn("Another connection wants to upgrade database '".concat(n.name, "'. Closing db now to resume the upgrade.")) : console.warn("Another connection wants to delete database '".concat(n.name, "'. Closing db now to resume the delete request.")), n.close({ disableAutoOpen: !1 });
        }), this.on("blocked", function(s) {
          !s.newVersion || s.newVersion < s.oldVersion ? console.warn("Dexie.delete('".concat(n.name, "') was blocked")) : console.warn("Upgrade '".concat(n.name, "' blocked by other connection holding version ").concat(s.oldVersion / 10));
        }), this._maxKey = lt(t.IDBKeyRange), this._createTransaction = function(s, v, f, d) {
          return new n.Transaction(s, v, f, n._options.chromeTransactionDurability, d);
        }, this._fireOnBlocked = function(s) {
          n.on("blocked").fire(s), We.filter(function(v) {
            return v.name === n.name && v !== n && !v._state.vcFired;
          }).map(function(v) {
            return v.on("versionchange").fire(s);
          });
        }, this.use(so), this.use(ho), this.use(co), this.use(ao), this.use(uo);
        var p = new Proxy(this, { get: function(s, v, f) {
          if (v === "_vip") return !0;
          if (v === "table") return function(h) {
            return Vt(n.table(h), p);
          };
          var d = Reflect.get(s, v, f);
          return d instanceof ar ? Vt(d, p) : v === "tables" ? d.map(function(h) {
            return Vt(h, p);
          }) : v === "_createTransaction" ? function() {
            return Vt(d.apply(this, arguments), p);
          } : d;
        } });
        this.vip = p, r.forEach(function(s) {
          return s(n);
        });
      }
      var Lt, ce = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", po = (An.prototype.subscribe = function(e, t, n) {
        return this._subscribe(e && typeof e != "function" ? e : { next: e, error: t, complete: n });
      }, An.prototype[ce] = function() {
        return this;
      }, An);
      function An(e) {
        this._subscribe = e;
      }
      try {
        Lt = { indexedDB: U.indexedDB || U.mozIndexedDB || U.webkitIndexedDB || U.msIndexedDB, IDBKeyRange: U.IDBKeyRange || U.webkitIDBKeyRange };
      } catch {
        Lt = { indexedDB: null, IDBKeyRange: null };
      }
      function Or(e) {
        var t, n = !1, r = new po(function(o) {
          var i = Zt(e), a, u = !1, c = {}, l = {}, p = { get closed() {
            return u;
          }, unsubscribe: function() {
            u || (u = !0, a && a.abort(), s && Pe.storagemutated.unsubscribe(f));
          } };
          o.start && o.start(p);
          var s = !1, v = function() {
            return ln(d);
          }, f = function(h) {
            Nt(c, h), On(l, c) && v();
          }, d = function() {
            var h, y, m;
            !u && Lt.indexedDB && (c = {}, h = {}, a && a.abort(), a = new AbortController(), m = (function(g) {
              var b = $e();
              try {
                i && Ye();
                var w = we(e, g);
                return w = i ? w.finally(_e) : w;
              } finally {
                b && ze();
              }
            })(y = { subscr: h, signal: a.signal, requery: v, querier: e, trans: null }), Promise.resolve(m).then(function(g) {
              n = !0, t = g, u || y.signal.aborted || (c = {}, (function(b) {
                for (var w in b) if (oe(b, w)) return;
                return 1;
              })(l = h) || s || (Pe(ct, f), s = !0), ln(function() {
                return !u && o.next && o.next(g);
              }));
            }, function(g) {
              n = !1, ["DatabaseClosedError", "AbortError"].includes(g == null ? void 0 : g.name) || u || ln(function() {
                u || o.error && o.error(g);
              });
            }));
          };
          return setTimeout(v, 0), p;
        });
        return r.hasValue = function() {
          return n;
        }, r.getValue = function() {
          return t;
        }, r;
      }
      var Re = me;
      function qn(e) {
        var t = Se;
        try {
          Se = !0, Pe.storagemutated.fire(e), Kn(e, !0);
        } finally {
          Se = t;
        }
      }
      Me(Re, x(x({}, mt), { delete: function(e) {
        return new Re(e, { addons: [] }).delete();
      }, exists: function(e) {
        return new Re(e, { addons: [] }).open().then(function(t) {
          return t.close(), !0;
        }).catch("NoSuchDatabaseError", function() {
          return !1;
        });
      }, getDatabaseNames: function(e) {
        try {
          return t = Re.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (kn(n) ? Promise.resolve(n.databases()).then(function(r) {
            return r.map(function(o) {
              return o.name;
            }).filter(function(o) {
              return o !== Ot;
            });
          }) : xn(n, t).toCollection().primaryKeys()).then(e);
        } catch {
          return G(new q.MissingAPI());
        }
        var t, n;
      }, defineClass: function() {
        return function(e) {
          A(this, e);
        };
      }, ignoreTransaction: function(e) {
        return T.trans ? Ce(T.transless, e) : e();
      }, vip: Pn, async: function(e) {
        return function() {
          try {
            var t = In(e.apply(this, arguments));
            return t && typeof t.then == "function" ? t : I.resolve(t);
          } catch (n) {
            return G(n);
          }
        };
      }, spawn: function(e, t, n) {
        try {
          var r = In(e.apply(n, t || []));
          return r && typeof r.then == "function" ? r : I.resolve(r);
        } catch (o) {
          return G(o);
        }
      }, currentTransaction: { get: function() {
        return T.trans || null;
      } }, waitFor: function(e, t) {
        return t = I.resolve(typeof e == "function" ? Re.ignoreTransaction(e) : e).timeout(t || 6e4), T.trans ? T.trans.waitFor(t) : t;
      }, Promise: I, debug: { get: function() {
        return fe;
      }, set: function(e) {
        Wn(e);
      } }, derive: Fe, extend: A, props: Me, override: Fn, Events: at, on: Pe, liveQuery: Or, extendObservabilitySet: Nt, getByKeyPath: pe, setByKeyPath: ie, delByKeyPath: function(e, t) {
        typeof t == "string" ? ie(e, t, void 0) : "length" in t && [].map.call(t, function(n) {
          ie(e, n, void 0);
        });
      }, shallowClone: Ln, deepClone: Oe, getObjectDiff: Dn, cmp: F, asap: Vn, minKey: -1 / 0, addons: [], connections: We, errnames: en, dependencies: Lt, cache: Be, semVer: "4.2.1", version: "4.2.1".split(".").map(function(e) {
        return parseInt(e);
      }).reduce(function(e, t, n) {
        return e + t / Math.pow(10, 2 * n);
      }) })), Re.maxKey = lt(Re.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Pe(ct, function(e) {
        Se || (e = new CustomEvent(yn, { detail: e }), Se = !0, dispatchEvent(e), Se = !1);
      }), addEventListener(yn, function(e) {
        e = e.detail, Se || qn(e);
      }));
      var Xe, Se = !1, jr = function() {
      };
      return typeof BroadcastChannel < "u" && ((jr = function() {
        (Xe = new BroadcastChannel(yn)).onmessage = function(e) {
          return e.data && qn(e.data);
        };
      })(), typeof Xe.unref == "function" && Xe.unref(), Pe(ct, function(e) {
        Se || Xe.postMessage(e);
      })), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
        if (!me.disableBfCache && e.persisted) {
          fe && console.debug("Dexie: handling persisted pagehide"), Xe != null && Xe.close();
          for (var t = 0, n = We; t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
        }
      }), addEventListener("pageshow", function(e) {
        !me.disableBfCache && e.persisted && (fe && console.debug("Dexie: handling persisted pageshow"), jr(), qn({ all: new ee(-1 / 0, [[]]) }));
      })), I.rejectionMapper = function(e, t) {
        return !e || e instanceof Le || e instanceof TypeError || e instanceof SyntaxError || !e.name || !Yn[e.name] ? e : (t = new Yn[e.name](t || e.message, e), "stack" in e && ge(t, "stack", { get: function() {
          return this.inner.stack;
        } }), t);
      }, Wn(fe), x(me, Object.freeze({ __proto__: null, Dexie: me, liveQuery: Or, Entity: tr, cmp: F, PropModification: it, replacePrefix: function(e, t) {
        return new it({ replacePrefix: [e, t] });
      }, add: function(e) {
        return new it({ add: e });
      }, remove: function(e) {
        return new it({ remove: e });
      }, default: me, RangeSet: ee, mergeRanges: ht, rangesOverlap: vr }), { default: me }), me;
    });
  })(zt)), zt.exports;
}
var _o = wo();
const Rn = /* @__PURE__ */ go(_o), Kr = Symbol.for("Dexie"), Ht = globalThis[Kr] || (globalThis[Kr] = Rn);
if (Rn.semVer !== Ht.semVer)
  throw new Error(`Two different versions of Dexie loaded in the same app: ${Rn.semVer} and ${Ht.semVer}`);
const {
  liveQuery: Ko,
  mergeRanges: Io,
  rangesOverlap: Do,
  RangeSet: To,
  cmp: Co,
  Entity: Ao,
  PropModification: qo,
  replacePrefix: Bo,
  add: Ro,
  remove: No,
  DexieYProvider: Mo
} = Ht, Yt = {
  searchTerms: ["Allow", "Keep"],
  timeoutSeconds: 120,
  confidenceThreshold: 60
}, Nn = 2;
class xo extends Ht {
  constructor() {
    super("ProjectDatabase");
    $t(this, "projects");
    $t(this, "bundles");
    $t(this, "testRuns");
    this.version(1).stores({
      projects: "++id, projectName, isPublic",
      bundles: "++id, bundleName, projectId, isPublic",
      testRuns: "++id, bundleId, project_id, status"
    }), this.version(2).stores({
      projects: "++id, projectName, isPublic",
      bundles: "++id, bundleName, projectId, isPublic",
      testRuns: "++id, bundleId, project_id, status"
    }).upgrade((k) => k.table("projects").toCollection().modify((x) => {
      x.schemaVersion = Nn, x.loopStartIndex = x.loopStartIndex ?? 0, x.globalDelayMs = x.globalDelayMs ?? 0, x.conditionalDefaults = x.conditionalDefaults ?? {
        ...Yt
      }, x.recorded_steps && Array.isArray(x.recorded_steps) && (x.recorded_steps = x.recorded_steps.map(
        (W) => Wt(W)
      )), console.log(`[Migration] Upgraded project ${x.id} to schema v2`);
    })), this.projects = this.table("projects"), this.bundles = this.table("bundles"), this.testRuns = this.table("testRuns");
  }
  // ==========================================================================
  // PROJECT METHODS
  // ==========================================================================
  /**
   * Add a new project with default Vision fields.
   */
  async addProject(k) {
    const x = (/* @__PURE__ */ new Date()).toISOString(), W = {
      ...k,
      schemaVersion: Nn,
      loopStartIndex: 0,
      globalDelayMs: 0,
      conditionalDefaults: { ...Yt },
      recorded_steps: (k.recorded_steps || []).map(Wt),
      created_date: k.created_date || x,
      updated_date: x
    };
    return await this.projects.add(W);
  }
  /**
   * Update an existing project.
   */
  async updateProject(k, x) {
    const W = {
      ...x,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    return x.recorded_steps && (W.recorded_steps = x.recorded_steps.map(Wt)), await this.projects.update(k, W);
  }
  /**
   * Get all projects.
   */
  async getAllProjects() {
    return (await this.projects.toArray()).map(Ir);
  }
  /**
   * Get a project by ID.
   */
  async getProject(k) {
    const x = await this.projects.get(k);
    return x ? Ir(x) : void 0;
  }
  /**
   * Delete a project.
   */
  async deleteProject(k) {
    await this.projects.delete(k);
  }
  // ==========================================================================
  // VISION-SPECIFIC METHODS
  // ==========================================================================
  /**
   * Update the loop start index for a project.
   */
  async setLoopStartIndex(k, x) {
    return await this.projects.update(k, {
      loopStartIndex: Math.max(0, x),
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update the global delay for a project.
   */
  async setGlobalDelay(k, x) {
    return await this.projects.update(k, {
      globalDelayMs: Math.max(0, x),
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update conditional defaults for a project.
   */
  async setConditionalDefaults(k, x) {
    const W = await this.projects.get(k);
    if (!W) throw new Error(`Project ${k} not found`);
    return await this.projects.update(k, {
      conditionalDefaults: {
        ...Yt,
        ...W.conditionalDefaults,
        ...x
      },
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update a specific step's delay.
   */
  async setStepDelay(k, x, W) {
    const U = await this.projects.get(k);
    if (!U) throw new Error(`Project ${k} not found`);
    if (!U.recorded_steps || x >= U.recorded_steps.length)
      throw new Error(`Step ${x} not found`);
    const $ = [...U.recorded_steps];
    return $[x] = {
      ...$[x],
      delaySeconds: W !== void 0 ? Math.max(0, W) : void 0
    }, await this.projects.update(k, {
      recorded_steps: $,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update a specific step's conditional config.
   */
  async setStepConditionalConfig(k, x, W) {
    const U = await this.projects.get(k);
    if (!U) throw new Error(`Project ${k} not found`);
    if (!U.recorded_steps || x >= U.recorded_steps.length)
      throw new Error(`Step ${x} not found`);
    const $ = [...U.recorded_steps];
    return $[x] = {
      ...$[x],
      conditionalConfig: W,
      event: W != null && W.enabled ? "conditional-click" : $[x].event
    }, await this.projects.update(k, {
      recorded_steps: $,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  // ==========================================================================
  // TEST RUN METHODS
  // ==========================================================================
  /**
   * Create a new test run.
   */
  async createTestRun(k) {
    return await this.testRuns.add(k);
  }
  /**
   * Update a test run.
   */
  async updateTestRun(k, x) {
    return await this.testRuns.update(k, x);
  }
  /**
   * Get test runs for a project.
   */
  async getTestRunsByProject(k) {
    return await this.testRuns.where("project_id").equals(k).reverse().sortBy("start_time");
  }
  /**
   * Get a test run by ID.
   */
  async getTestRun(k) {
    return await this.testRuns.get(k);
  }
  /**
   * Delete a test run.
   */
  async deleteTestRun(k) {
    await this.testRuns.delete(k);
  }
}
function Wt(_) {
  return {
    ..._,
    label: _.label || "",
    event: _.event || "click",
    recordedVia: _.recordedVia || "dom",
    // Preserve existing values, don't add undefined fields
    ..._.coordinates !== void 0 && { coordinates: _.coordinates },
    ..._.ocrText !== void 0 && { ocrText: _.ocrText },
    ..._.confidenceScore !== void 0 && { confidenceScore: _.confidenceScore },
    ..._.delaySeconds !== void 0 && { delaySeconds: _.delaySeconds },
    ..._.conditionalConfig !== void 0 && { conditionalConfig: _.conditionalConfig }
  };
}
function Ir(_) {
  return {
    ..._,
    schemaVersion: _.schemaVersion ?? Nn,
    loopStartIndex: _.loopStartIndex ?? 0,
    globalDelayMs: _.globalDelayMs ?? 0,
    conditionalDefaults: _.conditionalDefaults ?? { ...Yt },
    recorded_steps: (_.recorded_steps || []).map(Wt)
  };
}
const se = new xo();
async function ko(_) {
  try {
    let V;
    _ && (V = (await chrome.tabs.get(_)).windowId);
    const k = V !== void 0 ? await chrome.tabs.captureVisibleTab(V, {
      format: "png",
      quality: 100
    }) : await chrome.tabs.captureVisibleTab({
      format: "png",
      quality: 100
    });
    return console.log("[VisionHandler] Screenshot captured successfully"), {
      success: !0,
      dataUrl: k
      // Dimensions will be calculated by VisionEngine using Image API
    };
  } catch (V) {
    return console.error("[VisionHandler] Screenshot failed:", V), {
      success: !1,
      error: V instanceof Error ? V.message : String(V)
    };
  }
}
async function Po(_, V) {
  try {
    const k = V || ["contentScript/index.js"];
    return await chrome.scripting.executeScript({
      target: { tabId: _ },
      files: k
    }), console.log(`[VisionHandler] Scripts injected into tab ${_}`), { success: !0 };
  } catch (k) {
    return console.error("[VisionHandler] Script injection failed:", k), {
      success: !1,
      error: k instanceof Error ? k.message : String(k)
    };
  }
}
async function So(_) {
  const { tabId: V, ...k } = _;
  try {
    return await chrome.tabs.sendMessage(V, k);
  } catch (x) {
    return console.error("[VisionHandler] Forward to content script failed:", x), {
      success: !1,
      error: x instanceof Error ? x.message : String(x)
    };
  }
}
async function Oo(_, V) {
  var k;
  if ((k = _.type) != null && k.startsWith("VISION_"))
    switch (console.log(`[VisionHandler] Handling: ${_.type}`), _.type) {
      case "VISION_SCREENSHOT":
        return await ko(_.tabId);
      case "VISION_INJECT_SCRIPT":
        return await Po(
          _.tabId,
          _.files
        );
      case "VISION_CLICK":
      case "VISION_TYPE":
      case "VISION_KEY":
      case "VISION_SCROLL":
      case "VISION_GET_ELEMENT":
        return _.tabId ? await So(_) : { success: !1, error: "tabId is required" };
      default:
        console.warn(`[VisionHandler] Unknown Vision message type: ${_.type}`);
        return;
    }
}
async function jo() {
  if ("storage" in navigator && navigator.storage && navigator.storage.persist) {
    const _ = await navigator.storage.persisted();
    if (console.log("Storage persisted?", _), !_) {
      const V = await navigator.storage.persist();
      console.log("Persistence granted:", V);
    }
  } else
    console.log("navigator.storage.persist not available in this context");
}
jo();
let pt = null;
const Gt = /* @__PURE__ */ new Set();
chrome.runtime.onMessage.addListener((_, V, k) => {
  var W, U, $;
  const x = Oo(_);
  if (x !== void 0)
    return Promise.resolve(x).then(k), !0;
  if (!_.action) return !1;
  try {
    if (_.action === "add_project") {
      console.log("Background: Received add_project request", _.payload);
      const C = {
        ..._.payload,
        recorded_steps: [],
        parsed_fields: [],
        csv_data: []
      };
      return se.addProject(C).then((A) => {
        console.log("Background: Project added successfully with ID:", A), k({ success: !0, id: A });
      }).catch((A) => {
        console.error("Background: Error adding project:", A), k({ success: !1, error: A.message });
      }), !0;
    }
    if (_.action === "update_project")
      return se.updateProject(_.payload.id, {
        projectName: _.payload.name || _.payload.projectName,
        project_url: _.payload.target_url || _.payload.project_url
      }).then(() => k({ success: !0 })).catch(
        (C) => k({ success: !1, error: C.message })
      ), !0;
    if (_.action === "get_all_projects")
      return se.getAllProjects().then((C) => k({ success: !0, projects: C })).catch((C) => k({ success: !1, error: C.message })), !0;
    if (_.action === "delete_project") {
      const C = (W = _.payload) == null ? void 0 : W.projectId;
      return se.deleteProject(C).then(() => k({ success: !0 })).catch((A) => k({ success: !1, error: A.message })), !0;
    }
    if (_.action === "get_project_by_id") {
      const C = (U = _.payload) == null ? void 0 : U.id;
      return se.projects.get(C).then((A) => {
        k(A ? { success: !0, project: A } : { success: !1, error: "Process  not found" });
      }).catch((A) => {
        k({ success: !1, error: A.message });
      }), !0;
    }
    if (_.action === "open_project_url_and_inject") {
      const C = ($ = _.payload) == null ? void 0 : $.id;
      return se.getAllProjects().then((A) => {
        const X = A.find((le) => le.id === C);
        if (!X || !X.project_url) {
          k({ success: !1, error: "Process not found or missing URL" });
          return;
        }
        chrome.tabs.create({ url: X.project_url }, (le) => {
          le != null && le.id && (pt = le.id, Gt.add(le.id), Qt(le.id));
        });
      }).catch((A) => {
        k({ success: !1, error: A.message });
      }), !0;
    }
    if (_.action === "update_project_steps") {
      const { id: C, recorded_steps: A } = _.payload;
      return se.projects.update(C, { recorded_steps: A }).then(() => {
        k({ success: !0 });
      }).catch((X) => {
        k({ success: !1, error: X.message });
      }), !0;
    }
    if (_.action === "update_project_fields") {
      const { id: C, parsed_fields: A } = _.payload;
      return se.projects.update(C, { parsed_fields: A }).then(() => {
        k({ success: !0 });
      }).catch((X) => {
        k({ success: !1, error: X.message });
      }), !0;
    }
    if (_.action === "update_project_csv") {
      const { id: C, csv_data: A } = _.payload;
      return se.projects.update(C, { csv_data: A }).then(() => {
        k({ success: !0 });
      }).catch((X) => {
        k({ success: !1, error: X.message });
      }), !0;
    }
    if (_.action === "createTestRun")
      return (async () => {
        try {
          const C = await se.testRuns.add(_.payload), A = await se.testRuns.get(C);
          k({ success: !0, testRun: A });
        } catch (C) {
          k({ success: !1, error: C });
        }
      })(), !0;
    if (_.action === "updateTestRun")
      return (async () => {
        try {
          await se.testRuns.update(_.id, _.payload), k({ success: !0 });
        } catch (C) {
          k({ success: !1, error: C });
        }
      })(), !0;
    if (_.action === "getTestRunsByProject") {
      const C = _.projectId;
      return se.getTestRunsByProject(C).then((A) => {
        k({ success: !0, data: A });
      }).catch((A) => {
        k({ success: !1, error: A.message });
      }), !0;
    }
    if (_.action === "openTab") {
      const C = _.url;
      return chrome.tabs.create({ url: C }, (A) => {
        if (chrome.runtime.lastError) {
          console.error("Failed to create tab:", chrome.runtime.lastError.message), k({ success: !1, error: chrome.runtime.lastError.message });
          return;
        }
        if (!(A != null && A.id)) {
          k({ success: !1, error: "No tab ID returned" });
          return;
        }
        Qt(A.id, (X) => {
          X.success ? (console.log("Injected into tab", A.id), A != null && A.id && (pt = A.id, Gt.add(A.id), k({ success: !0, tabId: A.id }))) : (console.error("Injection failed:", X.error), k({ success: !1, error: X.error }));
        });
      }), !0;
    }
    if (_.action === "close_opened_tab")
      return pt !== null ? chrome.tabs.remove(pt, () => {
        pt = null, k({ success: !0 });
      }) : k({ success: !1, error: "No opened tab to close" }), !0;
    if (_.action === "openDashBoard")
      return chrome.tabs.create({ url: chrome.runtime.getURL("pages.html") }, () => {
        k({ success: !0 });
      }), !0;
  } catch (C) {
    return k({ success: !1, error: C.message }), !1;
  }
});
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html")
  });
});
chrome.runtime.onInstalled.addListener((_) => {
  _.reason === "install" && chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html#dashboard")
  });
});
function Qt(_, V) {
  chrome.scripting.executeScript(
    {
      target: { tabId: _, allFrames: !0 },
      files: ["js/main.js"]
    },
    () => {
      chrome.runtime.lastError ? (console.warn("Inject failed:", chrome.runtime.lastError.message), V == null || V({ success: !1 })) : (console.log("Injected main.js into tab", _), V == null || V({ success: !0 }));
    }
  );
}
chrome.webNavigation.onCommitted.addListener((_) => {
  Gt.has(_.tabId) && (console.log("Frame navigated:", _.frameId, _.url), Qt(_.tabId));
});
chrome.webNavigation.onCompleted.addListener((_) => {
  Gt.has(_.tabId) && Qt(_.tabId);
});

var yo = Object.defineProperty;
var vo = (_, F, x) => F in _ ? yo(_, F, { enumerable: !0, configurable: !0, writable: !0, value: x }) : _[F] = x;
var zt = (_, F, x) => vo(_, typeof F != "symbol" ? F + "" : F, x);
var mo = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function go(_) {
  return _ && _.__esModule && Object.prototype.hasOwnProperty.call(_, "default") ? _.default : _;
}
var Yt = { exports: {} }, bo = Yt.exports, Er;
function wo() {
  return Er || (Er = 1, (function(_, F) {
    (function(x, k) {
      _.exports = k();
    })(bo, function() {
      var x = function(e, t) {
        return (x = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
          n.__proto__ = r;
        } || function(n, r) {
          for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (n[o] = r[o]);
        })(e, t);
      }, k = function() {
        return (k = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
          return e;
        }).apply(this, arguments);
      };
      function U(e, t, n) {
        for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || ((r = r || Array.prototype.slice.call(t, 0, o))[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t));
      }
      var $ = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : mo, z = Object.keys, W = Array.isArray;
      function B(e, t) {
        return typeof t != "object" || z(t).forEach(function(n) {
          e[n] = t[n];
        }), e;
      }
      typeof Promise > "u" || $.Promise || ($.Promise = Promise);
      var D = Object.getPrototypeOf, G = {}.hasOwnProperty;
      function X(e, t) {
        return G.call(e, t);
      }
      function J(e, t) {
        typeof t == "function" && (t = t(D(e))), (typeof Reflect > "u" ? z : Reflect.ownKeys)(t).forEach(function(n) {
          be(e, n, t[n]);
        });
      }
      var yt = Object.defineProperty;
      function be(e, t, n, r) {
        yt(e, t, B(n && X(n, "get") && typeof n.get == "function" ? { get: n.get, set: n.set, configurable: !0 } : { value: n, configurable: !0, writable: !0 }, r));
      }
      function Fe(e) {
        return { from: function(t) {
          return e.prototype = Object.create(t.prototype), be(e.prototype, "constructor", e), { extend: J.bind(null, e.prototype) };
        } };
      }
      var Dr = Object.getOwnPropertyDescriptor, Tr = [].slice;
      function vt(e, t, n) {
        return Tr.call(e, t, n);
      }
      function Fn(e, t) {
        return t(e);
      }
      function Je(e) {
        if (!e) throw new Error("Assertion Failed");
      }
      function Vn(e) {
        $.setImmediate ? setImmediate(e) : setTimeout(e, 0);
      }
      function ye(e, t) {
        if (typeof t == "string" && X(e, t)) return e[t];
        if (!t) return e;
        if (typeof t != "string") {
          for (var n = [], r = 0, o = t.length; r < o; ++r) {
            var i = ye(e, t[r]);
            n.push(i);
          }
          return n;
        }
        var a = t.indexOf(".");
        if (a !== -1) {
          var u = e[t.substr(0, a)];
          return u == null ? void 0 : ye(u, t.substr(a + 1));
        }
      }
      function ue(e, t, n) {
        if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) if (typeof t != "string" && "length" in t) {
          Je(typeof n != "string" && "length" in n);
          for (var r = 0, o = t.length; r < o; ++r) ue(e, t[r], n[r]);
        } else {
          var i, a, u = t.indexOf(".");
          u !== -1 ? (i = t.substr(0, u), (a = t.substr(u + 1)) === "" ? n === void 0 ? W(e) && !isNaN(parseInt(i)) ? e.splice(i, 1) : delete e[i] : e[i] = n : ue(u = !(u = e[i]) || !X(e, i) ? e[i] = {} : u, a, n)) : n === void 0 ? W(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
        }
      }
      function Ln(e) {
        var t, n = {};
        for (t in e) X(e, t) && (n[t] = e[t]);
        return n;
      }
      var Cr = [].concat;
      function Un(e) {
        return Cr.apply([], e);
      }
      var Ke = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(Un([8, 16, 32, 64].map(function(e) {
        return ["Int", "Uint", "Float"].map(function(t) {
          return t + e + "Array";
        });
      }))).filter(function(e) {
        return $[e];
      }), $n = new Set(Ke.map(function(e) {
        return $[e];
      })), Ze = null;
      function je(e) {
        return Ze = /* @__PURE__ */ new WeakMap(), e = (function t(n) {
          if (!n || typeof n != "object") return n;
          var r = Ze.get(n);
          if (r) return r;
          if (W(n)) {
            r = [], Ze.set(n, r);
            for (var o = 0, i = n.length; o < i; ++o) r.push(t(n[o]));
          } else if ($n.has(n.constructor)) r = n;
          else {
            var a, u = D(n);
            for (a in r = u === Object.prototype ? {} : Object.create(u), Ze.set(n, r), n) X(n, a) && (r[a] = t(n[a]));
          }
          return r;
        })(e), Ze = null, e;
      }
      var Ar = {}.toString;
      function Qt(e) {
        return Ar.call(e).slice(8, -1);
      }
      var Xt = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", Br = typeof Xt == "symbol" ? function(e) {
        var t;
        return e != null && (t = e[Xt]) && t.apply(e);
      } : function() {
        return null;
      };
      function Ee(e, t) {
        return t = e.indexOf(t), 0 <= t && e.splice(t, 1), 0 <= t;
      }
      var Ve = {};
      function ve(e) {
        var t, n, r, o;
        if (arguments.length === 1) {
          if (W(e)) return e.slice();
          if (this === Ve && typeof e == "string") return [e];
          if (o = Br(e)) {
            for (n = []; !(r = o.next()).done; ) n.push(r.value);
            return n;
          }
          if (e == null) return [e];
          if (typeof (t = e.length) != "number") return [e];
          for (n = new Array(t); t--; ) n[t] = e[t];
          return n;
        }
        for (t = arguments.length, n = new Array(t); t--; ) n[t] = arguments[t];
        return n;
      }
      var Jt = typeof Symbol < "u" ? function(e) {
        return e[Symbol.toStringTag] === "AsyncFunction";
      } : function() {
        return !1;
      }, nt = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"], fe = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(nt), qr = { VersionChanged: "Database version changed by other database connection", DatabaseClosed: "Database has been closed", Abort: "Transaction aborted", TransactionInactive: "Transaction has already completed or failed", MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb" };
      function Le(e, t) {
        this.name = e, this.message = t;
      }
      function zn(e, t) {
        return e + ". Errors: " + Object.keys(t).map(function(n) {
          return t[n].toString();
        }).filter(function(n, r, o) {
          return o.indexOf(n) === r;
        }).join(`
`);
      }
      function mt(e, t, n, r) {
        this.failures = t, this.failedKeys = r, this.successCount = n, this.message = zn(e, t);
      }
      function Ue(e, t) {
        this.name = "BulkError", this.failures = Object.keys(t).map(function(n) {
          return t[n];
        }), this.failuresByPos = t, this.message = zn(e, this.failures);
      }
      Fe(Le).from(Error).extend({ toString: function() {
        return this.name + ": " + this.message;
      } }), Fe(mt).from(Le), Fe(Ue).from(Le);
      var Zt = fe.reduce(function(e, t) {
        return e[t] = t + "Error", e;
      }, {}), Nr = Le, A = fe.reduce(function(e, t) {
        var n = t + "Error";
        function r(o, i) {
          this.name = n, o ? typeof o == "string" ? (this.message = "".concat(o).concat(i ? `
 ` + i : ""), this.inner = i || null) : typeof o == "object" && (this.message = "".concat(o.name, " ").concat(o.message), this.inner = o) : (this.message = qr[t] || n, this.inner = null);
        }
        return Fe(r).from(Nr), e[t] = r, e;
      }, {});
      A.Syntax = SyntaxError, A.Type = TypeError, A.Range = RangeError;
      var Yn = nt.reduce(function(e, t) {
        return e[t + "Error"] = A[t], e;
      }, {}), gt = fe.reduce(function(e, t) {
        return ["Syntax", "Type", "Range"].indexOf(t) === -1 && (e[t + "Error"] = A[t]), e;
      }, {});
      function Y() {
      }
      function et(e) {
        return e;
      }
      function Rr(e, t) {
        return e == null || e === et ? t : function(n) {
          return t(e(n));
        };
      }
      function Ie(e, t) {
        return function() {
          e.apply(this, arguments), t.apply(this, arguments);
        };
      }
      function Mr(e, t) {
        return e === Y ? t : function() {
          var n = e.apply(this, arguments);
          n !== void 0 && (arguments[0] = n);
          var r = this.onsuccess, o = this.onerror;
          this.onsuccess = null, this.onerror = null;
          var i = t.apply(this, arguments);
          return r && (this.onsuccess = this.onsuccess ? Ie(r, this.onsuccess) : r), o && (this.onerror = this.onerror ? Ie(o, this.onerror) : o), i !== void 0 ? i : n;
        };
      }
      function Fr(e, t) {
        return e === Y ? t : function() {
          e.apply(this, arguments);
          var n = this.onsuccess, r = this.onerror;
          this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? Ie(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? Ie(r, this.onerror) : r);
        };
      }
      function Vr(e, t) {
        return e === Y ? t : function(n) {
          var r = e.apply(this, arguments);
          B(n, r);
          var o = this.onsuccess, i = this.onerror;
          return this.onsuccess = null, this.onerror = null, n = t.apply(this, arguments), o && (this.onsuccess = this.onsuccess ? Ie(o, this.onsuccess) : o), i && (this.onerror = this.onerror ? Ie(i, this.onerror) : i), r === void 0 ? n === void 0 ? void 0 : n : B(r, n);
        };
      }
      function Lr(e, t) {
        return e === Y ? t : function() {
          return t.apply(this, arguments) !== !1 && e.apply(this, arguments);
        };
      }
      function en(e, t) {
        return e === Y ? t : function() {
          var n = e.apply(this, arguments);
          if (n && typeof n.then == "function") {
            for (var r = this, o = arguments.length, i = new Array(o); o--; ) i[o] = arguments[o];
            return n.then(function() {
              return t.apply(r, i);
            });
          }
          return t.apply(this, arguments);
        };
      }
      gt.ModifyError = mt, gt.DexieError = Le, gt.BulkError = Ue;
      var de = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
      function Wn(e) {
        de = e;
      }
      var tt = {}, Hn = 100, Ke = typeof Promise > "u" ? [] : (function() {
        var e = Promise.resolve();
        if (typeof crypto > "u" || !crypto.subtle) return [e, D(e), e];
        var t = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [t, D(t), e];
      })(), nt = Ke[0], fe = Ke[1], Ke = Ke[2], fe = fe && fe.then, De = nt && nt.constructor, tn = !!Ke, rt = function(e, t) {
        ot.push([e, t]), bt && (queueMicrotask($r), bt = !1);
      }, nn = !0, bt = !0, Te = [], wt = [], rn = et, we = { id: "global", global: !0, ref: 0, unhandleds: [], onunhandled: Y, pgp: !1, env: {}, finalize: Y }, C = we, ot = [], Ce = 0, _t = [];
      function K(e) {
        if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
        this._listeners = [], this._lib = !1;
        var t = this._PSD = C;
        if (typeof e != "function") {
          if (e !== tt) throw new TypeError("Not a function");
          return this._state = arguments[1], this._value = arguments[2], void (this._state === !1 && an(this, this._value));
        }
        this._state = null, this._value = null, ++t.ref, (function n(r, o) {
          try {
            o(function(i) {
              if (r._state === null) {
                if (i === r) throw new TypeError("A promise cannot be resolved with itself.");
                var a = r._lib && $e();
                i && typeof i.then == "function" ? n(r, function(u, c) {
                  i instanceof K ? i._then(u, c) : i.then(u, c);
                }) : (r._state = !0, r._value = i, Qn(r)), a && ze();
              }
            }, an.bind(null, r));
          } catch (i) {
            an(r, i);
          }
        })(this, e);
      }
      var on = { get: function() {
        var e = C, t = Pt;
        function n(r, o) {
          var i = this, a = !e.global && (e !== C || t !== Pt), u = a && !xe(), c = new K(function(l, p) {
            un(i, new Gn(Jn(r, e, a, u), Jn(o, e, a, u), l, p, e));
          });
          return this._consoleTask && (c._consoleTask = this._consoleTask), c;
        }
        return n.prototype = tt, n;
      }, set: function(e) {
        be(this, "then", e && e.prototype === tt ? on : { get: function() {
          return e;
        }, set: on.set });
      } };
      function Gn(e, t, n, r, o) {
        this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = o;
      }
      function an(e, t) {
        var n, r;
        wt.push(t), e._state === null && (n = e._lib && $e(), t = rn(t), e._state = !1, e._value = t, r = e, Te.some(function(o) {
          return o._value === r._value;
        }) || Te.push(r), Qn(e), n && ze());
      }
      function Qn(e) {
        var t = e._listeners;
        e._listeners = [];
        for (var n = 0, r = t.length; n < r; ++n) un(e, t[n]);
        var o = e._PSD;
        --o.ref || o.finalize(), Ce === 0 && (++Ce, rt(function() {
          --Ce == 0 && sn();
        }, []));
      }
      function un(e, t) {
        if (e._state !== null) {
          var n = e._state ? t.onFulfilled : t.onRejected;
          if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
          ++t.psd.ref, ++Ce, rt(Ur, [n, e, t]);
        } else e._listeners.push(t);
      }
      function Ur(e, t, n) {
        try {
          var r, o = t._value;
          !t._state && wt.length && (wt = []), r = de && t._consoleTask ? t._consoleTask.run(function() {
            return e(o);
          }) : e(o), t._state || wt.indexOf(o) !== -1 || (function(i) {
            for (var a = Te.length; a; ) if (Te[--a]._value === i._value) return Te.splice(a, 1);
          })(t), n.resolve(r);
        } catch (i) {
          n.reject(i);
        } finally {
          --Ce == 0 && sn(), --n.psd.ref || n.psd.finalize();
        }
      }
      function $r() {
        Ae(we, function() {
          $e() && ze();
        });
      }
      function $e() {
        var e = nn;
        return bt = nn = !1, e;
      }
      function ze() {
        var e, t, n;
        do
          for (; 0 < ot.length; ) for (e = ot, ot = [], n = e.length, t = 0; t < n; ++t) {
            var r = e[t];
            r[0].apply(null, r[1]);
          }
        while (0 < ot.length);
        bt = nn = !0;
      }
      function sn() {
        var e = Te;
        Te = [], e.forEach(function(r) {
          r._PSD.onunhandled.call(null, r._value, r);
        });
        for (var t = _t.slice(0), n = t.length; n; ) t[--n]();
      }
      function xt(e) {
        return new K(tt, !1, e);
      }
      function Q(e, t) {
        var n = C;
        return function() {
          var r = $e(), o = C;
          try {
            return ke(n, !0), e.apply(this, arguments);
          } catch (i) {
            t && t(i);
          } finally {
            ke(o, !1), r && ze();
          }
        };
      }
      J(K.prototype, { then: on, _then: function(e, t) {
        un(this, new Gn(null, null, e, t, C));
      }, catch: function(e) {
        if (arguments.length === 1) return this.then(null, e);
        var t = e, n = arguments[1];
        return typeof t == "function" ? this.then(null, function(r) {
          return (r instanceof t ? n : xt)(r);
        }) : this.then(null, function(r) {
          return (r && r.name === t ? n : xt)(r);
        });
      }, finally: function(e) {
        return this.then(function(t) {
          return K.resolve(e()).then(function() {
            return t;
          });
        }, function(t) {
          return K.resolve(e()).then(function() {
            return xt(t);
          });
        });
      }, timeout: function(e, t) {
        var n = this;
        return e < 1 / 0 ? new K(function(r, o) {
          var i = setTimeout(function() {
            return o(new A.Timeout(t));
          }, e);
          n.then(r, o).finally(clearTimeout.bind(null, i));
        }) : this;
      } }), typeof Symbol < "u" && Symbol.toStringTag && be(K.prototype, Symbol.toStringTag, "Dexie.Promise"), we.env = Xn(), J(K, { all: function() {
        var e = ve.apply(null, arguments).map(Ot);
        return new K(function(t, n) {
          e.length === 0 && t([]);
          var r = e.length;
          e.forEach(function(o, i) {
            return K.resolve(o).then(function(a) {
              e[i] = a, --r || t(e);
            }, n);
          });
        });
      }, resolve: function(e) {
        return e instanceof K ? e : e && typeof e.then == "function" ? new K(function(t, n) {
          e.then(t, n);
        }) : new K(tt, !0, e);
      }, reject: xt, race: function() {
        var e = ve.apply(null, arguments).map(Ot);
        return new K(function(t, n) {
          e.map(function(r) {
            return K.resolve(r).then(t, n);
          });
        });
      }, PSD: { get: function() {
        return C;
      }, set: function(e) {
        return C = e;
      } }, totalEchoes: { get: function() {
        return Pt;
      } }, newPSD: _e, usePSD: Ae, scheduler: { get: function() {
        return rt;
      }, set: function(e) {
        rt = e;
      } }, rejectionMapper: { get: function() {
        return rn;
      }, set: function(e) {
        rn = e;
      } }, follow: function(e, t) {
        return new K(function(n, r) {
          return _e(function(o, i) {
            var a = C;
            a.unhandleds = [], a.onunhandled = i, a.finalize = Ie(function() {
              var u, c = this;
              u = function() {
                c.unhandleds.length === 0 ? o() : i(c.unhandleds[0]);
              }, _t.push(function l() {
                u(), _t.splice(_t.indexOf(l), 1);
              }), ++Ce, rt(function() {
                --Ce == 0 && sn();
              }, []);
            }, a.finalize), e();
          }, t, n, r);
        });
      } }), De && (De.allSettled && be(K, "allSettled", function() {
        var e = ve.apply(null, arguments).map(Ot);
        return new K(function(t) {
          e.length === 0 && t([]);
          var n = e.length, r = new Array(n);
          e.forEach(function(o, i) {
            return K.resolve(o).then(function(a) {
              return r[i] = { status: "fulfilled", value: a };
            }, function(a) {
              return r[i] = { status: "rejected", reason: a };
            }).then(function() {
              return --n || t(r);
            });
          });
        });
      }), De.any && typeof AggregateError < "u" && be(K, "any", function() {
        var e = ve.apply(null, arguments).map(Ot);
        return new K(function(t, n) {
          e.length === 0 && n(new AggregateError([]));
          var r = e.length, o = new Array(r);
          e.forEach(function(i, a) {
            return K.resolve(i).then(function(u) {
              return t(u);
            }, function(u) {
              o[a] = u, --r || n(new AggregateError(o));
            });
          });
        });
      }), De.withResolvers && (K.withResolvers = De.withResolvers));
      var te = { awaits: 0, echoes: 0, id: 0 }, zr = 0, kt = [], St = 0, Pt = 0, Yr = 0;
      function _e(e, t, n, r) {
        var o = C, i = Object.create(o);
        return i.parent = o, i.ref = 0, i.global = !1, i.id = ++Yr, we.env, i.env = tn ? { Promise: K, PromiseProp: { value: K, configurable: !0, writable: !0 }, all: K.all, race: K.race, allSettled: K.allSettled, any: K.any, resolve: K.resolve, reject: K.reject } : {}, t && B(i, t), ++o.ref, i.finalize = function() {
          --this.parent.ref || this.parent.finalize();
        }, r = Ae(i, e, n, r), i.ref === 0 && i.finalize(), r;
      }
      function Ye() {
        return te.id || (te.id = ++zr), ++te.awaits, te.echoes += Hn, te.id;
      }
      function xe() {
        return !!te.awaits && (--te.awaits == 0 && (te.id = 0), te.echoes = te.awaits * Hn, !0);
      }
      function Ot(e) {
        return te.echoes && e && e.constructor === De ? (Ye(), e.then(function(t) {
          return xe(), t;
        }, function(t) {
          return xe(), Z(t);
        })) : e;
      }
      function Wr() {
        var e = kt[kt.length - 1];
        kt.pop(), ke(e, !1);
      }
      function ke(e, t) {
        var n, r = C;
        (t ? !te.echoes || St++ && e === C : !St || --St && e === C) || queueMicrotask(t ? (function(o) {
          ++Pt, te.echoes && --te.echoes != 0 || (te.echoes = te.awaits = te.id = 0), kt.push(C), ke(o, !0);
        }).bind(null, e) : Wr), e !== C && (C = e, r === we && (we.env = Xn()), tn && (n = we.env.Promise, t = e.env, (r.global || e.global) && (Object.defineProperty($, "Promise", t.PromiseProp), n.all = t.all, n.race = t.race, n.resolve = t.resolve, n.reject = t.reject, t.allSettled && (n.allSettled = t.allSettled), t.any && (n.any = t.any))));
      }
      function Xn() {
        var e = $.Promise;
        return tn ? { Promise: e, PromiseProp: Object.getOwnPropertyDescriptor($, "Promise"), all: e.all, race: e.race, allSettled: e.allSettled, any: e.any, resolve: e.resolve, reject: e.reject } : {};
      }
      function Ae(e, t, n, r, o) {
        var i = C;
        try {
          return ke(e, !0), t(n, r, o);
        } finally {
          ke(i, !1);
        }
      }
      function Jn(e, t, n, r) {
        return typeof e != "function" ? e : function() {
          var o = C;
          n && Ye(), ke(t, !0);
          try {
            return e.apply(this, arguments);
          } finally {
            ke(o, !1), r && queueMicrotask(xe);
          }
        };
      }
      function cn(e) {
        Promise === De && te.echoes === 0 ? St === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
      }
      ("" + fe).indexOf("[native code]") === -1 && (Ye = xe = Y);
      var Z = K.reject, Be = "￿", me = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", Zn = "String expected.", We = [], jt = "__dbnames", ln = "readonly", fn = "readwrite";
      function qe(e, t) {
        return e ? t ? function() {
          return e.apply(this, arguments) && t.apply(this, arguments);
        } : e : t;
      }
      var er = { type: 3, lower: -1 / 0, lowerOpen: !1, upper: [[]], upperOpen: !1 };
      function Et(e) {
        return typeof e != "string" || /\./.test(e) ? function(t) {
          return t;
        } : function(t) {
          return t[e] === void 0 && e in t && delete (t = je(t))[e], t;
        };
      }
      function tr() {
        throw A.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
      }
      function V(e, t) {
        try {
          var n = nr(e), r = nr(t);
          if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r !== "Date" ? NaN : -1;
          switch (n) {
            case "number":
            case "Date":
            case "string":
              return t < e ? 1 : e < t ? -1 : 0;
            case "binary":
              return (function(o, i) {
                for (var a = o.length, u = i.length, c = a < u ? a : u, l = 0; l < c; ++l) if (o[l] !== i[l]) return o[l] < i[l] ? -1 : 1;
                return a === u ? 0 : a < u ? -1 : 1;
              })(rr(e), rr(t));
            case "Array":
              return (function(o, i) {
                for (var a = o.length, u = i.length, c = a < u ? a : u, l = 0; l < c; ++l) {
                  var p = V(o[l], i[l]);
                  if (p !== 0) return p;
                }
                return a === u ? 0 : a < u ? -1 : 1;
              })(e, t);
          }
        } catch {
        }
        return NaN;
      }
      function nr(e) {
        var t = typeof e;
        return t != "object" ? t : ArrayBuffer.isView(e) ? "binary" : (e = Qt(e), e === "ArrayBuffer" ? "binary" : e);
      }
      function rr(e) {
        return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
      }
      function It(e, t, n) {
        var r = e.schema.yProps;
        return r ? (t && 0 < n.numFailures && (t = t.filter(function(o, i) {
          return !n.failures[i];
        })), Promise.all(r.map(function(o) {
          return o = o.updatesTable, t ? e.db.table(o).where("k").anyOf(t).delete() : e.db.table(o).clear();
        })).then(function() {
          return n;
        })) : n;
      }
      var it = (or.prototype.execute = function(e) {
        var t = this["@@propmod"];
        if (t.add !== void 0) {
          var n = t.add;
          if (W(n)) return U(U([], W(e) ? e : [], !0), n).sort();
          if (typeof n == "number") return (Number(e) || 0) + n;
          if (typeof n == "bigint") try {
            return BigInt(e) + n;
          } catch {
            return BigInt(0) + n;
          }
          throw new TypeError("Invalid term ".concat(n));
        }
        if (t.remove !== void 0) {
          var r = t.remove;
          if (W(r)) return W(e) ? e.filter(function(o) {
            return !r.includes(o);
          }).sort() : [];
          if (typeof r == "number") return Number(e) - r;
          if (typeof r == "bigint") try {
            return BigInt(e) - r;
          } catch {
            return BigInt(0) - r;
          }
          throw new TypeError("Invalid subtrahend ".concat(r));
        }
        return n = (n = t.replacePrefix) === null || n === void 0 ? void 0 : n[0], n && typeof e == "string" && e.startsWith(n) ? t.replacePrefix[1] + e.substring(n.length) : e;
      }, or);
      function or(e) {
        this["@@propmod"] = e;
      }
      function ir(e, t) {
        for (var n = z(t), r = n.length, o = !1, i = 0; i < r; ++i) {
          var a = n[i], u = t[a], c = ye(e, a);
          u instanceof it ? (ue(e, a, u.execute(c)), o = !0) : c !== u && (ue(e, a, u), o = !0);
        }
        return o;
      }
      var ar = (H.prototype._trans = function(e, t, n) {
        var r = this._tx || C.trans, o = this.name, i = de && typeof console < "u" && console.createTask && console.createTask("Dexie: ".concat(e === "readonly" ? "read" : "write", " ").concat(this.name));
        function a(l, p, s) {
          if (!s.schema[o]) throw new A.NotFound("Table " + o + " not part of transaction");
          return t(s.idbtrans, s);
        }
        var u = $e();
        try {
          var c = r && r.db._novip === this.db._novip ? r === C.trans ? r._promise(e, a, n) : _e(function() {
            return r._promise(e, a, n);
          }, { trans: r, transless: C.transless || C }) : (function l(p, s, v, f) {
            if (p.idbdb && (p._state.openComplete || C.letThrough || p._vip)) {
              var d = p._createTransaction(s, v, p._dbSchema);
              try {
                d.create(), p._state.PR1398_maxLoop = 3;
              } catch (h) {
                return h.name === Zt.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                  return l(p, s, v, f);
                })) : Z(h);
              }
              return d._promise(s, function(h, y) {
                return _e(function() {
                  return C.trans = d, f(h, y, d);
                });
              }).then(function(h) {
                if (s === "readwrite") try {
                  d.idbtrans.commit();
                } catch {
                }
                return s === "readonly" ? h : d._completion.then(function() {
                  return h;
                });
              });
            }
            if (p._state.openComplete) return Z(new A.DatabaseClosed(p._state.dbOpenError));
            if (!p._state.isBeingOpened) {
              if (!p._state.autoOpen) return Z(new A.DatabaseClosed());
              p.open().catch(Y);
            }
            return p._state.dbReadyPromise.then(function() {
              return l(p, s, v, f);
            });
          })(this.db, e, [this.name], a);
          return i && (c._consoleTask = i, c = c.catch(function(l) {
            return console.trace(l), Z(l);
          })), c;
        } finally {
          u && ze();
        }
      }, H.prototype.get = function(e, t) {
        var n = this;
        return e && e.constructor === Object ? this.where(e).first(t) : e == null ? Z(new A.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(r) {
          return n.core.get({ trans: r, key: e }).then(function(o) {
            return n.hook.reading.fire(o);
          });
        }).then(t);
      }, H.prototype.where = function(e) {
        if (typeof e == "string") return new this.db.WhereClause(this, e);
        if (W(e)) return new this.db.WhereClause(this, "[".concat(e.join("+"), "]"));
        var t = z(e);
        if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
        var n = this.schema.indexes.concat(this.schema.primKey).filter(function(u) {
          if (u.compound && t.every(function(l) {
            return 0 <= u.keyPath.indexOf(l);
          })) {
            for (var c = 0; c < t.length; ++c) if (t.indexOf(u.keyPath[c]) === -1) return !1;
            return !0;
          }
          return !1;
        }).sort(function(u, c) {
          return u.keyPath.length - c.keyPath.length;
        })[0];
        if (n && this.db._maxKey !== Be) {
          var i = n.keyPath.slice(0, t.length);
          return this.where(i).equals(i.map(function(c) {
            return e[c];
          }));
        }
        !n && de && console.warn("The query ".concat(JSON.stringify(e), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(t.join("+"), "]"));
        var r = this.schema.idxByName;
        function o(u, c) {
          return V(u, c) === 0;
        }
        var a = t.reduce(function(s, c) {
          var l = s[0], p = s[1], s = r[c], v = e[c];
          return [l || s, l || !s ? qe(p, s && s.multi ? function(f) {
            return f = ye(f, c), W(f) && f.some(function(d) {
              return o(v, d);
            });
          } : function(f) {
            return o(v, ye(f, c));
          }) : p];
        }, [null, null]), i = a[0], a = a[1];
        return i ? this.where(i.name).equals(e[i.keyPath]).filter(a) : n ? this.filter(a) : this.where(t).equals("");
      }, H.prototype.filter = function(e) {
        return this.toCollection().and(e);
      }, H.prototype.count = function(e) {
        return this.toCollection().count(e);
      }, H.prototype.offset = function(e) {
        return this.toCollection().offset(e);
      }, H.prototype.limit = function(e) {
        return this.toCollection().limit(e);
      }, H.prototype.each = function(e) {
        return this.toCollection().each(e);
      }, H.prototype.toArray = function(e) {
        return this.toCollection().toArray(e);
      }, H.prototype.toCollection = function() {
        return new this.db.Collection(new this.db.WhereClause(this));
      }, H.prototype.orderBy = function(e) {
        return new this.db.Collection(new this.db.WhereClause(this, W(e) ? "[".concat(e.join("+"), "]") : e));
      }, H.prototype.reverse = function() {
        return this.toCollection().reverse();
      }, H.prototype.mapToClass = function(e) {
        var t, n = this.db, r = this.name;
        function o() {
          return t !== null && t.apply(this, arguments) || this;
        }
        (this.schema.mappedClass = e).prototype instanceof tr && ((function(c, l) {
          if (typeof l != "function" && l !== null) throw new TypeError("Class extends value " + String(l) + " is not a constructor or null");
          function p() {
            this.constructor = c;
          }
          x(c, l), c.prototype = l === null ? Object.create(l) : (p.prototype = l.prototype, new p());
        })(o, t = e), Object.defineProperty(o.prototype, "db", { get: function() {
          return n;
        }, enumerable: !1, configurable: !0 }), o.prototype.table = function() {
          return r;
        }, e = o);
        for (var i = /* @__PURE__ */ new Set(), a = e.prototype; a; a = D(a)) Object.getOwnPropertyNames(a).forEach(function(c) {
          return i.add(c);
        });
        function u(c) {
          if (!c) return c;
          var l, p = Object.create(e.prototype);
          for (l in c) if (!i.has(l)) try {
            p[l] = c[l];
          } catch {
          }
          return p;
        }
        return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = u, this.hook("reading", u), e;
      }, H.prototype.defineClass = function() {
        return this.mapToClass(function(e) {
          B(this, e);
        });
      }, H.prototype.add = function(e, t) {
        var n = this, r = this.schema.primKey, o = r.auto, i = r.keyPath, a = e;
        return i && o && (a = Et(i)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "add", keys: t != null ? [t] : null, values: [a] });
        }).then(function(u) {
          return u.numFailures ? K.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (i) try {
            ue(e, i, u);
          } catch {
          }
          return u;
        });
      }, H.prototype.upsert = function(e, t) {
        var n = this, r = this.schema.primKey.keyPath;
        return this._trans("readwrite", function(o) {
          return n.core.get({ trans: o, key: e }).then(function(i) {
            var a = i ?? {};
            return ir(a, t), r && ue(a, r, e), n.core.mutate({ trans: o, type: "put", values: [a], keys: [e], upsert: !0, updates: { keys: [e], changeSpecs: [t] } }).then(function(u) {
              return u.numFailures ? K.reject(u.failures[0]) : !!i;
            });
          });
        });
      }, H.prototype.update = function(e, t) {
        return typeof e != "object" || W(e) ? this.where(":id").equals(e).modify(t) : (e = ye(e, this.schema.primKey.keyPath), e === void 0 ? Z(new A.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t));
      }, H.prototype.put = function(e, t) {
        var n = this, r = this.schema.primKey, o = r.auto, i = r.keyPath, a = e;
        return i && o && (a = Et(i)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "put", values: [a], keys: t != null ? [t] : null });
        }).then(function(u) {
          return u.numFailures ? K.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (i) try {
            ue(e, i, u);
          } catch {
          }
          return u;
        });
      }, H.prototype.delete = function(e) {
        var t = this;
        return this._trans("readwrite", function(n) {
          return t.core.mutate({ trans: n, type: "delete", keys: [e] }).then(function(r) {
            return It(t, [e], r);
          }).then(function(r) {
            return r.numFailures ? K.reject(r.failures[0]) : void 0;
          });
        });
      }, H.prototype.clear = function() {
        var e = this;
        return this._trans("readwrite", function(t) {
          return e.core.mutate({ trans: t, type: "deleteRange", range: er }).then(function(n) {
            return It(e, null, n);
          });
        }).then(function(t) {
          return t.numFailures ? K.reject(t.failures[0]) : void 0;
        });
      }, H.prototype.bulkGet = function(e) {
        var t = this;
        return this._trans("readonly", function(n) {
          return t.core.getMany({ keys: e, trans: n }).then(function(r) {
            return r.map(function(o) {
              return t.hook.reading.fire(o);
            });
          });
        });
      }, H.prototype.bulkAdd = function(e, t, n) {
        var r = this, o = Array.isArray(t) ? t : void 0, i = (n = n || (o ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var l = r.schema.primKey, u = l.auto, l = l.keyPath;
          if (l && o) throw new A.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
          if (o && o.length !== e.length) throw new A.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, l = l && u ? e.map(Et(l)) : e;
          return r.core.mutate({ trans: a, type: "add", keys: o, values: l, wantResults: i }).then(function(d) {
            var s = d.numFailures, v = d.results, f = d.lastResult, d = d.failures;
            if (s === 0) return i ? v : f;
            throw new Ue("".concat(r.name, ".bulkAdd(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, H.prototype.bulkPut = function(e, t, n) {
        var r = this, o = Array.isArray(t) ? t : void 0, i = (n = n || (o ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var l = r.schema.primKey, u = l.auto, l = l.keyPath;
          if (l && o) throw new A.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
          if (o && o.length !== e.length) throw new A.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, l = l && u ? e.map(Et(l)) : e;
          return r.core.mutate({ trans: a, type: "put", keys: o, values: l, wantResults: i }).then(function(d) {
            var s = d.numFailures, v = d.results, f = d.lastResult, d = d.failures;
            if (s === 0) return i ? v : f;
            throw new Ue("".concat(r.name, ".bulkPut(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, H.prototype.bulkUpdate = function(e) {
        var t = this, n = this.core, r = e.map(function(a) {
          return a.key;
        }), o = e.map(function(a) {
          return a.changes;
        }), i = [];
        return this._trans("readwrite", function(a) {
          return n.getMany({ trans: a, keys: r, cache: "clone" }).then(function(u) {
            var c = [], l = [];
            e.forEach(function(s, v) {
              var f = s.key, d = s.changes, h = u[v];
              if (h) {
                for (var y = 0, m = Object.keys(d); y < m.length; y++) {
                  var g = m[y], b = d[g];
                  if (g === t.schema.primKey.keyPath) {
                    if (V(b, f) !== 0) throw new A.Constraint("Cannot update primary key in bulkUpdate()");
                  } else ue(h, g, b);
                }
                i.push(v), c.push(f), l.push(h);
              }
            });
            var p = c.length;
            return n.mutate({ trans: a, type: "put", keys: c, values: l, updates: { keys: r, changeSpecs: o } }).then(function(s) {
              var v = s.numFailures, f = s.failures;
              if (v === 0) return p;
              for (var d = 0, h = Object.keys(f); d < h.length; d++) {
                var y, m = h[d], g = i[Number(m)];
                g != null && (y = f[m], delete f[m], f[g] = y);
              }
              throw new Ue("".concat(t.name, ".bulkUpdate(): ").concat(v, " of ").concat(p, " operations failed"), f);
            });
          });
        });
      }, H.prototype.bulkDelete = function(e) {
        var t = this, n = e.length;
        return this._trans("readwrite", function(r) {
          return t.core.mutate({ trans: r, type: "delete", keys: e }).then(function(o) {
            return It(t, e, o);
          });
        }).then(function(a) {
          var o = a.numFailures, i = a.lastResult, a = a.failures;
          if (o === 0) return i;
          throw new Ue("".concat(t.name, ".bulkDelete(): ").concat(o, " of ").concat(n, " operations failed"), a);
        });
      }, H);
      function H() {
      }
      function at(e) {
        function t(a, u) {
          if (u) {
            for (var c = arguments.length, l = new Array(c - 1); --c; ) l[c - 1] = arguments[c];
            return n[a].subscribe.apply(null, l), e;
          }
          if (typeof a == "string") return n[a];
        }
        var n = {};
        t.addEventType = i;
        for (var r = 1, o = arguments.length; r < o; ++r) i(arguments[r]);
        return t;
        function i(a, u, c) {
          if (typeof a != "object") {
            var l;
            u = u || Lr;
            var p = { subscribers: [], fire: c = c || Y, subscribe: function(s) {
              p.subscribers.indexOf(s) === -1 && (p.subscribers.push(s), p.fire = u(p.fire, s));
            }, unsubscribe: function(s) {
              p.subscribers = p.subscribers.filter(function(v) {
                return v !== s;
              }), p.fire = p.subscribers.reduce(u, c);
            } };
            return n[a] = t[a] = p;
          }
          z(l = a).forEach(function(s) {
            var v = l[s];
            if (W(v)) i(s, l[s][0], l[s][1]);
            else {
              if (v !== "asap") throw new A.InvalidArgument("Invalid event config");
              var f = i(s, et, function() {
                for (var d = arguments.length, h = new Array(d); d--; ) h[d] = arguments[d];
                f.subscribers.forEach(function(y) {
                  Vn(function() {
                    y.apply(null, h);
                  });
                });
              });
            }
          });
        }
      }
      function ut(e, t) {
        return Fe(t).from({ prototype: e }), t;
      }
      function He(e, t) {
        return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
      }
      function dn(e, t) {
        e.filter = qe(e.filter, t);
      }
      function hn(e, t, n) {
        var r = e.replayFilter;
        e.replayFilter = r ? function() {
          return qe(r(), t());
        } : t, e.justLimit = n && !r;
      }
      function Kt(e, t) {
        if (e.isPrimKey) return t.primaryKey;
        var n = t.getIndexByKeyPath(e.index);
        if (!n) throw new A.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
        return n;
      }
      function ur(e, t, n) {
        var r = Kt(e, t.schema);
        return t.openCursor({ trans: n, values: !e.keysOnly, reverse: e.dir === "prev", unique: !!e.unique, query: { index: r, range: e.range } });
      }
      function Dt(e, t, n, r) {
        var o = e.replayFilter ? qe(e.filter, e.replayFilter()) : e.filter;
        if (e.or) {
          var i = {}, a = function(u, c, l) {
            var p, s;
            o && !o(c, l, function(v) {
              return c.stop(v);
            }, function(v) {
              return c.fail(v);
            }) || ((s = "" + (p = c.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(p)), X(i, s) || (i[s] = !0, t(u, c, l)));
          };
          return Promise.all([e.or._iterate(a, n), sr(ur(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)]);
        }
        return sr(ur(e, r, n), qe(e.algorithm, o), t, !e.keysOnly && e.valueMapper);
      }
      function sr(e, t, n, r) {
        var o = Q(r ? function(i, a, u) {
          return n(r(i), a, u);
        } : n);
        return e.then(function(i) {
          if (i) return i.start(function() {
            var a = function() {
              return i.continue();
            };
            t && !t(i, function(u) {
              return a = u;
            }, function(u) {
              i.stop(u), a = Y;
            }, function(u) {
              i.fail(u), a = Y;
            }) || o(i.value, i, function(u) {
              return a = u;
            }), a();
          });
        });
      }
      var Hr = (L.prototype._read = function(e, t) {
        var n = this._ctx;
        return n.error ? n.table._trans(null, Z.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
      }, L.prototype._write = function(e) {
        var t = this._ctx;
        return t.error ? t.table._trans(null, Z.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
      }, L.prototype._addAlgorithm = function(e) {
        var t = this._ctx;
        t.algorithm = qe(t.algorithm, e);
      }, L.prototype._iterate = function(e, t) {
        return Dt(this._ctx, e, t, this._ctx.table.core);
      }, L.prototype.clone = function(e) {
        var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
        return e && B(n, e), t._ctx = n, t;
      }, L.prototype.raw = function() {
        return this._ctx.valueMapper = null, this;
      }, L.prototype.each = function(e) {
        var t = this._ctx;
        return this._read(function(n) {
          return Dt(t, e, n, t.table.core);
        });
      }, L.prototype.count = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx, o = r.table.core;
          if (He(r, !0)) return o.count({ trans: n, query: { index: Kt(r, o.schema), range: r.range } }).then(function(a) {
            return Math.min(a, r.limit);
          });
          var i = 0;
          return Dt(r, function() {
            return ++i, !1;
          }, n, o).then(function() {
            return i;
          });
        }).then(e);
      }, L.prototype.sortBy = function(e, t) {
        var n = e.split(".").reverse(), r = n[0], o = n.length - 1;
        function i(c, l) {
          return l ? i(c[n[l]], l - 1) : c[r];
        }
        var a = this._ctx.dir === "next" ? 1 : -1;
        function u(c, l) {
          return V(i(c, o), i(l, o)) * a;
        }
        return this.toArray(function(c) {
          return c.sort(u);
        }).then(t);
      }, L.prototype.toArray = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx;
          if (r.dir === "next" && He(r, !0) && 0 < r.limit) {
            var o = r.valueMapper, i = Kt(r, r.table.core.schema);
            return r.table.core.query({ trans: n, limit: r.limit, values: !0, query: { index: i, range: r.range } }).then(function(u) {
              return u = u.result, o ? u.map(o) : u;
            });
          }
          var a = [];
          return Dt(r, function(u) {
            return a.push(u);
          }, n, r.table.core).then(function() {
            return a;
          });
        }, e);
      }, L.prototype.offset = function(e) {
        var t = this._ctx;
        return e <= 0 || (t.offset += e, He(t) ? hn(t, function() {
          var n = e;
          return function(r, o) {
            return n === 0 || (n === 1 ? --n : o(function() {
              r.advance(n), n = 0;
            }), !1);
          };
        }) : hn(t, function() {
          var n = e;
          return function() {
            return --n < 0;
          };
        })), this;
      }, L.prototype.limit = function(e) {
        return this._ctx.limit = Math.min(this._ctx.limit, e), hn(this._ctx, function() {
          var t = e;
          return function(n, r, o) {
            return --t <= 0 && r(o), 0 <= t;
          };
        }, !0), this;
      }, L.prototype.until = function(e, t) {
        return dn(this._ctx, function(n, r, o) {
          return !e(n.value) || (r(o), t);
        }), this;
      }, L.prototype.first = function(e) {
        return this.limit(1).toArray(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.last = function(e) {
        return this.reverse().first(e);
      }, L.prototype.filter = function(e) {
        var t;
        return dn(this._ctx, function(n) {
          return e(n.value);
        }), (t = this._ctx).isMatch = qe(t.isMatch, e), this;
      }, L.prototype.and = function(e) {
        return this.filter(e);
      }, L.prototype.or = function(e) {
        return new this.db.WhereClause(this._ctx.table, e, this);
      }, L.prototype.reverse = function() {
        return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
      }, L.prototype.desc = function() {
        return this.reverse();
      }, L.prototype.eachKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.key, r);
        });
      }, L.prototype.eachUniqueKey = function(e) {
        return this._ctx.unique = "unique", this.eachKey(e);
      }, L.prototype.eachPrimaryKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.primaryKey, r);
        });
      }, L.prototype.keys = function(e) {
        var t = this._ctx;
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, o) {
          n.push(o.key);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.primaryKeys = function(e) {
        var t = this._ctx;
        if (t.dir === "next" && He(t, !0) && 0 < t.limit) return this._read(function(r) {
          var o = Kt(t, t.table.core.schema);
          return t.table.core.query({ trans: r, values: !1, limit: t.limit, query: { index: o, range: t.range } });
        }).then(function(r) {
          return r.result;
        }).then(e);
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, o) {
          n.push(o.primaryKey);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.uniqueKeys = function(e) {
        return this._ctx.unique = "unique", this.keys(e);
      }, L.prototype.firstKey = function(e) {
        return this.limit(1).keys(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.lastKey = function(e) {
        return this.reverse().firstKey(e);
      }, L.prototype.distinct = function() {
        var e = this._ctx, e = e.index && e.table.schema.idxByName[e.index];
        if (!e || !e.multi) return this;
        var t = {};
        return dn(this._ctx, function(o) {
          var r = o.primaryKey.toString(), o = X(t, r);
          return t[r] = !0, !o;
        }), this;
      }, L.prototype.modify = function(e) {
        var t = this, n = this._ctx;
        return this._write(function(r) {
          var o = typeof e == "function" ? e : function(h) {
            return ir(h, e);
          }, i = n.table.core, l = i.schema.primaryKey, a = l.outbound, u = l.extractKey, c = 200, l = t.db._options.modifyChunkSize;
          l && (c = typeof l == "object" ? l[i.name] || l["*"] || 200 : l);
          function p(h, g) {
            var m = g.failures, g = g.numFailures;
            v += h - g;
            for (var b = 0, w = z(m); b < w.length; b++) {
              var P = w[b];
              s.push(m[P]);
            }
          }
          var s = [], v = 0, f = [], d = e === cr;
          return t.clone().primaryKeys().then(function(h) {
            function y(g) {
              var b = Math.min(c, h.length - g), w = h.slice(g, g + b);
              return (d ? Promise.resolve([]) : i.getMany({ trans: r, keys: w, cache: "immutable" })).then(function(P) {
                var E = [], S = [], O = a ? [] : null, I = d ? w : [];
                if (!d) for (var j = 0; j < b; ++j) {
                  var T = P[j], N = { value: je(T), primKey: h[g + j] };
                  o.call(N, N.value, N) !== !1 && (N.value == null ? I.push(h[g + j]) : a || V(u(T), u(N.value)) === 0 ? (S.push(N.value), a && O.push(h[g + j])) : (I.push(h[g + j]), E.push(N.value)));
                }
                return Promise.resolve(0 < E.length && i.mutate({ trans: r, type: "add", values: E }).then(function(R) {
                  for (var M in R.failures) I.splice(parseInt(M), 1);
                  p(E.length, R);
                })).then(function() {
                  return (0 < S.length || m && typeof e == "object") && i.mutate({ trans: r, type: "put", keys: O, values: S, criteria: m, changeSpec: typeof e != "function" && e, isAdditionalChunk: 0 < g }).then(function(R) {
                    return p(S.length, R);
                  });
                }).then(function() {
                  return (0 < I.length || m && d) && i.mutate({ trans: r, type: "delete", keys: I, criteria: m, isAdditionalChunk: 0 < g }).then(function(R) {
                    return It(n.table, I, R);
                  }).then(function(R) {
                    return p(I.length, R);
                  });
                }).then(function() {
                  return h.length > g + b && y(g + c);
                });
              });
            }
            var m = He(n) && n.limit === 1 / 0 && (typeof e != "function" || d) && { index: n.index, range: n.range };
            return y(0).then(function() {
              if (0 < s.length) throw new mt("Error modifying one or more objects", s, v, f);
              return h.length;
            });
          });
        });
      }, L.prototype.delete = function() {
        var e = this._ctx, t = e.range;
        return !He(e) || e.table.schema.yProps || !e.isPrimKey && t.type !== 3 ? this.modify(cr) : this._write(function(n) {
          var r = e.table.core.schema.primaryKey, o = t;
          return e.table.core.count({ trans: n, query: { index: r, range: o } }).then(function(i) {
            return e.table.core.mutate({ trans: n, type: "deleteRange", range: o }).then(function(c) {
              var u = c.failures, c = c.numFailures;
              if (c) throw new mt("Could not delete some values", Object.keys(u).map(function(l) {
                return u[l];
              }), i - c);
              return i - c;
            });
          });
        });
      }, L);
      function L() {
      }
      var cr = function(e, t) {
        return t.value = null;
      };
      function Gr(e, t) {
        return e < t ? -1 : e === t ? 0 : 1;
      }
      function Qr(e, t) {
        return t < e ? -1 : e === t ? 0 : 1;
      }
      function ce(e, t, n) {
        return e = e instanceof fr ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
      }
      function Ge(e) {
        return new e.Collection(e, function() {
          return lr("");
        }).limit(0);
      }
      function Tt(e, t, n, r) {
        var o, i, a, u, c, l, p, s = n.length;
        if (!n.every(function(d) {
          return typeof d == "string";
        })) return ce(e, Zn);
        function v(d) {
          o = d === "next" ? function(y) {
            return y.toUpperCase();
          } : function(y) {
            return y.toLowerCase();
          }, i = d === "next" ? function(y) {
            return y.toLowerCase();
          } : function(y) {
            return y.toUpperCase();
          }, a = d === "next" ? Gr : Qr;
          var h = n.map(function(y) {
            return { lower: i(y), upper: o(y) };
          }).sort(function(y, m) {
            return a(y.lower, m.lower);
          });
          u = h.map(function(y) {
            return y.upper;
          }), c = h.map(function(y) {
            return y.lower;
          }), p = (l = d) === "next" ? "" : r;
        }
        v("next"), e = new e.Collection(e, function() {
          return Se(u[0], c[s - 1] + r);
        }), e._ondirectionchange = function(d) {
          v(d);
        };
        var f = 0;
        return e._addAlgorithm(function(d, h, y) {
          var m = d.key;
          if (typeof m != "string") return !1;
          var g = i(m);
          if (t(g, c, f)) return !0;
          for (var b = null, w = f; w < s; ++w) {
            var P = (function(E, S, O, I, j, T) {
              for (var N = Math.min(E.length, I.length), R = -1, M = 0; M < N; ++M) {
                var le = S[M];
                if (le !== I[M]) return j(E[M], O[M]) < 0 ? E.substr(0, M) + O[M] + O.substr(M + 1) : j(E[M], I[M]) < 0 ? E.substr(0, M) + I[M] + O.substr(M + 1) : 0 <= R ? E.substr(0, R) + S[R] + O.substr(R + 1) : null;
                j(E[M], le) < 0 && (R = M);
              }
              return N < I.length && T === "next" ? E + O.substr(E.length) : N < E.length && T === "prev" ? E.substr(0, O.length) : R < 0 ? null : E.substr(0, R) + I[R] + O.substr(R + 1);
            })(m, g, u[w], c[w], a, l);
            P === null && b === null ? f = w + 1 : (b === null || 0 < a(b, P)) && (b = P);
          }
          return h(b !== null ? function() {
            d.continue(b + p);
          } : y), !1;
        }), e;
      }
      function Se(e, t, n, r) {
        return { type: 2, lower: e, upper: t, lowerOpen: n, upperOpen: r };
      }
      function lr(e) {
        return { type: 1, lower: e, upper: e };
      }
      var fr = (Object.defineProperty(ne.prototype, "Collection", { get: function() {
        return this._ctx.table.db.Collection;
      }, enumerable: !1, configurable: !0 }), ne.prototype.between = function(e, t, n, r) {
        n = n !== !1, r = r === !0;
        try {
          return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Ge(this) : new this.Collection(this, function() {
            return Se(e, t, !n, !r);
          });
        } catch {
          return ce(this, me);
        }
      }, ne.prototype.equals = function(e) {
        return e == null ? ce(this, me) : new this.Collection(this, function() {
          return lr(e);
        });
      }, ne.prototype.above = function(e) {
        return e == null ? ce(this, me) : new this.Collection(this, function() {
          return Se(e, void 0, !0);
        });
      }, ne.prototype.aboveOrEqual = function(e) {
        return e == null ? ce(this, me) : new this.Collection(this, function() {
          return Se(e, void 0, !1);
        });
      }, ne.prototype.below = function(e) {
        return e == null ? ce(this, me) : new this.Collection(this, function() {
          return Se(void 0, e, !1, !0);
        });
      }, ne.prototype.belowOrEqual = function(e) {
        return e == null ? ce(this, me) : new this.Collection(this, function() {
          return Se(void 0, e);
        });
      }, ne.prototype.startsWith = function(e) {
        return typeof e != "string" ? ce(this, Zn) : this.between(e, e + Be, !0, !0);
      }, ne.prototype.startsWithIgnoreCase = function(e) {
        return e === "" ? this.startsWith(e) : Tt(this, function(t, n) {
          return t.indexOf(n[0]) === 0;
        }, [e], Be);
      }, ne.prototype.equalsIgnoreCase = function(e) {
        return Tt(this, function(t, n) {
          return t === n[0];
        }, [e], "");
      }, ne.prototype.anyOfIgnoreCase = function() {
        var e = ve.apply(Ve, arguments);
        return e.length === 0 ? Ge(this) : Tt(this, function(t, n) {
          return n.indexOf(t) !== -1;
        }, e, "");
      }, ne.prototype.startsWithAnyOfIgnoreCase = function() {
        var e = ve.apply(Ve, arguments);
        return e.length === 0 ? Ge(this) : Tt(this, function(t, n) {
          return n.some(function(r) {
            return t.indexOf(r) === 0;
          });
        }, e, Be);
      }, ne.prototype.anyOf = function() {
        var e = this, t = ve.apply(Ve, arguments), n = this._cmp;
        try {
          t.sort(n);
        } catch {
          return ce(this, me);
        }
        if (t.length === 0) return Ge(this);
        var r = new this.Collection(this, function() {
          return Se(t[0], t[t.length - 1]);
        });
        r._ondirectionchange = function(i) {
          n = i === "next" ? e._ascending : e._descending, t.sort(n);
        };
        var o = 0;
        return r._addAlgorithm(function(i, a, u) {
          for (var c = i.key; 0 < n(c, t[o]); ) if (++o === t.length) return a(u), !1;
          return n(c, t[o]) === 0 || (a(function() {
            i.continue(t[o]);
          }), !1);
        }), r;
      }, ne.prototype.notEqual = function(e) {
        return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], { includeLowers: !1, includeUppers: !1 });
      }, ne.prototype.noneOf = function() {
        var e = ve.apply(Ve, arguments);
        if (e.length === 0) return new this.Collection(this);
        try {
          e.sort(this._ascending);
        } catch {
          return ce(this, me);
        }
        var t = e.reduce(function(n, r) {
          return n ? n.concat([[n[n.length - 1][1], r]]) : [[-1 / 0, r]];
        }, null);
        return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, { includeLowers: !1, includeUppers: !1 });
      }, ne.prototype.inAnyRange = function(m, t) {
        var n = this, r = this._cmp, o = this._ascending, i = this._descending, a = this._min, u = this._max;
        if (m.length === 0) return Ge(this);
        if (!m.every(function(g) {
          return g[0] !== void 0 && g[1] !== void 0 && o(g[0], g[1]) <= 0;
        })) return ce(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", A.InvalidArgument);
        var c = !t || t.includeLowers !== !1, l = t && t.includeUppers === !0, p, s = o;
        function v(g, b) {
          return s(g[0], b[0]);
        }
        try {
          (p = m.reduce(function(g, b) {
            for (var w = 0, P = g.length; w < P; ++w) {
              var E = g[w];
              if (r(b[0], E[1]) < 0 && 0 < r(b[1], E[0])) {
                E[0] = a(E[0], b[0]), E[1] = u(E[1], b[1]);
                break;
              }
            }
            return w === P && g.push(b), g;
          }, [])).sort(v);
        } catch {
          return ce(this, me);
        }
        var f = 0, d = l ? function(g) {
          return 0 < o(g, p[f][1]);
        } : function(g) {
          return 0 <= o(g, p[f][1]);
        }, h = c ? function(g) {
          return 0 < i(g, p[f][0]);
        } : function(g) {
          return 0 <= i(g, p[f][0]);
        }, y = d, m = new this.Collection(this, function() {
          return Se(p[0][0], p[p.length - 1][1], !c, !l);
        });
        return m._ondirectionchange = function(g) {
          s = g === "next" ? (y = d, o) : (y = h, i), p.sort(v);
        }, m._addAlgorithm(function(g, b, w) {
          for (var P, E = g.key; y(E); ) if (++f === p.length) return b(w), !1;
          return !d(P = E) && !h(P) || (n._cmp(E, p[f][1]) === 0 || n._cmp(E, p[f][0]) === 0 || b(function() {
            s === o ? g.continue(p[f][0]) : g.continue(p[f][1]);
          }), !1);
        }), m;
      }, ne.prototype.startsWithAnyOf = function() {
        var e = ve.apply(Ve, arguments);
        return e.every(function(t) {
          return typeof t == "string";
        }) ? e.length === 0 ? Ge(this) : this.inAnyRange(e.map(function(t) {
          return [t, t + Be];
        })) : ce(this, "startsWithAnyOf() only works with strings");
      }, ne);
      function ne() {
      }
      function he(e) {
        return Q(function(t) {
          return st(t), e(t.target.error), !1;
        });
      }
      function st(e) {
        e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
      }
      var ct = "storagemutated", pn = "x-storagemutated-1", Pe = at(null, ct), Xr = (pe.prototype._lock = function() {
        return Je(!C.global), ++this._reculock, this._reculock !== 1 || C.global || (C.lockOwnerFor = this), this;
      }, pe.prototype._unlock = function() {
        if (Je(!C.global), --this._reculock == 0) for (C.global || (C.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked(); ) {
          var e = this._blockedFuncs.shift();
          try {
            Ae(e[1], e[0]);
          } catch {
          }
        }
        return this;
      }, pe.prototype._locked = function() {
        return this._reculock && C.lockOwnerFor !== this;
      }, pe.prototype.create = function(e) {
        var t = this;
        if (!this.mode) return this;
        var n = this.db.idbdb, r = this.db._state.dbOpenError;
        if (Je(!this.idbtrans), !e && !n) switch (r && r.name) {
          case "DatabaseClosedError":
            throw new A.DatabaseClosed(r);
          case "MissingAPIError":
            throw new A.MissingAPI(r.message, r);
          default:
            throw new A.OpenFailed(r);
        }
        if (!this.active) throw new A.TransactionInactive();
        return Je(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = Q(function(o) {
          st(o), t._reject(e.error);
        }), e.onabort = Q(function(o) {
          st(o), t.active && t._reject(new A.Abort(e.error)), t.active = !1, t.on("abort").fire(o);
        }), e.oncomplete = Q(function() {
          t.active = !1, t._resolve(), "mutatedParts" in e && Pe.storagemutated.fire(e.mutatedParts);
        }), this;
      }, pe.prototype._promise = function(e, t, n) {
        var r = this;
        if (e === "readwrite" && this.mode !== "readwrite") return Z(new A.ReadOnly("Transaction is readonly"));
        if (!this.active) return Z(new A.TransactionInactive());
        if (this._locked()) return new K(function(i, a) {
          r._blockedFuncs.push([function() {
            r._promise(e, t, n).then(i, a);
          }, C]);
        });
        if (n) return _e(function() {
          var i = new K(function(a, u) {
            r._lock();
            var c = t(a, u, r);
            c && c.then && c.then(a, u);
          });
          return i.finally(function() {
            return r._unlock();
          }), i._lib = !0, i;
        });
        var o = new K(function(i, a) {
          var u = t(i, a, r);
          u && u.then && u.then(i, a);
        });
        return o._lib = !0, o;
      }, pe.prototype._root = function() {
        return this.parent ? this.parent._root() : this;
      }, pe.prototype.waitFor = function(e) {
        var t, n = this._root(), r = K.resolve(e);
        n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
          return r;
        }) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), (function i() {
          for (++n._spinCount; n._waitingQueue.length; ) n._waitingQueue.shift()();
          n._waitingFor && (t.get(-1 / 0).onsuccess = i);
        })());
        var o = n._waitingFor;
        return new K(function(i, a) {
          r.then(function(u) {
            return n._waitingQueue.push(Q(i.bind(null, u)));
          }, function(u) {
            return n._waitingQueue.push(Q(a.bind(null, u)));
          }).finally(function() {
            n._waitingFor === o && (n._waitingFor = null);
          });
        });
      }, pe.prototype.abort = function() {
        this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new A.Abort()));
      }, pe.prototype.table = function(e) {
        var t = this._memoizedTables || (this._memoizedTables = {});
        if (X(t, e)) return t[e];
        var n = this.schema[e];
        if (!n) throw new A.NotFound("Table " + e + " not part of transaction");
        return n = new this.db.Table(e, n, this), n.core = this.db.core.table(e), t[e] = n;
      }, pe);
      function pe() {
      }
      function yn(e, t, n, r, o, i, a, u) {
        return { name: e, keyPath: t, unique: n, multi: r, auto: o, compound: i, src: (n && !a ? "&" : "") + (r ? "*" : "") + (o ? "++" : "") + dr(t), type: u };
      }
      function dr(e) {
        return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
      }
      function vn(e, t, n) {
        return { name: e, primKey: t, indexes: n, mappedClass: null, idxByName: (r = function(o) {
          return [o.name, o];
        }, n.reduce(function(o, i, a) {
          return a = r(i, a), a && (o[a[0]] = a[1]), o;
        }, {})) };
        var r;
      }
      var lt = function(e) {
        try {
          return e.only([[]]), lt = function() {
            return [[]];
          }, [[]];
        } catch {
          return lt = function() {
            return Be;
          }, Be;
        }
      };
      function mn(e) {
        return e == null ? function() {
        } : typeof e == "string" ? (t = e).split(".").length === 1 ? function(n) {
          return n[t];
        } : function(n) {
          return ye(n, t);
        } : function(n) {
          return ye(n, e);
        };
        var t;
      }
      function hr(e) {
        return [].slice.call(e);
      }
      var Jr = 0;
      function ft(e) {
        return e == null ? ":id" : typeof e == "string" ? e : "[".concat(e.join("+"), "]");
      }
      function Zr(e, t, c) {
        function r(y) {
          if (y.type === 3) return null;
          if (y.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
          var f = y.lower, d = y.upper, h = y.lowerOpen, y = y.upperOpen;
          return f === void 0 ? d === void 0 ? null : t.upperBound(d, !!y) : d === void 0 ? t.lowerBound(f, !!h) : t.bound(f, d, !!h, !!y);
        }
        function o(v) {
          var f, d = v.name;
          return { name: d, schema: v, mutate: function(h) {
            var y = h.trans, m = h.type, g = h.keys, b = h.values, w = h.range;
            return new Promise(function(P, E) {
              P = Q(P);
              var S = y.objectStore(d), O = S.keyPath == null, I = m === "put" || m === "add";
              if (!I && m !== "delete" && m !== "deleteRange") throw new Error("Invalid operation type: " + m);
              var j, T = (g || b || { length: 1 }).length;
              if (g && b && g.length !== b.length) throw new Error("Given keys array must have same length as given values array.");
              if (T === 0) return P({ numFailures: 0, failures: {}, results: [], lastResult: void 0 });
              function N(ae) {
                ++le, st(ae);
              }
              var R = [], M = [], le = 0;
              if (m === "deleteRange") {
                if (w.type === 4) return P({ numFailures: le, failures: M, results: [], lastResult: void 0 });
                w.type === 3 ? R.push(j = S.clear()) : R.push(j = S.delete(r(w)));
              } else {
                var O = I ? O ? [b, g] : [b, null] : [g, null], q = O[0], oe = O[1];
                if (I) for (var ie = 0; ie < T; ++ie) R.push(j = oe && oe[ie] !== void 0 ? S[m](q[ie], oe[ie]) : S[m](q[ie])), j.onerror = N;
                else for (ie = 0; ie < T; ++ie) R.push(j = S[m](q[ie])), j.onerror = N;
              }
              function $t(ae) {
                ae = ae.target.result, R.forEach(function(Me, Bn) {
                  return Me.error != null && (M[Bn] = Me.error);
                }), P({ numFailures: le, failures: M, results: m === "delete" ? g : R.map(function(Me) {
                  return Me.result;
                }), lastResult: ae });
              }
              j.onerror = function(ae) {
                N(ae), $t(ae);
              }, j.onsuccess = $t;
            });
          }, getMany: function(h) {
            var y = h.trans, m = h.keys;
            return new Promise(function(g, b) {
              g = Q(g);
              for (var w, P = y.objectStore(d), E = m.length, S = new Array(E), O = 0, I = 0, j = function(R) {
                R = R.target, S[R._pos] = R.result, ++I === O && g(S);
              }, T = he(b), N = 0; N < E; ++N) m[N] != null && ((w = P.get(m[N]))._pos = N, w.onsuccess = j, w.onerror = T, ++O);
              O === 0 && g(S);
            });
          }, get: function(h) {
            var y = h.trans, m = h.key;
            return new Promise(function(g, b) {
              g = Q(g);
              var w = y.objectStore(d).get(m);
              w.onsuccess = function(P) {
                return g(P.target.result);
              }, w.onerror = he(b);
            });
          }, query: (f = l, function(h) {
            return new Promise(function(y, m) {
              y = Q(y);
              var g, b, w, O = h.trans, P = h.values, E = h.limit, j = h.query, S = E === 1 / 0 ? void 0 : E, I = j.index, j = j.range, O = O.objectStore(d), I = I.isPrimaryKey ? O : O.index(I.name), j = r(j);
              if (E === 0) return y({ result: [] });
              f ? ((S = P ? I.getAll(j, S) : I.getAllKeys(j, S)).onsuccess = function(T) {
                return y({ result: T.target.result });
              }, S.onerror = he(m)) : (g = 0, b = !P && "openKeyCursor" in I ? I.openKeyCursor(j) : I.openCursor(j), w = [], b.onsuccess = function(T) {
                var N = b.result;
                return N ? (w.push(P ? N.value : N.primaryKey), ++g === E ? y({ result: w }) : void N.continue()) : y({ result: w });
              }, b.onerror = he(m));
            });
          }), openCursor: function(h) {
            var y = h.trans, m = h.values, g = h.query, b = h.reverse, w = h.unique;
            return new Promise(function(P, E) {
              P = Q(P);
              var I = g.index, S = g.range, O = y.objectStore(d), O = I.isPrimaryKey ? O : O.index(I.name), I = b ? w ? "prevunique" : "prev" : w ? "nextunique" : "next", j = !m && "openKeyCursor" in O ? O.openKeyCursor(r(S), I) : O.openCursor(r(S), I);
              j.onerror = he(E), j.onsuccess = Q(function(T) {
                var N, R, M, le, q = j.result;
                q ? (q.___id = ++Jr, q.done = !1, N = q.continue.bind(q), R = (R = q.continuePrimaryKey) && R.bind(q), M = q.advance.bind(q), le = function() {
                  throw new Error("Cursor not stopped");
                }, q.trans = y, q.stop = q.continue = q.continuePrimaryKey = q.advance = function() {
                  throw new Error("Cursor not started");
                }, q.fail = Q(E), q.next = function() {
                  var oe = this, ie = 1;
                  return this.start(function() {
                    return ie-- ? oe.continue() : oe.stop();
                  }).then(function() {
                    return oe;
                  });
                }, q.start = function(oe) {
                  function ie() {
                    if (j.result) try {
                      oe();
                    } catch (ae) {
                      q.fail(ae);
                    }
                    else q.done = !0, q.start = function() {
                      throw new Error("Cursor behind last entry");
                    }, q.stop();
                  }
                  var $t = new Promise(function(ae, Me) {
                    ae = Q(ae), j.onerror = he(Me), q.fail = Me, q.stop = function(Bn) {
                      q.stop = q.continue = q.continuePrimaryKey = q.advance = le, ae(Bn);
                    };
                  });
                  return j.onsuccess = Q(function(ae) {
                    j.onsuccess = ie, ie();
                  }), q.continue = N, q.continuePrimaryKey = R, q.advance = M, ie(), $t;
                }, P(q)) : P(null);
              }, E);
            });
          }, count: function(h) {
            var y = h.query, m = h.trans, g = y.index, b = y.range;
            return new Promise(function(w, P) {
              var E = m.objectStore(d), S = g.isPrimaryKey ? E : E.index(g.name), E = r(b), S = E ? S.count(E) : S.count();
              S.onsuccess = Q(function(O) {
                return w(O.target.result);
              }), S.onerror = he(P);
            });
          } };
        }
        var i, a, u, p = (a = c, u = hr((i = e).objectStoreNames), { schema: { name: i.name, tables: u.map(function(v) {
          return a.objectStore(v);
        }).map(function(v) {
          var f = v.keyPath, y = v.autoIncrement, d = W(f), h = {}, y = { name: v.name, primaryKey: { name: null, isPrimaryKey: !0, outbound: f == null, compound: d, keyPath: f, autoIncrement: y, unique: !0, extractKey: mn(f) }, indexes: hr(v.indexNames).map(function(m) {
            return v.index(m);
          }).map(function(w) {
            var g = w.name, b = w.unique, P = w.multiEntry, w = w.keyPath, P = { name: g, compound: W(w), keyPath: w, unique: b, multiEntry: P, extractKey: mn(w) };
            return h[ft(w)] = P;
          }), getIndexByKeyPath: function(m) {
            return h[ft(m)];
          } };
          return h[":id"] = y.primaryKey, f != null && (h[ft(f)] = y.primaryKey), y;
        }) }, hasGetAll: 0 < u.length && "getAll" in a.objectStore(u[0]) && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) }), c = p.schema, l = p.hasGetAll, p = c.tables.map(o), s = {};
        return p.forEach(function(v) {
          return s[v.name] = v;
        }), { stack: "dbcore", transaction: e.transaction.bind(e), table: function(v) {
          if (!s[v]) throw new Error("Table '".concat(v, "' not found"));
          return s[v];
        }, MIN_KEY: -1 / 0, MAX_KEY: lt(t), schema: c };
      }
      function eo(e, t, n, r) {
        var o = n.IDBKeyRange;
        return n.indexedDB, { dbcore: (r = Zr(t, o, r), e.dbcore.reduce(function(i, a) {
          return a = a.create, k(k({}, i), a(i));
        }, r)) };
      }
      function Ct(e, r) {
        var n = r.db, r = eo(e._middlewares, n, e._deps, r);
        e.core = r.dbcore, e.tables.forEach(function(o) {
          var i = o.name;
          e.core.schema.tables.some(function(a) {
            return a.name === i;
          }) && (o.core = e.core.table(i), e[i] instanceof e.Table && (e[i].core = o.core));
        });
      }
      function At(e, t, n, r) {
        n.forEach(function(o) {
          var i = r[o];
          t.forEach(function(a) {
            var u = (function c(l, p) {
              return Dr(l, p) || (l = D(l)) && c(l, p);
            })(a, o);
            (!u || "value" in u && u.value === void 0) && (a === e.Transaction.prototype || a instanceof e.Transaction ? be(a, o, { get: function() {
              return this.table(o);
            }, set: function(c) {
              yt(this, o, { value: c, writable: !0, configurable: !0, enumerable: !0 });
            } }) : a[o] = new e.Table(o, i));
          });
        });
      }
      function gn(e, t) {
        t.forEach(function(n) {
          for (var r in n) n[r] instanceof e.Table && delete n[r];
        });
      }
      function to(e, t) {
        return e._cfg.version - t._cfg.version;
      }
      function no(e, t, n, r) {
        var o = e._dbSchema;
        n.objectStoreNames.contains("$meta") && !o.$meta && (o.$meta = vn("$meta", yr("")[0], []), e._storeNames.push("$meta"));
        var i = e._createTransaction("readwrite", e._storeNames, o);
        i.create(n), i._completion.catch(r);
        var a = i._reject.bind(i), u = C.transless || C;
        _e(function() {
          return C.trans = i, C.transless = u, t !== 0 ? (Ct(e, n), l = t, ((c = i).storeNames.includes("$meta") ? c.table("$meta").get("version").then(function(p) {
            return p ?? l;
          }) : K.resolve(l)).then(function(p) {
            return v = p, f = i, d = n, h = [], p = (s = e)._versions, y = s._dbSchema = qt(0, s.idbdb, d), (p = p.filter(function(m) {
              return m._cfg.version >= v;
            })).length !== 0 ? (p.forEach(function(m) {
              h.push(function() {
                var g = y, b = m._cfg.dbschema;
                Nt(s, g, d), Nt(s, b, d), y = s._dbSchema = b;
                var w = bn(g, b);
                w.add.forEach(function(I) {
                  wn(d, I[0], I[1].primKey, I[1].indexes);
                }), w.change.forEach(function(I) {
                  if (I.recreate) throw new A.Upgrade("Not yet support for changing primary key");
                  var j = d.objectStore(I.name);
                  I.add.forEach(function(T) {
                    return Bt(j, T);
                  }), I.change.forEach(function(T) {
                    j.deleteIndex(T.name), Bt(j, T);
                  }), I.del.forEach(function(T) {
                    return j.deleteIndex(T);
                  });
                });
                var P = m._cfg.contentUpgrade;
                if (P && m._cfg.version > v) {
                  Ct(s, d), f._memoizedTables = {};
                  var E = Ln(b);
                  w.del.forEach(function(I) {
                    E[I] = g[I];
                  }), gn(s, [s.Transaction.prototype]), At(s, [s.Transaction.prototype], z(E), E), f.schema = E;
                  var S, O = Jt(P);
                  return O && Ye(), w = K.follow(function() {
                    var I;
                    (S = P(f)) && O && (I = xe.bind(null, null), S.then(I, I));
                  }), S && typeof S.then == "function" ? K.resolve(S) : w.then(function() {
                    return S;
                  });
                }
              }), h.push(function(g) {
                var b, w, P = m._cfg.dbschema;
                b = P, w = g, [].slice.call(w.db.objectStoreNames).forEach(function(E) {
                  return b[E] == null && w.db.deleteObjectStore(E);
                }), gn(s, [s.Transaction.prototype]), At(s, [s.Transaction.prototype], s._storeNames, s._dbSchema), f.schema = s._dbSchema;
              }), h.push(function(g) {
                s.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(s.idbdb.version / 10) === m._cfg.version ? (s.idbdb.deleteObjectStore("$meta"), delete s._dbSchema.$meta, s._storeNames = s._storeNames.filter(function(b) {
                  return b !== "$meta";
                })) : g.objectStore("$meta").put(m._cfg.version, "version"));
              });
            }), (function m() {
              return h.length ? K.resolve(h.shift()(f.idbtrans)).then(m) : K.resolve();
            })().then(function() {
              pr(y, d);
            })) : K.resolve();
            var s, v, f, d, h, y;
          }).catch(a)) : (z(o).forEach(function(p) {
            wn(n, p, o[p].primKey, o[p].indexes);
          }), Ct(e, n), void K.follow(function() {
            return e.on.populate.fire(i);
          }).catch(a));
          var c, l;
        });
      }
      function ro(e, t) {
        pr(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
        var n = qt(0, e.idbdb, t);
        Nt(e, e._dbSchema, t);
        for (var r = 0, o = bn(n, e._dbSchema).change; r < o.length; r++) {
          var i = (function(a) {
            if (a.change.length || a.recreate) return console.warn("Unable to patch indexes of table ".concat(a.name, " because it has changes on the type of index or primary key.")), { value: void 0 };
            var u = t.objectStore(a.name);
            a.add.forEach(function(c) {
              de && console.debug("Dexie upgrade patch: Creating missing index ".concat(a.name, ".").concat(c.src)), Bt(u, c);
            });
          })(o[r]);
          if (typeof i == "object") return i.value;
        }
      }
      function bn(e, t) {
        var n, r = { del: [], add: [], change: [] };
        for (n in e) t[n] || r.del.push(n);
        for (n in t) {
          var o = e[n], i = t[n];
          if (o) {
            var a = { name: n, def: i, recreate: !1, del: [], add: [], change: [] };
            if ("" + (o.primKey.keyPath || "") != "" + (i.primKey.keyPath || "") || o.primKey.auto !== i.primKey.auto) a.recreate = !0, r.change.push(a);
            else {
              var u = o.idxByName, c = i.idxByName, l = void 0;
              for (l in u) c[l] || a.del.push(l);
              for (l in c) {
                var p = u[l], s = c[l];
                p ? p.src !== s.src && a.change.push(s) : a.add.push(s);
              }
              (0 < a.del.length || 0 < a.add.length || 0 < a.change.length) && r.change.push(a);
            }
          } else r.add.push([n, i]);
        }
        return r;
      }
      function wn(e, t, n, r) {
        var o = e.db.createObjectStore(t, n.keyPath ? { keyPath: n.keyPath, autoIncrement: n.auto } : { autoIncrement: n.auto });
        return r.forEach(function(i) {
          return Bt(o, i);
        }), o;
      }
      function pr(e, t) {
        z(e).forEach(function(n) {
          t.db.objectStoreNames.contains(n) || (de && console.debug("Dexie: Creating missing table", n), wn(t, n, e[n].primKey, e[n].indexes));
        });
      }
      function Bt(e, t) {
        e.createIndex(t.name, t.keyPath, { unique: t.unique, multiEntry: t.multi });
      }
      function qt(e, t, n) {
        var r = {};
        return vt(t.objectStoreNames, 0).forEach(function(o) {
          for (var i = n.objectStore(o), a = yn(dr(l = i.keyPath), l || "", !0, !1, !!i.autoIncrement, l && typeof l != "string", !0), u = [], c = 0; c < i.indexNames.length; ++c) {
            var p = i.index(i.indexNames[c]), l = p.keyPath, p = yn(p.name, l, !!p.unique, !!p.multiEntry, !1, l && typeof l != "string", !1);
            u.push(p);
          }
          r[o] = vn(o, a, u);
        }), r;
      }
      function Nt(e, t, n) {
        for (var r = n.db.objectStoreNames, o = 0; o < r.length; ++o) {
          var i = r[o], a = n.objectStore(i);
          e._hasGetAll = "getAll" in a;
          for (var u = 0; u < a.indexNames.length; ++u) {
            var c = a.indexNames[u], l = a.index(c).keyPath, p = typeof l == "string" ? l : "[" + vt(l).join("+") + "]";
            !t[i] || (l = t[i].idxByName[p]) && (l.name = c, delete t[i].idxByName[p], t[i].idxByName[c] = l);
          }
        }
        typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && $.WorkerGlobalScope && $ instanceof $.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
      }
      function yr(e) {
        return e.split(",").map(function(t, n) {
          var i = t.split(":"), r = (o = i[1]) === null || o === void 0 ? void 0 : o.trim(), o = (t = i[0].trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(o) ? o.match(/^\[(.*)\]$/)[1].split("+") : o;
          return yn(o, i || null, /\&/.test(t), /\*/.test(t), /\+\+/.test(t), W(i), n === 0, r);
        });
      }
      var oo = (Qe.prototype._createTableSchema = vn, Qe.prototype._parseIndexSyntax = yr, Qe.prototype._parseStoresSpec = function(e, t) {
        var n = this;
        z(e).forEach(function(r) {
          if (e[r] !== null) {
            var o = n._parseIndexSyntax(e[r]), i = o.shift();
            if (!i) throw new A.Schema("Invalid schema for table " + r + ": " + e[r]);
            if (i.unique = !0, i.multi) throw new A.Schema("Primary key cannot be multiEntry*");
            o.forEach(function(a) {
              if (a.auto) throw new A.Schema("Only primary key can be marked as autoIncrement (++)");
              if (!a.keyPath) throw new A.Schema("Index must have a name and cannot be an empty string");
            }), o = n._createTableSchema(r, i, o), t[r] = o;
          }
        });
      }, Qe.prototype.stores = function(n) {
        var t = this.db;
        this._cfg.storesSource = this._cfg.storesSource ? B(this._cfg.storesSource, n) : n;
        var n = t._versions, r = {}, o = {};
        return n.forEach(function(i) {
          B(r, i._cfg.storesSource), o = i._cfg.dbschema = {}, i._parseStoresSpec(r, o);
        }), t._dbSchema = o, gn(t, [t._allTables, t, t.Transaction.prototype]), At(t, [t._allTables, t, t.Transaction.prototype, this._cfg.tables], z(o), o), t._storeNames = z(o), this;
      }, Qe.prototype.upgrade = function(e) {
        return this._cfg.contentUpgrade = en(this._cfg.contentUpgrade || Y, e), this;
      }, Qe);
      function Qe() {
      }
      function _n(e, t) {
        var n = e._dbNamesDB;
        return n || (n = e._dbNamesDB = new ge(jt, { addons: [], indexedDB: e, IDBKeyRange: t })).version(1).stores({ dbnames: "name" }), n.table("dbnames");
      }
      function xn(e) {
        return e && typeof e.databases == "function";
      }
      function kn(e) {
        return _e(function() {
          return C.letThrough = !0, e();
        });
      }
      function Sn(e) {
        return !("from" in e);
      }
      var re = function(e, t) {
        if (!this) {
          var n = new re();
          return e && "d" in e && B(n, e), n;
        }
        B(this, arguments.length ? { d: 1, from: e, to: 1 < arguments.length ? t : e } : { d: 0 });
      };
      function dt(e, t, n) {
        var r = V(t, n);
        if (!isNaN(r)) {
          if (0 < r) throw RangeError();
          if (Sn(e)) return B(e, { from: t, to: n, d: 1 });
          var o = e.l, r = e.r;
          if (V(n, e.from) < 0) return o ? dt(o, t, n) : e.l = { from: t, to: n, d: 1, l: null, r: null }, mr(e);
          if (0 < V(t, e.to)) return r ? dt(r, t, n) : e.r = { from: t, to: n, d: 1, l: null, r: null }, mr(e);
          V(t, e.from) < 0 && (e.from = t, e.l = null, e.d = r ? r.d + 1 : 1), 0 < V(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), n = !e.r, o && !e.l && ht(e, o), r && n && ht(e, r);
        }
      }
      function ht(e, t) {
        Sn(t) || (function n(r, c) {
          var i = c.from, a = c.to, u = c.l, c = c.r;
          dt(r, i, a), u && n(r, u), c && n(r, c);
        })(e, t);
      }
      function vr(e, t) {
        var n = Rt(t), r = n.next();
        if (r.done) return !1;
        for (var o = r.value, i = Rt(e), a = i.next(o.from), u = a.value; !r.done && !a.done; ) {
          if (V(u.from, o.to) <= 0 && 0 <= V(u.to, o.from)) return !0;
          V(o.from, u.from) < 0 ? o = (r = n.next(u.from)).value : u = (a = i.next(o.from)).value;
        }
        return !1;
      }
      function Rt(e) {
        var t = Sn(e) ? null : { s: 0, n: e };
        return { next: function(n) {
          for (var r = 0 < arguments.length; t; ) switch (t.s) {
            case 0:
              if (t.s = 1, r) for (; t.n.l && V(n, t.n.from) < 0; ) t = { up: t, n: t.n.l, s: 1 };
              else for (; t.n.l; ) t = { up: t, n: t.n.l, s: 1 };
            case 1:
              if (t.s = 2, !r || V(n, t.n.to) <= 0) return { value: t.n, done: !1 };
            case 2:
              if (t.n.r) {
                t.s = 3, t = { up: t, n: t.n.r, s: 0 };
                continue;
              }
            case 3:
              t = t.up;
          }
          return { done: !0 };
        } };
      }
      function mr(e) {
        var t, n, r = (((t = e.r) === null || t === void 0 ? void 0 : t.d) || 0) - (((n = e.l) === null || n === void 0 ? void 0 : n.d) || 0), o = 1 < r ? "r" : r < -1 ? "l" : "";
        o && (t = o == "r" ? "l" : "r", n = k({}, e), r = e[o], e.from = r.from, e.to = r.to, e[o] = r[o], n[o] = r[t], (e[t] = n).d = gr(n)), e.d = gr(e);
      }
      function gr(n) {
        var t = n.r, n = n.l;
        return (t ? n ? Math.max(t.d, n.d) : t.d : n ? n.d : 0) + 1;
      }
      function Mt(e, t) {
        return z(t).forEach(function(n) {
          e[n] ? ht(e[n], t[n]) : e[n] = (function r(o) {
            var i, a, u = {};
            for (i in o) X(o, i) && (a = o[i], u[i] = !a || typeof a != "object" || $n.has(a.constructor) ? a : r(a));
            return u;
          })(t[n]);
        }), e;
      }
      function Pn(e, t) {
        return e.all || t.all || Object.keys(e).some(function(n) {
          return t[n] && vr(t[n], e[n]);
        });
      }
      J(re.prototype, ((fe = { add: function(e) {
        return ht(this, e), this;
      }, addKey: function(e) {
        return dt(this, e, e), this;
      }, addKeys: function(e) {
        var t = this;
        return e.forEach(function(n) {
          return dt(t, n, n);
        }), this;
      }, hasKey: function(e) {
        var t = Rt(this).next(e).value;
        return t && V(t.from, e) <= 0 && 0 <= V(t.to, e);
      } })[Xt] = function() {
        return Rt(this);
      }, fe));
      var Ne = {}, On = {}, jn = !1;
      function Ft(e) {
        Mt(On, e), jn || (jn = !0, setTimeout(function() {
          jn = !1, En(On, !(On = {}));
        }, 0));
      }
      function En(e, t) {
        t === void 0 && (t = !1);
        var n = /* @__PURE__ */ new Set();
        if (e.all) for (var r = 0, o = Object.values(Ne); r < o.length; r++) br(a = o[r], e, n, t);
        else for (var i in e) {
          var a, u = /^idb\:\/\/(.*)\/(.*)\//.exec(i);
          u && (i = u[1], u = u[2], (a = Ne["idb://".concat(i, "/").concat(u)]) && br(a, e, n, t));
        }
        n.forEach(function(c) {
          return c();
        });
      }
      function br(e, t, n, r) {
        for (var o = [], i = 0, a = Object.entries(e.queries.query); i < a.length; i++) {
          for (var u = a[i], c = u[0], l = [], p = 0, s = u[1]; p < s.length; p++) {
            var v = s[p];
            Pn(t, v.obsSet) ? v.subscribers.forEach(function(y) {
              return n.add(y);
            }) : r && l.push(v);
          }
          r && o.push([c, l]);
        }
        if (r) for (var f = 0, d = o; f < d.length; f++) {
          var h = d[f], c = h[0], l = h[1];
          e.queries.query[c] = l;
        }
      }
      function io(e) {
        var t = e._state, n = e._deps.indexedDB;
        if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
          return t.dbOpenError ? Z(t.dbOpenError) : e;
        });
        t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
        var r = t.openCanceller, o = Math.round(10 * e.verno), i = !1;
        function a() {
          if (t.openCanceller !== r) throw new A.DatabaseClosed("db.open() was cancelled");
        }
        function u() {
          return new K(function(v, f) {
            if (a(), !n) throw new A.MissingAPI();
            var d = e.name, h = t.autoSchema || !o ? n.open(d) : n.open(d, o);
            if (!h) throw new A.MissingAPI();
            h.onerror = he(f), h.onblocked = Q(e._fireOnBlocked), h.onupgradeneeded = Q(function(y) {
              var m;
              p = h.transaction, t.autoSchema && !e._options.allowEmptyDB ? (h.onerror = st, p.abort(), h.result.close(), (m = n.deleteDatabase(d)).onsuccess = m.onerror = Q(function() {
                f(new A.NoSuchDatabase("Database ".concat(d, " doesnt exist")));
              })) : (p.onerror = he(f), y = y.oldVersion > Math.pow(2, 62) ? 0 : y.oldVersion, s = y < 1, e.idbdb = h.result, i && ro(e, p), no(e, y / 10, p, f));
            }, f), h.onsuccess = Q(function() {
              p = null;
              var y, m, g, b, w, P = e.idbdb = h.result, E = vt(P.objectStoreNames);
              if (0 < E.length) try {
                var S = P.transaction((b = E).length === 1 ? b[0] : b, "readonly");
                if (t.autoSchema) m = P, g = S, (y = e).verno = m.version / 10, g = y._dbSchema = qt(0, m, g), y._storeNames = vt(m.objectStoreNames, 0), At(y, [y._allTables], z(g), g);
                else if (Nt(e, e._dbSchema, S), ((w = bn(qt(0, (w = e).idbdb, S), w._dbSchema)).add.length || w.change.some(function(O) {
                  return O.add.length || O.change.length;
                })) && !i) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), P.close(), o = P.version + 1, i = !0, v(u());
                Ct(e, S);
              } catch {
              }
              We.push(e), P.onversionchange = Q(function(O) {
                t.vcFired = !0, e.on("versionchange").fire(O);
              }), P.onclose = Q(function() {
                e.close({ disableAutoOpen: !1 });
              }), s && (w = e._deps, S = d, P = w.indexedDB, w = w.IDBKeyRange, xn(P) || S === jt || _n(P, w).put({ name: S }).catch(Y)), v();
            }, f);
          }).catch(function(v) {
            switch (v == null ? void 0 : v.name) {
              case "UnknownError":
                if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), u();
                break;
              case "VersionError":
                if (0 < o) return o = 0, u();
            }
            return K.reject(v);
          });
        }
        var c, l = t.dbReadyResolve, p = null, s = !1;
        return K.race([r, (typeof navigator > "u" ? K.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(v) {
          function f() {
            return indexedDB.databases().finally(v);
          }
          c = setInterval(f, 100), f();
        }).finally(function() {
          return clearInterval(c);
        }) : Promise.resolve()).then(u)]).then(function() {
          return a(), t.onReadyBeingFired = [], K.resolve(kn(function() {
            return e.on.ready.fire(e.vip);
          })).then(function v() {
            if (0 < t.onReadyBeingFired.length) {
              var f = t.onReadyBeingFired.reduce(en, Y);
              return t.onReadyBeingFired = [], K.resolve(kn(function() {
                return f(e.vip);
              })).then(v);
            }
          });
        }).finally(function() {
          t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
        }).catch(function(v) {
          t.dbOpenError = v;
          try {
            p && p.abort();
          } catch {
          }
          return r === t.openCanceller && e._close(), Z(v);
        }).finally(function() {
          t.openComplete = !0, l();
        }).then(function() {
          var v;
          return s && (v = {}, e.tables.forEach(function(f) {
            f.schema.indexes.forEach(function(d) {
              d.name && (v["idb://".concat(e.name, "/").concat(f.name, "/").concat(d.name)] = new re(-1 / 0, [[[]]]));
            }), v["idb://".concat(e.name, "/").concat(f.name, "/")] = v["idb://".concat(e.name, "/").concat(f.name, "/:dels")] = new re(-1 / 0, [[[]]]);
          }), Pe(ct).fire(v), En(v, !0)), e;
        });
      }
      function In(e) {
        function t(i) {
          return e.next(i);
        }
        var n = o(t), r = o(function(i) {
          return e.throw(i);
        });
        function o(i) {
          return function(c) {
            var u = i(c), c = u.value;
            return u.done ? c : c && typeof c.then == "function" ? c.then(n, r) : W(c) ? Promise.all(c).then(n, r) : n(c);
          };
        }
        return o(t)();
      }
      function Vt(e, t, n) {
        for (var r = W(e) ? e.slice() : [e], o = 0; o < n; ++o) r.push(t);
        return r;
      }
      var ao = { stack: "dbcore", name: "VirtualIndexMiddleware", level: 1, create: function(e) {
        return k(k({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema, o = {}, i = [];
          function a(s, v, f) {
            var d = ft(s), h = o[d] = o[d] || [], y = s == null ? 0 : typeof s == "string" ? 1 : s.length, m = 0 < v, m = k(k({}, f), { name: m ? "".concat(d, "(virtual-from:").concat(f.name, ")") : f.name, lowLevelIndex: f, isVirtual: m, keyTail: v, keyLength: y, extractKey: mn(s), unique: !m && f.unique });
            return h.push(m), m.isPrimaryKey || i.push(m), 1 < y && a(y === 2 ? s[0] : s.slice(0, y - 1), v + 1, f), h.sort(function(g, b) {
              return g.keyTail - b.keyTail;
            }), m;
          }
          t = a(r.primaryKey.keyPath, 0, r.primaryKey), o[":id"] = [t];
          for (var u = 0, c = r.indexes; u < c.length; u++) {
            var l = c[u];
            a(l.keyPath, 0, l);
          }
          function p(s) {
            var v, f = s.query.index;
            return f.isVirtual ? k(k({}, s), { query: { index: f.lowLevelIndex, range: (v = s.query.range, f = f.keyTail, { type: v.type === 1 ? 2 : v.type, lower: Vt(v.lower, v.lowerOpen ? e.MAX_KEY : e.MIN_KEY, f), lowerOpen: !0, upper: Vt(v.upper, v.upperOpen ? e.MIN_KEY : e.MAX_KEY, f), upperOpen: !0 }) } }) : s;
          }
          return k(k({}, n), { schema: k(k({}, r), { primaryKey: t, indexes: i, getIndexByKeyPath: function(s) {
            return (s = o[ft(s)]) && s[0];
          } }), count: function(s) {
            return n.count(p(s));
          }, query: function(s) {
            return n.query(p(s));
          }, openCursor: function(s) {
            var v = s.query.index, f = v.keyTail, d = v.isVirtual, h = v.keyLength;
            return d ? n.openCursor(p(s)).then(function(m) {
              return m && y(m);
            }) : n.openCursor(s);
            function y(m) {
              return Object.create(m, { continue: { value: function(g) {
                g != null ? m.continue(Vt(g, s.reverse ? e.MAX_KEY : e.MIN_KEY, f)) : s.unique ? m.continue(m.key.slice(0, h).concat(s.reverse ? e.MIN_KEY : e.MAX_KEY, f)) : m.continue();
              } }, continuePrimaryKey: { value: function(g, b) {
                m.continuePrimaryKey(Vt(g, e.MAX_KEY, f), b);
              } }, primaryKey: { get: function() {
                return m.primaryKey;
              } }, key: { get: function() {
                var g = m.key;
                return h === 1 ? g[0] : g.slice(0, h);
              } }, value: { get: function() {
                return m.value;
              } } });
            }
          } });
        } });
      } };
      function Kn(e, t, n, r) {
        return n = n || {}, r = r || "", z(e).forEach(function(o) {
          var i, a, u;
          X(t, o) ? (i = e[o], a = t[o], typeof i == "object" && typeof a == "object" && i && a ? (u = Qt(i)) !== Qt(a) ? n[r + o] = t[o] : u === "Object" ? Kn(i, a, n, r + o + ".") : i !== a && (n[r + o] = t[o]) : i !== a && (n[r + o] = t[o])) : n[r + o] = void 0;
        }), z(t).forEach(function(o) {
          X(e, o) || (n[r + o] = t[o]);
        }), n;
      }
      function Dn(e, t) {
        return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
      }
      var uo = { stack: "dbcore", name: "HooksMiddleware", level: 2, create: function(e) {
        return k(k({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema.primaryKey;
          return k(k({}, n), { mutate: function(o) {
            var i = C.trans, a = i.table(t).hook, u = a.deleting, c = a.creating, l = a.updating;
            switch (o.type) {
              case "add":
                if (c.fire === Y) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "put":
                if (c.fire === Y && l.fire === Y) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "delete":
                if (u.fire === Y) break;
                return i._promise("readwrite", function() {
                  return p(o);
                }, !0);
              case "deleteRange":
                if (u.fire === Y) break;
                return i._promise("readwrite", function() {
                  return (function s(v, f, d) {
                    return n.query({ trans: v, values: !1, query: { index: r, range: f }, limit: d }).then(function(h) {
                      var y = h.result;
                      return p({ type: "delete", keys: y, trans: v }).then(function(m) {
                        return 0 < m.numFailures ? Promise.reject(m.failures[0]) : y.length < d ? { failures: [], numFailures: 0, lastResult: void 0 } : s(v, k(k({}, f), { lower: y[y.length - 1], lowerOpen: !0 }), d);
                      });
                    });
                  })(o.trans, o.range, 1e4);
                }, !0);
            }
            return n.mutate(o);
            function p(s) {
              var v, f, d, h = C.trans, y = s.keys || Dn(r, s);
              if (!y) throw new Error("Keys missing");
              return (s = s.type === "add" || s.type === "put" ? k(k({}, s), { keys: y }) : k({}, s)).type !== "delete" && (s.values = U([], s.values)), s.keys && (s.keys = U([], s.keys)), v = n, d = y, ((f = s).type === "add" ? Promise.resolve([]) : v.getMany({ trans: f.trans, keys: d, cache: "immutable" })).then(function(m) {
                var g = y.map(function(b, w) {
                  var P, E, S, O = m[w], I = { onerror: null, onsuccess: null };
                  return s.type === "delete" ? u.fire.call(I, b, O, h) : s.type === "add" || O === void 0 ? (P = c.fire.call(I, b, s.values[w], h), b == null && P != null && (s.keys[w] = b = P, r.outbound || ue(s.values[w], r.keyPath, b))) : (P = Kn(O, s.values[w]), (E = l.fire.call(I, P, b, O, h)) && (S = s.values[w], Object.keys(E).forEach(function(j) {
                    X(S, j) ? S[j] = E[j] : ue(S, j, E[j]);
                  }))), I;
                });
                return n.mutate(s).then(function(b) {
                  for (var w = b.failures, P = b.results, E = b.numFailures, b = b.lastResult, S = 0; S < y.length; ++S) {
                    var O = (P || y)[S], I = g[S];
                    O == null ? I.onerror && I.onerror(w[S]) : I.onsuccess && I.onsuccess(s.type === "put" && m[S] ? s.values[S] : O);
                  }
                  return { failures: w, results: P, numFailures: E, lastResult: b };
                }).catch(function(b) {
                  return g.forEach(function(w) {
                    return w.onerror && w.onerror(b);
                  }), Promise.reject(b);
                });
              });
            }
          } });
        } });
      } };
      function wr(e, t, n) {
        try {
          if (!t || t.keys.length < e.length) return null;
          for (var r = [], o = 0, i = 0; o < t.keys.length && i < e.length; ++o) V(t.keys[o], e[i]) === 0 && (r.push(n ? je(t.values[o]) : t.values[o]), ++i);
          return r.length === e.length ? r : null;
        } catch {
          return null;
        }
      }
      var so = { stack: "dbcore", level: -1, create: function(e) {
        return { table: function(t) {
          var n = e.table(t);
          return k(k({}, n), { getMany: function(r) {
            if (!r.cache) return n.getMany(r);
            var o = wr(r.keys, r.trans._cache, r.cache === "clone");
            return o ? K.resolve(o) : n.getMany(r).then(function(i) {
              return r.trans._cache = { keys: r.keys, values: r.cache === "clone" ? je(i) : i }, i;
            });
          }, mutate: function(r) {
            return r.type !== "add" && (r.trans._cache = null), n.mutate(r);
          } });
        } };
      } };
      function _r(e, t) {
        return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
      }
      function xr(e, t) {
        switch (e) {
          case "query":
            return t.values && !t.unique;
          case "get":
          case "getMany":
          case "count":
          case "openCursor":
            return !1;
        }
      }
      var co = { stack: "dbcore", level: 0, name: "Observability", create: function(e) {
        var t = e.schema.name, n = new re(e.MIN_KEY, e.MAX_KEY);
        return k(k({}, e), { transaction: function(r, o, i) {
          if (C.subscr && o !== "readonly") throw new A.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(C.querier));
          return e.transaction(r, o, i);
        }, table: function(r) {
          var o = e.table(r), i = o.schema, a = i.primaryKey, s = i.indexes, u = a.extractKey, c = a.outbound, l = a.autoIncrement && s.filter(function(f) {
            return f.compound && f.keyPath.includes(a.keyPath);
          }), p = k(k({}, o), { mutate: function(f) {
            function d(j) {
              return j = "idb://".concat(t, "/").concat(r, "/").concat(j), b[j] || (b[j] = new re());
            }
            var h, y, m, g = f.trans, b = f.mutatedParts || (f.mutatedParts = {}), w = d(""), P = d(":dels"), E = f.type, I = f.type === "deleteRange" ? [f.range] : f.type === "delete" ? [f.keys] : f.values.length < 50 ? [Dn(a, f).filter(function(j) {
              return j;
            }), f.values] : [], S = I[0], O = I[1], I = f.trans._cache;
            return W(S) ? (w.addKeys(S), (I = E === "delete" || S.length === O.length ? wr(S, I) : null) || P.addKeys(S), (I || O) && (h = d, y = I, m = O, i.indexes.forEach(function(j) {
              var T = h(j.name || "");
              function N(M) {
                return M != null ? j.extractKey(M) : null;
              }
              function R(M) {
                return j.multiEntry && W(M) ? M.forEach(function(le) {
                  return T.addKey(le);
                }) : T.addKey(M);
              }
              (y || m).forEach(function(M, oe) {
                var q = y && N(y[oe]), oe = m && N(m[oe]);
                V(q, oe) !== 0 && (q != null && R(q), oe != null && R(oe));
              });
            }))) : S ? (O = { from: (O = S.lower) !== null && O !== void 0 ? O : e.MIN_KEY, to: (O = S.upper) !== null && O !== void 0 ? O : e.MAX_KEY }, P.add(O), w.add(O)) : (w.add(n), P.add(n), i.indexes.forEach(function(j) {
              return d(j.name).add(n);
            })), o.mutate(f).then(function(j) {
              return !S || f.type !== "add" && f.type !== "put" || (w.addKeys(j.results), l && l.forEach(function(T) {
                for (var N = f.values.map(function(q) {
                  return T.extractKey(q);
                }), R = T.keyPath.findIndex(function(q) {
                  return q === a.keyPath;
                }), M = 0, le = j.results.length; M < le; ++M) N[M][R] = j.results[M];
                d(T.name).addKeys(N);
              })), g.mutatedParts = Mt(g.mutatedParts || {}, b), j;
            });
          } }), s = function(d) {
            var h = d.query, d = h.index, h = h.range;
            return [d, new re((d = h.lower) !== null && d !== void 0 ? d : e.MIN_KEY, (h = h.upper) !== null && h !== void 0 ? h : e.MAX_KEY)];
          }, v = { get: function(f) {
            return [a, new re(f.key)];
          }, getMany: function(f) {
            return [a, new re().addKeys(f.keys)];
          }, count: s, query: s, openCursor: s };
          return z(v).forEach(function(f) {
            p[f] = function(d) {
              var h = C.subscr, y = !!h, m = _r(C, o) && xr(f, d) ? d.obsSet = {} : h;
              if (y) {
                var g = function(O) {
                  return O = "idb://".concat(t, "/").concat(r, "/").concat(O), m[O] || (m[O] = new re());
                }, b = g(""), w = g(":dels"), h = v[f](d), y = h[0], h = h[1];
                if ((f === "query" && y.isPrimaryKey && !d.values ? w : g(y.name || "")).add(h), !y.isPrimaryKey) {
                  if (f !== "count") {
                    var P = f === "query" && c && d.values && o.query(k(k({}, d), { values: !1 }));
                    return o[f].apply(this, arguments).then(function(O) {
                      if (f === "query") {
                        if (c && d.values) return P.then(function(N) {
                          return N = N.result, b.addKeys(N), O;
                        });
                        var I = d.values ? O.result.map(u) : O.result;
                        (d.values ? b : w).addKeys(I);
                      } else if (f === "openCursor") {
                        var j = O, T = d.values;
                        return j && Object.create(j, { key: { get: function() {
                          return w.addKey(j.primaryKey), j.key;
                        } }, primaryKey: { get: function() {
                          var N = j.primaryKey;
                          return w.addKey(N), N;
                        } }, value: { get: function() {
                          return T && b.addKey(j.primaryKey), j.value;
                        } } });
                      }
                      return O;
                    });
                  }
                  w.add(n);
                }
              }
              return o[f].apply(this, arguments);
            };
          }), p;
        } });
      } };
      function kr(e, t, n) {
        if (n.numFailures === 0) return t;
        if (t.type === "deleteRange") return null;
        var r = t.keys ? t.keys.length : "values" in t && t.values ? t.values.length : 1;
        return n.numFailures === r ? null : (t = k({}, t), W(t.keys) && (t.keys = t.keys.filter(function(o, i) {
          return !(i in n.failures);
        })), "values" in t && W(t.values) && (t.values = t.values.filter(function(o, i) {
          return !(i in n.failures);
        })), t);
      }
      function Tn(e, t) {
        return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < V(n, r.lower) : 0 <= V(n, r.lower))) && (e = e, (t = t).upper === void 0 || (t.upperOpen ? V(e, t.upper) < 0 : V(e, t.upper) <= 0));
        var n, r;
      }
      function Sr(e, t, v, r, o, i) {
        if (!v || v.length === 0) return e;
        var a = t.query.index, u = a.multiEntry, c = t.query.range, l = r.schema.primaryKey.extractKey, p = a.extractKey, s = (a.lowLevelIndex || a).extractKey, v = v.reduce(function(f, d) {
          var h = f, y = [];
          if (d.type === "add" || d.type === "put") for (var m = new re(), g = d.values.length - 1; 0 <= g; --g) {
            var b, w = d.values[g], P = l(w);
            m.hasKey(P) || (b = p(w), (u && W(b) ? b.some(function(j) {
              return Tn(j, c);
            }) : Tn(b, c)) && (m.addKey(P), y.push(w)));
          }
          switch (d.type) {
            case "add":
              var E = new re().addKeys(t.values ? f.map(function(T) {
                return l(T);
              }) : f), h = f.concat(t.values ? y.filter(function(T) {
                return T = l(T), !E.hasKey(T) && (E.addKey(T), !0);
              }) : y.map(function(T) {
                return l(T);
              }).filter(function(T) {
                return !E.hasKey(T) && (E.addKey(T), !0);
              }));
              break;
            case "put":
              var S = new re().addKeys(d.values.map(function(T) {
                return l(T);
              }));
              h = f.filter(function(T) {
                return !S.hasKey(t.values ? l(T) : T);
              }).concat(t.values ? y : y.map(function(T) {
                return l(T);
              }));
              break;
            case "delete":
              var O = new re().addKeys(d.keys);
              h = f.filter(function(T) {
                return !O.hasKey(t.values ? l(T) : T);
              });
              break;
            case "deleteRange":
              var I = d.range;
              h = f.filter(function(T) {
                return !Tn(l(T), I);
              });
          }
          return h;
        }, e);
        return v === e ? e : (v.sort(function(f, d) {
          return V(s(f), s(d)) || V(l(f), l(d));
        }), t.limit && t.limit < 1 / 0 && (v.length > t.limit ? v.length = t.limit : e.length === t.limit && v.length < t.limit && (o.dirty = !0)), i ? Object.freeze(v) : v);
      }
      function Pr(e, t) {
        return V(e.lower, t.lower) === 0 && V(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
      }
      function lo(e, t) {
        return (function(n, r, o, i) {
          if (n === void 0) return r !== void 0 ? -1 : 0;
          if (r === void 0) return 1;
          if ((r = V(n, r)) === 0) {
            if (o && i) return 0;
            if (o) return 1;
            if (i) return -1;
          }
          return r;
        })(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= (function(n, r, o, i) {
          if (n === void 0) return r !== void 0 ? 1 : 0;
          if (r === void 0) return -1;
          if ((r = V(n, r)) === 0) {
            if (o && i) return 0;
            if (o) return -1;
            if (i) return 1;
          }
          return r;
        })(e.upper, t.upper, e.upperOpen, t.upperOpen);
      }
      function fo(e, t, n, r) {
        e.subscribers.add(n), r.addEventListener("abort", function() {
          var o, i;
          e.subscribers.delete(n), e.subscribers.size === 0 && (o = e, i = t, setTimeout(function() {
            o.subscribers.size === 0 && Ee(i, o);
          }, 3e3));
        });
      }
      var ho = { stack: "dbcore", level: 0, name: "Cache", create: function(e) {
        var t = e.schema.name;
        return k(k({}, e), { transaction: function(n, r, o) {
          var i, a, u = e.transaction(n, r, o);
          return r === "readwrite" && (a = (i = new AbortController()).signal, o = function(c) {
            return function() {
              if (i.abort(), r === "readwrite") {
                for (var l = /* @__PURE__ */ new Set(), p = 0, s = n; p < s.length; p++) {
                  var v = s[p], f = Ne["idb://".concat(t, "/").concat(v)];
                  if (f) {
                    var d = e.table(v), h = f.optimisticOps.filter(function(T) {
                      return T.trans === u;
                    });
                    if (u._explicit && c && u.mutatedParts) for (var y = 0, m = Object.values(f.queries.query); y < m.length; y++) for (var g = 0, b = (E = m[y]).slice(); g < b.length; g++) Pn((S = b[g]).obsSet, u.mutatedParts) && (Ee(E, S), S.subscribers.forEach(function(T) {
                      return l.add(T);
                    }));
                    else if (0 < h.length) {
                      f.optimisticOps = f.optimisticOps.filter(function(T) {
                        return T.trans !== u;
                      });
                      for (var w = 0, P = Object.values(f.queries.query); w < P.length; w++) for (var E, S, O, I = 0, j = (E = P[w]).slice(); I < j.length; I++) (S = j[I]).res != null && u.mutatedParts && (c && !S.dirty ? (O = Object.isFrozen(S.res), O = Sr(S.res, S.req, h, d, S, O), S.dirty ? (Ee(E, S), S.subscribers.forEach(function(T) {
                        return l.add(T);
                      })) : O !== S.res && (S.res = O, S.promise = K.resolve({ result: O }))) : (S.dirty && Ee(E, S), S.subscribers.forEach(function(T) {
                        return l.add(T);
                      })));
                    }
                  }
                }
                l.forEach(function(T) {
                  return T();
                });
              }
            };
          }, u.addEventListener("abort", o(!1), { signal: a }), u.addEventListener("error", o(!1), { signal: a }), u.addEventListener("complete", o(!0), { signal: a })), u;
        }, table: function(n) {
          var r = e.table(n), o = r.schema.primaryKey;
          return k(k({}, r), { mutate: function(i) {
            var a = C.trans;
            if (o.outbound || a.db._options.cache === "disabled" || a.explicit || a.idbtrans.mode !== "readwrite") return r.mutate(i);
            var u = Ne["idb://".concat(t, "/").concat(n)];
            return u ? (a = r.mutate(i), i.type !== "add" && i.type !== "put" || !(50 <= i.values.length || Dn(o, i).some(function(c) {
              return c == null;
            })) ? (u.optimisticOps.push(i), i.mutatedParts && Ft(i.mutatedParts), a.then(function(c) {
              0 < c.numFailures && (Ee(u.optimisticOps, i), (c = kr(0, i, c)) && u.optimisticOps.push(c), i.mutatedParts && Ft(i.mutatedParts));
            }), a.catch(function() {
              Ee(u.optimisticOps, i), i.mutatedParts && Ft(i.mutatedParts);
            })) : a.then(function(c) {
              var l = kr(0, k(k({}, i), { values: i.values.map(function(p, s) {
                var v;
                return c.failures[s] ? p : (p = (v = o.keyPath) !== null && v !== void 0 && v.includes(".") ? je(p) : k({}, p), ue(p, o.keyPath, c.results[s]), p);
              }) }), c);
              u.optimisticOps.push(l), queueMicrotask(function() {
                return i.mutatedParts && Ft(i.mutatedParts);
              });
            }), a) : r.mutate(i);
          }, query: function(i) {
            if (!_r(C, r) || !xr("query", i)) return r.query(i);
            var a = ((l = C.trans) === null || l === void 0 ? void 0 : l.db._options.cache) === "immutable", s = C, u = s.requery, c = s.signal, l = (function(d, h, y, m) {
              var g = Ne["idb://".concat(d, "/").concat(h)];
              if (!g) return [];
              if (!(h = g.queries[y])) return [null, !1, g, null];
              var b = h[(m.query ? m.query.index.name : null) || ""];
              if (!b) return [null, !1, g, null];
              switch (y) {
                case "query":
                  var w = b.find(function(P) {
                    return P.req.limit === m.limit && P.req.values === m.values && Pr(P.req.query.range, m.query.range);
                  });
                  return w ? [w, !0, g, b] : [b.find(function(P) {
                    return ("limit" in P.req ? P.req.limit : 1 / 0) >= m.limit && (!m.values || P.req.values) && lo(P.req.query.range, m.query.range);
                  }), !1, g, b];
                case "count":
                  return w = b.find(function(P) {
                    return Pr(P.req.query.range, m.query.range);
                  }), [w, !!w, g, b];
              }
            })(t, n, "query", i), p = l[0], s = l[1], v = l[2], f = l[3];
            return p && s ? p.obsSet = i.obsSet : (s = r.query(i).then(function(d) {
              var h = d.result;
              if (p && (p.res = h), a) {
                for (var y = 0, m = h.length; y < m; ++y) Object.freeze(h[y]);
                Object.freeze(h);
              } else d.result = je(h);
              return d;
            }).catch(function(d) {
              return f && p && Ee(f, p), Promise.reject(d);
            }), p = { obsSet: i.obsSet, promise: s, subscribers: /* @__PURE__ */ new Set(), type: "query", req: i, dirty: !1 }, f ? f.push(p) : (f = [p], (v = v || (Ne["idb://".concat(t, "/").concat(n)] = { queries: { query: {}, count: {} }, objs: /* @__PURE__ */ new Map(), optimisticOps: [], unsignaledParts: {} })).queries.query[i.query.index.name || ""] = f)), fo(p, f, u, c), p.promise.then(function(d) {
              return { result: Sr(d.result, i, v == null ? void 0 : v.optimisticOps, r, p, a) };
            });
          } });
        } });
      } };
      function Lt(e, t) {
        return new Proxy(e, { get: function(n, r, o) {
          return r === "db" ? t : Reflect.get(n, r, o);
        } });
      }
      var ge = (ee.prototype.version = function(e) {
        if (isNaN(e) || e < 0.1) throw new A.Type("Given version is not a positive number");
        if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new A.Schema("Cannot add version when database is open");
        this.verno = Math.max(this.verno, e);
        var t = this._versions, n = t.filter(function(r) {
          return r._cfg.version === e;
        })[0];
        return n || (n = new this.Version(e), t.push(n), t.sort(to), n.stores({}), this._state.autoSchema = !1, n);
      }, ee.prototype._whenReady = function(e) {
        var t = this;
        return this.idbdb && (this._state.openComplete || C.letThrough || this._vip) ? e() : new K(function(n, r) {
          if (t._state.openComplete) return r(new A.DatabaseClosed(t._state.dbOpenError));
          if (!t._state.isBeingOpened) {
            if (!t._state.autoOpen) return void r(new A.DatabaseClosed());
            t.open().catch(Y);
          }
          t._state.dbReadyPromise.then(n, r);
        }).then(e);
      }, ee.prototype.use = function(e) {
        var t = e.stack, n = e.create, r = e.level, o = e.name;
        return o && this.unuse({ stack: t, name: o }), e = this._middlewares[t] || (this._middlewares[t] = []), e.push({ stack: t, create: n, level: r ?? 10, name: o }), e.sort(function(i, a) {
          return i.level - a.level;
        }), this;
      }, ee.prototype.unuse = function(e) {
        var t = e.stack, n = e.name, r = e.create;
        return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(o) {
          return r ? o.create !== r : !!n && o.name !== n;
        })), this;
      }, ee.prototype.open = function() {
        var e = this;
        return Ae(we, function() {
          return io(e);
        });
      }, ee.prototype._close = function() {
        this.on.close.fire(new CustomEvent("close"));
        var e = this._state, t = We.indexOf(this);
        if (0 <= t && We.splice(t, 1), this.idbdb) {
          try {
            this.idbdb.close();
          } catch {
          }
          this.idbdb = null;
        }
        e.isBeingOpened || (e.dbReadyPromise = new K(function(n) {
          e.dbReadyResolve = n;
        }), e.openCanceller = new K(function(n, r) {
          e.cancelOpen = r;
        }));
      }, ee.prototype.close = function(n) {
        var t = (n === void 0 ? { disableAutoOpen: !0 } : n).disableAutoOpen, n = this._state;
        t ? (n.isBeingOpened && n.cancelOpen(new A.DatabaseClosed()), this._close(), n.autoOpen = !1, n.dbOpenError = new A.DatabaseClosed()) : (this._close(), n.autoOpen = this._options.autoOpen || n.isBeingOpened, n.openComplete = !1, n.dbOpenError = null);
      }, ee.prototype.delete = function(e) {
        var t = this;
        e === void 0 && (e = { disableAutoOpen: !0 });
        var n = 0 < arguments.length && typeof arguments[0] != "object", r = this._state;
        return new K(function(o, i) {
          function a() {
            t.close(e);
            var u = t._deps.indexedDB.deleteDatabase(t.name);
            u.onsuccess = Q(function() {
              var c, l, p;
              c = t._deps, l = t.name, p = c.indexedDB, c = c.IDBKeyRange, xn(p) || l === jt || _n(p, c).delete(l).catch(Y), o();
            }), u.onerror = he(i), u.onblocked = t._fireOnBlocked;
          }
          if (n) throw new A.InvalidArgument("Invalid closeOptions argument to db.delete()");
          r.isBeingOpened ? r.dbReadyPromise.then(a) : a();
        });
      }, ee.prototype.backendDB = function() {
        return this.idbdb;
      }, ee.prototype.isOpen = function() {
        return this.idbdb !== null;
      }, ee.prototype.hasBeenClosed = function() {
        var e = this._state.dbOpenError;
        return e && e.name === "DatabaseClosed";
      }, ee.prototype.hasFailed = function() {
        return this._state.dbOpenError !== null;
      }, ee.prototype.dynamicallyOpened = function() {
        return this._state.autoSchema;
      }, Object.defineProperty(ee.prototype, "tables", { get: function() {
        var e = this;
        return z(this._allTables).map(function(t) {
          return e._allTables[t];
        });
      }, enumerable: !1, configurable: !0 }), ee.prototype.transaction = function() {
        var e = (function(t, n, r) {
          var o = arguments.length;
          if (o < 2) throw new A.InvalidArgument("Too few arguments");
          for (var i = new Array(o - 1); --o; ) i[o - 1] = arguments[o];
          return r = i.pop(), [t, Un(i), r];
        }).apply(this, arguments);
        return this._transaction.apply(this, e);
      }, ee.prototype._transaction = function(e, t, n) {
        var r = this, o = C.trans;
        o && o.db === this && e.indexOf("!") === -1 || (o = null);
        var i, a, u = e.indexOf("?") !== -1;
        e = e.replace("!", "").replace("?", "");
        try {
          if (a = t.map(function(l) {
            if (l = l instanceof r.Table ? l.name : l, typeof l != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
            return l;
          }), e == "r" || e === ln) i = ln;
          else {
            if (e != "rw" && e != fn) throw new A.InvalidArgument("Invalid transaction mode: " + e);
            i = fn;
          }
          if (o) {
            if (o.mode === ln && i === fn) {
              if (!u) throw new A.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
              o = null;
            }
            o && a.forEach(function(l) {
              if (o && o.storeNames.indexOf(l) === -1) {
                if (!u) throw new A.SubTransaction("Table " + l + " not included in parent transaction.");
                o = null;
              }
            }), u && o && !o.active && (o = null);
          }
        } catch (l) {
          return o ? o._promise(null, function(p, s) {
            s(l);
          }) : Z(l);
        }
        var c = (function l(p, s, v, f, d) {
          return K.resolve().then(function() {
            var h = C.transless || C, y = p._createTransaction(s, v, p._dbSchema, f);
            if (y.explicit = !0, h = { trans: y, transless: h }, f) y.idbtrans = f.idbtrans;
            else try {
              y.create(), y.idbtrans._explicit = !0, p._state.PR1398_maxLoop = 3;
            } catch (b) {
              return b.name === Zt.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                return l(p, s, v, null, d);
              })) : Z(b);
            }
            var m, g = Jt(d);
            return g && Ye(), h = K.follow(function() {
              var b;
              (m = d.call(y, y)) && (g ? (b = xe.bind(null, null), m.then(b, b)) : typeof m.next == "function" && typeof m.throw == "function" && (m = In(m)));
            }, h), (m && typeof m.then == "function" ? K.resolve(m).then(function(b) {
              return y.active ? b : Z(new A.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
            }) : h.then(function() {
              return m;
            })).then(function(b) {
              return f && y._resolve(), y._completion.then(function() {
                return b;
              });
            }).catch(function(b) {
              return y._reject(b), Z(b);
            });
          });
        }).bind(null, this, i, a, o, n);
        return o ? o._promise(i, c, "lock") : C.trans ? Ae(C.transless, function() {
          return r._whenReady(c);
        }) : this._whenReady(c);
      }, ee.prototype.table = function(e) {
        if (!X(this._allTables, e)) throw new A.InvalidTable("Table ".concat(e, " does not exist"));
        return this._allTables[e];
      }, ee);
      function ee(e, t) {
        var n = this;
        this._middlewares = {}, this.verno = 0;
        var r = ee.dependencies;
        this._options = t = k({ addons: ee.addons, autoOpen: !0, indexedDB: r.indexedDB, IDBKeyRange: r.IDBKeyRange, cache: "cloned" }, t), this._deps = { indexedDB: t.indexedDB, IDBKeyRange: t.IDBKeyRange }, r = t.addons, this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
        var o, i, a, u, c, l = { dbOpenError: null, isBeingOpened: !1, onReadyBeingFired: null, openComplete: !1, dbReadyResolve: Y, dbReadyPromise: null, cancelOpen: Y, openCanceller: null, autoSchema: !0, PR1398_maxLoop: 3, autoOpen: t.autoOpen };
        l.dbReadyPromise = new K(function(s) {
          l.dbReadyResolve = s;
        }), l.openCanceller = new K(function(s, v) {
          l.cancelOpen = v;
        }), this._state = l, this.name = e, this.on = at(this, "populate", "blocked", "versionchange", "close", { ready: [en, Y] }), this.once = function(s, v) {
          var f = function() {
            for (var d = [], h = 0; h < arguments.length; h++) d[h] = arguments[h];
            n.on(s).unsubscribe(f), v.apply(n, d);
          };
          return n.on(s, f);
        }, this.on.ready.subscribe = Fn(this.on.ready.subscribe, function(s) {
          return function(v, f) {
            ee.vip(function() {
              var d, h = n._state;
              h.openComplete ? (h.dbOpenError || K.resolve().then(v), f && s(v)) : h.onReadyBeingFired ? (h.onReadyBeingFired.push(v), f && s(v)) : (s(v), d = n, f || s(function y() {
                d.on.ready.unsubscribe(v), d.on.ready.unsubscribe(y);
              }));
            });
          };
        }), this.Collection = (o = this, ut(Hr.prototype, function(m, y) {
          this.db = o;
          var f = er, d = null;
          if (y) try {
            f = y();
          } catch (g) {
            d = g;
          }
          var h = m._ctx, y = h.table, m = y.hook.reading.fire;
          this._ctx = { table: y, index: h.index, isPrimKey: !h.index || y.schema.primKey.keyPath && h.index === y.schema.primKey.name, range: f, keysOnly: !1, dir: "next", unique: "", algorithm: null, filter: null, replayFilter: null, justLimit: !0, isMatch: null, offset: 0, limit: 1 / 0, error: d, or: h.or, valueMapper: m !== et ? m : null };
        })), this.Table = (i = this, ut(ar.prototype, function(s, v, f) {
          this.db = i, this._tx = f, this.name = s, this.schema = v, this.hook = i._allTables[s] ? i._allTables[s].hook : at(null, { creating: [Mr, Y], reading: [Rr, et], updating: [Vr, Y], deleting: [Fr, Y] });
        })), this.Transaction = (a = this, ut(Xr.prototype, function(s, v, f, d, h) {
          var y = this;
          s !== "readonly" && v.forEach(function(m) {
            m = (m = f[m]) === null || m === void 0 ? void 0 : m.yProps, m && (v = v.concat(m.map(function(g) {
              return g.updatesTable;
            })));
          }), this.db = a, this.mode = s, this.storeNames = v, this.schema = f, this.chromeTransactionDurability = d, this.idbtrans = null, this.on = at(this, "complete", "error", "abort"), this.parent = h || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new K(function(m, g) {
            y._resolve = m, y._reject = g;
          }), this._completion.then(function() {
            y.active = !1, y.on.complete.fire();
          }, function(m) {
            var g = y.active;
            return y.active = !1, y.on.error.fire(m), y.parent ? y.parent._reject(m) : g && y.idbtrans && y.idbtrans.abort(), Z(m);
          });
        })), this.Version = (u = this, ut(oo.prototype, function(s) {
          this.db = u, this._cfg = { version: s, storesSource: null, dbschema: {}, tables: {}, contentUpgrade: null };
        })), this.WhereClause = (c = this, ut(fr.prototype, function(s, v, f) {
          if (this.db = c, this._ctx = { table: s, index: v === ":id" ? null : v, or: f }, this._cmp = this._ascending = V, this._descending = function(d, h) {
            return V(h, d);
          }, this._max = function(d, h) {
            return 0 < V(d, h) ? d : h;
          }, this._min = function(d, h) {
            return V(d, h) < 0 ? d : h;
          }, this._IDBKeyRange = c._deps.IDBKeyRange, !this._IDBKeyRange) throw new A.MissingAPI();
        })), this.on("versionchange", function(s) {
          0 < s.newVersion ? console.warn("Another connection wants to upgrade database '".concat(n.name, "'. Closing db now to resume the upgrade.")) : console.warn("Another connection wants to delete database '".concat(n.name, "'. Closing db now to resume the delete request.")), n.close({ disableAutoOpen: !1 });
        }), this.on("blocked", function(s) {
          !s.newVersion || s.newVersion < s.oldVersion ? console.warn("Dexie.delete('".concat(n.name, "') was blocked")) : console.warn("Upgrade '".concat(n.name, "' blocked by other connection holding version ").concat(s.oldVersion / 10));
        }), this._maxKey = lt(t.IDBKeyRange), this._createTransaction = function(s, v, f, d) {
          return new n.Transaction(s, v, f, n._options.chromeTransactionDurability, d);
        }, this._fireOnBlocked = function(s) {
          n.on("blocked").fire(s), We.filter(function(v) {
            return v.name === n.name && v !== n && !v._state.vcFired;
          }).map(function(v) {
            return v.on("versionchange").fire(s);
          });
        }, this.use(so), this.use(ho), this.use(co), this.use(ao), this.use(uo);
        var p = new Proxy(this, { get: function(s, v, f) {
          if (v === "_vip") return !0;
          if (v === "table") return function(h) {
            return Lt(n.table(h), p);
          };
          var d = Reflect.get(s, v, f);
          return d instanceof ar ? Lt(d, p) : v === "tables" ? d.map(function(h) {
            return Lt(h, p);
          }) : v === "_createTransaction" ? function() {
            return Lt(d.apply(this, arguments), p);
          } : d;
        } });
        this.vip = p, r.forEach(function(s) {
          return s(n);
        });
      }
      var Ut, fe = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", po = (Cn.prototype.subscribe = function(e, t, n) {
        return this._subscribe(e && typeof e != "function" ? e : { next: e, error: t, complete: n });
      }, Cn.prototype[fe] = function() {
        return this;
      }, Cn);
      function Cn(e) {
        this._subscribe = e;
      }
      try {
        Ut = { indexedDB: $.indexedDB || $.mozIndexedDB || $.webkitIndexedDB || $.msIndexedDB, IDBKeyRange: $.IDBKeyRange || $.webkitIDBKeyRange };
      } catch {
        Ut = { indexedDB: null, IDBKeyRange: null };
      }
      function Or(e) {
        var t, n = !1, r = new po(function(o) {
          var i = Jt(e), a, u = !1, c = {}, l = {}, p = { get closed() {
            return u;
          }, unsubscribe: function() {
            u || (u = !0, a && a.abort(), s && Pe.storagemutated.unsubscribe(f));
          } };
          o.start && o.start(p);
          var s = !1, v = function() {
            return cn(d);
          }, f = function(h) {
            Mt(c, h), Pn(l, c) && v();
          }, d = function() {
            var h, y, m;
            !u && Ut.indexedDB && (c = {}, h = {}, a && a.abort(), a = new AbortController(), m = (function(g) {
              var b = $e();
              try {
                i && Ye();
                var w = _e(e, g);
                return w = i ? w.finally(xe) : w;
              } finally {
                b && ze();
              }
            })(y = { subscr: h, signal: a.signal, requery: v, querier: e, trans: null }), Promise.resolve(m).then(function(g) {
              n = !0, t = g, u || y.signal.aborted || (c = {}, (function(b) {
                for (var w in b) if (X(b, w)) return;
                return 1;
              })(l = h) || s || (Pe(ct, f), s = !0), cn(function() {
                return !u && o.next && o.next(g);
              }));
            }, function(g) {
              n = !1, ["DatabaseClosedError", "AbortError"].includes(g == null ? void 0 : g.name) || u || cn(function() {
                u || o.error && o.error(g);
              });
            }));
          };
          return setTimeout(v, 0), p;
        });
        return r.hasValue = function() {
          return n;
        }, r.getValue = function() {
          return t;
        }, r;
      }
      var Re = ge;
      function An(e) {
        var t = Oe;
        try {
          Oe = !0, Pe.storagemutated.fire(e), En(e, !0);
        } finally {
          Oe = t;
        }
      }
      J(Re, k(k({}, gt), { delete: function(e) {
        return new Re(e, { addons: [] }).delete();
      }, exists: function(e) {
        return new Re(e, { addons: [] }).open().then(function(t) {
          return t.close(), !0;
        }).catch("NoSuchDatabaseError", function() {
          return !1;
        });
      }, getDatabaseNames: function(e) {
        try {
          return t = Re.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (xn(n) ? Promise.resolve(n.databases()).then(function(r) {
            return r.map(function(o) {
              return o.name;
            }).filter(function(o) {
              return o !== jt;
            });
          }) : _n(n, t).toCollection().primaryKeys()).then(e);
        } catch {
          return Z(new A.MissingAPI());
        }
        var t, n;
      }, defineClass: function() {
        return function(e) {
          B(this, e);
        };
      }, ignoreTransaction: function(e) {
        return C.trans ? Ae(C.transless, e) : e();
      }, vip: kn, async: function(e) {
        return function() {
          try {
            var t = In(e.apply(this, arguments));
            return t && typeof t.then == "function" ? t : K.resolve(t);
          } catch (n) {
            return Z(n);
          }
        };
      }, spawn: function(e, t, n) {
        try {
          var r = In(e.apply(n, t || []));
          return r && typeof r.then == "function" ? r : K.resolve(r);
        } catch (o) {
          return Z(o);
        }
      }, currentTransaction: { get: function() {
        return C.trans || null;
      } }, waitFor: function(e, t) {
        return t = K.resolve(typeof e == "function" ? Re.ignoreTransaction(e) : e).timeout(t || 6e4), C.trans ? C.trans.waitFor(t) : t;
      }, Promise: K, debug: { get: function() {
        return de;
      }, set: function(e) {
        Wn(e);
      } }, derive: Fe, extend: B, props: J, override: Fn, Events: at, on: Pe, liveQuery: Or, extendObservabilitySet: Mt, getByKeyPath: ye, setByKeyPath: ue, delByKeyPath: function(e, t) {
        typeof t == "string" ? ue(e, t, void 0) : "length" in t && [].map.call(t, function(n) {
          ue(e, n, void 0);
        });
      }, shallowClone: Ln, deepClone: je, getObjectDiff: Kn, cmp: V, asap: Vn, minKey: -1 / 0, addons: [], connections: We, errnames: Zt, dependencies: Ut, cache: Ne, semVer: "4.2.1", version: "4.2.1".split(".").map(function(e) {
        return parseInt(e);
      }).reduce(function(e, t, n) {
        return e + t / Math.pow(10, 2 * n);
      }) })), Re.maxKey = lt(Re.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Pe(ct, function(e) {
        Oe || (e = new CustomEvent(pn, { detail: e }), Oe = !0, dispatchEvent(e), Oe = !1);
      }), addEventListener(pn, function(e) {
        e = e.detail, Oe || An(e);
      }));
      var Xe, Oe = !1, jr = function() {
      };
      return typeof BroadcastChannel < "u" && ((jr = function() {
        (Xe = new BroadcastChannel(pn)).onmessage = function(e) {
          return e.data && An(e.data);
        };
      })(), typeof Xe.unref == "function" && Xe.unref(), Pe(ct, function(e) {
        Oe || Xe.postMessage(e);
      })), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
        if (!ge.disableBfCache && e.persisted) {
          de && console.debug("Dexie: handling persisted pagehide"), Xe != null && Xe.close();
          for (var t = 0, n = We; t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
        }
      }), addEventListener("pageshow", function(e) {
        !ge.disableBfCache && e.persisted && (de && console.debug("Dexie: handling persisted pageshow"), jr(), An({ all: new re(-1 / 0, [[]]) }));
      })), K.rejectionMapper = function(e, t) {
        return !e || e instanceof Le || e instanceof TypeError || e instanceof SyntaxError || !e.name || !Yn[e.name] ? e : (t = new Yn[e.name](t || e.message, e), "stack" in e && be(t, "stack", { get: function() {
          return this.inner.stack;
        } }), t);
      }, Wn(de), k(ge, Object.freeze({ __proto__: null, Dexie: ge, liveQuery: Or, Entity: tr, cmp: V, PropModification: it, replacePrefix: function(e, t) {
        return new it({ replacePrefix: [e, t] });
      }, add: function(e) {
        return new it({ add: e });
      }, remove: function(e) {
        return new it({ remove: e });
      }, default: ge, RangeSet: re, mergeRanges: ht, rangesOverlap: vr }), { default: ge }), ge;
    });
  })(Yt)), Yt.exports;
}
var _o = wo();
const qn = /* @__PURE__ */ go(_o), Ir = Symbol.for("Dexie"), Gt = globalThis[Ir] || (globalThis[Ir] = qn);
if (qn.semVer !== Gt.semVer)
  throw new Error(`Two different versions of Dexie loaded in the same app: ${qn.semVer} and ${Gt.semVer}`);
const {
  liveQuery: Io,
  mergeRanges: Ko,
  rangesOverlap: Do,
  RangeSet: To,
  cmp: Co,
  Entity: Ao,
  PropModification: Bo,
  replacePrefix: qo,
  add: No,
  remove: Ro,
  DexieYProvider: Mo
} = Gt, Wt = {
  searchTerms: ["Allow", "Keep"],
  timeoutSeconds: 120,
  confidenceThreshold: 60
}, Nn = 2;
class xo extends Gt {
  constructor() {
    super("ProjectDatabase");
    zt(this, "projects");
    zt(this, "bundles");
    zt(this, "testRuns");
    this.version(1).stores({
      projects: "++id, projectName, isPublic",
      bundles: "++id, bundleName, projectId, isPublic",
      testRuns: "++id, bundleId, project_id, status"
    }), this.version(2).stores({
      projects: "++id, projectName, isPublic",
      bundles: "++id, bundleName, projectId, isPublic",
      testRuns: "++id, bundleId, project_id, status"
    }).upgrade((x) => x.table("projects").toCollection().modify((k) => {
      k.schemaVersion = Nn, k.loopStartIndex = k.loopStartIndex ?? -1, k.globalDelayMs = k.globalDelayMs ?? 0, k.conditionalDefaults = k.conditionalDefaults ?? {
        ...Wt
      }, k.recorded_steps && Array.isArray(k.recorded_steps) && (k.recorded_steps = k.recorded_steps.map(
        (U) => Ht(U)
      )), console.log(`[Migration] Upgraded project ${k.id} to schema v2`);
    })), this.projects = this.table("projects"), this.bundles = this.table("bundles"), this.testRuns = this.table("testRuns");
  }
  // ==========================================================================
  // PROJECT METHODS
  // ==========================================================================
  /**
   * Add a new project with default Vision fields.
   */
  async addProject(x) {
    const k = (/* @__PURE__ */ new Date()).toISOString(), U = {
      ...x,
      schemaVersion: Nn,
      loopStartIndex: -1,
      globalDelayMs: 0,
      conditionalDefaults: { ...Wt },
      recorded_steps: (x.recorded_steps || []).map(Ht),
      created_date: x.created_date || k,
      updated_date: k
    };
    return await this.projects.add(U);
  }
  /**
   * Update an existing project.
   */
  async updateProject(x, k) {
    const U = {
      ...k,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    return k.recorded_steps && (U.recorded_steps = k.recorded_steps.map(Ht)), await this.projects.update(x, U);
  }
  /**
   * Get all projects.
   */
  async getAllProjects() {
    return (await this.projects.toArray()).map(Kr);
  }
  /**
   * Get a project by ID.
   */
  async getProject(x) {
    const k = await this.projects.get(x);
    return k ? Kr(k) : void 0;
  }
  /**
   * Delete a project.
   */
  async deleteProject(x) {
    await this.projects.delete(x);
  }
  // ==========================================================================
  // VISION-SPECIFIC METHODS
  // ==========================================================================
  /**
   * Update the loop start index for a project.
   */
  async setLoopStartIndex(x, k) {
    return await this.projects.update(x, {
      loopStartIndex: k ?? -1,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update the global delay for a project.
   */
  async setGlobalDelay(x, k) {
    return await this.projects.update(x, {
      globalDelayMs: Math.max(0, k),
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update conditional defaults for a project.
   */
  async setConditionalDefaults(x, k) {
    const U = await this.projects.get(x);
    if (!U) throw new Error(`Project ${x} not found`);
    return await this.projects.update(x, {
      conditionalDefaults: {
        ...Wt,
        ...U.conditionalDefaults,
        ...k
      },
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update a specific step's delay.
   */
  async setStepDelay(x, k, U) {
    const $ = await this.projects.get(x);
    if (!$) throw new Error(`Project ${x} not found`);
    if (!$.recorded_steps || k >= $.recorded_steps.length)
      throw new Error(`Step ${k} not found`);
    const z = [...$.recorded_steps];
    return z[k] = {
      ...z[k],
      delaySeconds: U !== void 0 ? Math.max(0, U) : void 0
    }, await this.projects.update(x, {
      recorded_steps: z,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Update a specific step's conditional config.
   */
  async setStepConditionalConfig(x, k, U) {
    const $ = await this.projects.get(x);
    if (!$) throw new Error(`Project ${x} not found`);
    if (!$.recorded_steps || k >= $.recorded_steps.length)
      throw new Error(`Step ${k} not found`);
    const z = [...$.recorded_steps];
    return z[k] = {
      ...z[k],
      conditionalConfig: U,
      event: U != null && U.enabled ? "conditional-click" : z[k].event
    }, await this.projects.update(x, {
      recorded_steps: z,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  // ==========================================================================
  // TEST RUN METHODS
  // ==========================================================================
  /**
   * Create a new test run.
   */
  async createTestRun(x) {
    return await this.testRuns.add(x);
  }
  /**
   * Update a test run.
   */
  async updateTestRun(x, k) {
    return await this.testRuns.update(x, k);
  }
  /**
   * Get test runs for a project.
   */
  async getTestRunsByProject(x) {
    return await this.testRuns.where("project_id").equals(x).reverse().sortBy("start_time");
  }
  /**
   * Get a test run by ID.
   */
  async getTestRun(x) {
    return await this.testRuns.get(x);
  }
  /**
   * Delete a test run.
   */
  async deleteTestRun(x) {
    await this.testRuns.delete(x);
  }
}
function Ht(_) {
  return {
    ..._,
    label: _.label || "",
    event: _.event || "click",
    recordedVia: _.recordedVia || "dom",
    // Preserve existing values, don't add undefined fields
    ..._.coordinates !== void 0 && { coordinates: _.coordinates },
    ..._.ocrText !== void 0 && { ocrText: _.ocrText },
    ..._.confidenceScore !== void 0 && { confidenceScore: _.confidenceScore },
    ..._.delaySeconds !== void 0 && { delaySeconds: _.delaySeconds },
    ..._.conditionalConfig !== void 0 && { conditionalConfig: _.conditionalConfig }
  };
}
function Kr(_) {
  return {
    ..._,
    schemaVersion: _.schemaVersion ?? Nn,
    loopStartIndex: _.loopStartIndex ?? -1,
    globalDelayMs: _.globalDelayMs ?? 0,
    conditionalDefaults: _.conditionalDefaults ?? { ...Wt },
    recorded_steps: (_.recorded_steps || []).map(Ht)
  };
}
const se = new xo();
async function ko(_) {
  try {
    let F;
    _ && (F = (await chrome.tabs.get(_)).windowId);
    const x = F !== void 0 ? await chrome.tabs.captureVisibleTab(F, {
      format: "png",
      quality: 100
    }) : await chrome.tabs.captureVisibleTab({
      format: "png",
      quality: 100
    });
    return console.log("[VisionHandler] Screenshot captured successfully"), {
      success: !0,
      dataUrl: x
      // Dimensions will be calculated by VisionEngine using Image API
    };
  } catch (F) {
    return console.error("[VisionHandler] Screenshot failed:", F), {
      success: !1,
      error: F instanceof Error ? F.message : String(F)
    };
  }
}
async function So(_, F) {
  try {
    const x = F || ["contentScript/index.js"];
    return await chrome.scripting.executeScript({
      target: { tabId: _ },
      files: x
    }), console.log(`[VisionHandler] Scripts injected into tab ${_}`), { success: !0 };
  } catch (x) {
    return console.error("[VisionHandler] Script injection failed:", x), {
      success: !1,
      error: x instanceof Error ? x.message : String(x)
    };
  }
}
async function Po(_) {
  const { tabId: F, ...x } = _;
  try {
    return await chrome.tabs.sendMessage(F, x);
  } catch (k) {
    return console.error("[VisionHandler] Forward to content script failed:", k), {
      success: !1,
      error: k instanceof Error ? k.message : String(k)
    };
  }
}
function Oo(_, F) {
  var x;
  if ((x = _.type) != null && x.startsWith("VISION_"))
    switch (console.log(`[VisionHandler] Handling: ${_.type}`), _.type) {
      case "VISION_SCREENSHOT":
        return ko(_.tabId);
      case "VISION_INJECT_SCRIPT":
        return So(
          _.tabId,
          _.files
        );
      case "VISION_CLICK":
      case "VISION_TYPE":
      case "VISION_KEY":
      case "VISION_SCROLL":
      case "VISION_GET_ELEMENT":
        return _.tabId ? Po(_) : Promise.resolve({ success: !1, error: "tabId is required" });
      default:
        console.warn(`[VisionHandler] Unknown Vision message type: ${_.type}`);
        return;
    }
}
async function jo() {
  if ("storage" in navigator && navigator.storage && navigator.storage.persist) {
    const _ = await navigator.storage.persisted();
    if (console.log("Storage persisted?", _), !_) {
      const F = await navigator.storage.persist();
      console.log("Persistence granted:", F);
    }
  } else
    console.log("navigator.storage.persist not available in this context");
}
jo();
let pt = null;
const Rn = /* @__PURE__ */ new Set();
chrome.runtime.onMessage.addListener((_, F, x) => {
  if (_.type === "VISION_CAPTURE_FOR_RECORDING")
    return (async () => {
      var k;
      try {
        if (!((k = F.tab) != null && k.windowId)) {
          x({ error: "No window context" });
          return;
        }
        const U = await chrome.tabs.captureVisibleTab(
          F.tab.windowId,
          { format: "png" }
        );
        x({
          screenshot: U,
          bounds: _.bounds,
          text: null
          // Content script will extract via DOM first
        });
      } catch (U) {
        console.error("[TestFlow Background] Screenshot capture failed:", U), x({ error: String(U) });
      }
    })(), !0;
});
chrome.runtime.onMessage.addListener((_, F, x) => {
  var U, $, z, W;
  console.log("[Background] Message received:", _, "from sender:", F);
  const k = Oo(_);
  if (k !== void 0)
    return console.log("[Background] Handling as Vision message"), Promise.resolve(k).then(x), !0;
  if (_.type === "logEvent")
    return !1;
  if (!_.action)
    return console.log("[Background] No action specified, returning false"), !1;
  console.log("[Background] Processing action:", _.action);
  try {
    if (_.action === "add_project") {
      console.log("Background: Received add_project request", _.payload);
      const B = {
        ..._.payload,
        recorded_steps: [],
        parsed_fields: [],
        csv_data: []
      };
      return se.addProject(B).then((D) => {
        console.log("Background: Project added successfully with ID:", D), x({ success: !0, id: D });
      }).catch((D) => {
        console.error("Background: Error adding project:", D), x({ success: !1, error: D.message });
      }), !0;
    }
    if (_.action === "update_project") {
      const { id: B, ...D } = _.payload, G = {};
      return (D.name || D.projectName) && (G.projectName = D.name || D.projectName), (D.target_url || D.project_url) && (G.project_url = D.target_url || D.project_url), D.recorded_steps !== void 0 && (G.recorded_steps = D.recorded_steps), D.loopStartIndex !== void 0 && (G.loopStartIndex = D.loopStartIndex), D.globalDelayMs !== void 0 && (G.globalDelayMs = D.globalDelayMs), D.conditionalDefaults !== void 0 && (G.conditionalDefaults = D.conditionalDefaults), D.schemaVersion !== void 0 && (G.schemaVersion = D.schemaVersion), se.updateProject(B, G).then(() => x({ success: !0 })).catch(
        (X) => x({ success: !1, error: X.message })
      ), !0;
    }
    if (_.action === "get_project") {
      const B = (U = _.payload) == null ? void 0 : U.id;
      return se.projects.get(B).then((D) => {
        x(D ? { success: !0, project: D } : { success: !1, error: "Project not found" });
      }).catch(
        (D) => x({ success: !1, error: D.message })
      ), !0;
    }
    if (_.action === "get_all_projects")
      return se.getAllProjects().then((B) => x({ success: !0, projects: B })).catch((B) => x({ success: !1, error: B.message })), !0;
    if (_.action === "delete_project") {
      const B = ($ = _.payload) == null ? void 0 : $.projectId;
      return se.deleteProject(B).then(() => x({ success: !0 })).catch((D) => x({ success: !1, error: D.message })), !0;
    }
    if (_.action === "get_project_by_id") {
      const B = (z = _.payload) == null ? void 0 : z.id;
      return se.projects.get(B).then((D) => {
        x(D ? { success: !0, project: D } : { success: !1, error: "Process  not found" });
      }).catch((D) => {
        x({ success: !1, error: D.message });
      }), !0;
    }
    if (_.action === "open_project_url_and_inject") {
      const B = (W = _.payload) == null ? void 0 : W.id;
      return se.getAllProjects().then((D) => {
        const G = D.find((J) => J.id === B);
        if (!G) {
          x({ success: !1, error: "Process not found" });
          return;
        }
        const X = G.target_url || G.project_url;
        if (!X) {
          x({ success: !1, error: "No target URL configured for project" });
          return;
        }
        chrome.tabs.create({ url: X }, (J) => {
          J != null && J.id ? (pt = J.id, Rn.add(J.id), Mn(J.id), x({ success: !0, tabId: J.id })) : x({ success: !1, error: "Failed to create tab" });
        });
      }).catch((D) => {
        x({ success: !1, error: D.message });
      }), !0;
    }
    if (_.action === "update_project_steps") {
      const { id: B, recorded_steps: D, loopStartIndex: G, globalDelayMs: X, delayMode: J } = _.payload;
      return se.projects.update(B, {
        recorded_steps: D,
        // VISION: Save Vision fields
        ...G !== void 0 && { loopStartIndex: G },
        ...X !== void 0 && { globalDelayMs: X },
        ...J !== void 0 && { delayMode: J },
        ...J !== void 0 && { delayMode: J },
        // B-43: Add this
        updated_date: (/* @__PURE__ */ new Date()).toISOString()
      }).then(() => {
        x({ success: !0 });
      }).catch((yt) => {
        x({ success: !1, error: yt.message });
      }), !0;
    }
    if (_.action === "update_project_fields") {
      const { id: B, parsed_fields: D } = _.payload;
      return se.projects.update(B, { parsed_fields: D }).then(() => {
        x({ success: !0 });
      }).catch((G) => {
        x({ success: !1, error: G.message });
      }), !0;
    }
    if (_.action === "update_project_csv") {
      const { id: B, csv_data: D } = _.payload;
      return se.projects.update(B, { csv_data: D }).then(() => {
        x({ success: !0 });
      }).catch((G) => {
        x({ success: !1, error: G.message });
      }), !0;
    }
    if (_.action === "createTestRun")
      return (async () => {
        try {
          const B = await se.testRuns.add(_.payload), D = await se.testRuns.get(B);
          x({ success: !0, testRun: D });
        } catch (B) {
          x({ success: !1, error: B });
        }
      })(), !0;
    if (_.action === "updateTestRun")
      return (async () => {
        try {
          await se.testRuns.update(_.id, _.payload), x({ success: !0 });
        } catch (B) {
          x({ success: !1, error: B });
        }
      })(), !0;
    if (_.action === "getTestRunsByProject") {
      const B = _.projectId;
      return se.getTestRunsByProject(B).then((D) => {
        x({ success: !0, data: D });
      }).catch((D) => {
        x({ success: !1, error: D.message });
      }), !0;
    }
    if (_.action === "openTab") {
      const B = _.url;
      return chrome.tabs.create({ url: B }, (D) => {
        if (chrome.runtime.lastError) {
          console.error("Failed to create tab:", chrome.runtime.lastError.message), x({ success: !1, error: chrome.runtime.lastError.message });
          return;
        }
        if (!(D != null && D.id)) {
          x({ success: !1, error: "No tab ID returned" });
          return;
        }
        Mn(D.id, (G) => {
          G.success ? (console.log("Injected into tab", D.id), D != null && D.id && (pt = D.id, Rn.add(D.id), x({ success: !0, tabId: D.id }))) : (console.error("Injection failed:", G.error), x({ success: !1, error: G.error }));
        });
      }), !0;
    }
    return _.action === "close_opened_tab" ? (pt !== null ? chrome.tabs.remove(pt, () => {
      pt = null, x({ success: !0 });
    }) : x({ success: !1, error: "No opened tab to close" }), !0) : _.action === "openDashBoard" ? (chrome.tabs.create({ url: chrome.runtime.getURL("pages.html") }, () => {
      x({ success: !0 });
    }), !0) : (console.warn("Background: Unknown action:", _.action), x({ success: !1, error: `Unknown action: ${_.action}` }), !1);
  } catch (B) {
    return console.error("Background: Exception in message handler:", B), x({ success: !1, error: B.message }), !1;
  }
});
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html")
  });
});
chrome.runtime.onInstalled.addListener((_) => {
  _.reason === "install" && chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html#dashboard")
  });
});
function Mn(_, F) {
  chrome.scripting.executeScript(
    {
      target: { tabId: _, allFrames: !0 },
      files: ["js/main.js"]
    },
    () => {
      chrome.runtime.lastError ? (console.warn("Inject failed:", chrome.runtime.lastError.message), F == null || F({ success: !1 })) : (console.log("Injected main.js into tab", _), F == null || F({ success: !0 }));
    }
  );
}
chrome.webNavigation.onCommitted.addListener((_) => {
  Rn.has(_.tabId) && (console.log("Frame navigated:", _.frameId, _.url), Mn(_.tabId));
});
